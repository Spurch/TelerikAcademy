﻿/*
 Problem 3. Min, Max, Sum and Average of N Numbers
 Write a program that reads from the console a sequence of n integer numbers and returns the minimal, the maximal number, the sum and the average of all numbers (displayed with 2 digits after the decimal point).
 The input starts by the number n (alone in a line) followed by n lines, each holding an integer number.
 The output is like in the examples below. 
 */
using System;
class MinMaxSumAvrg
{
    static void Main()
    {
        Console.WriteLine("How many numbers are you going to enter? ");
        int Value = Int32.Parse(Console.ReadLine());
        /*
         * We are going to use the first value entered as a starting point 
         * for the Min and Max variables. That is why we initialize CountNumbers with 1
         * and we add the Min variable to the SumOfNumbers before entering the
         * for-loop. Note that the for-loop will iterate till N-1. That is because
         * we already have the first value in the Min variable.
         * All of this is necessary because if we use some fixed starting values for
         * Min & Max variables we might run into a situation where they don't change at all.
         * 
         * Imagine that we initilize Min and Max with 0.0 and the user enters only positive
         * or only negative values - what would be the impact on the two variables?
         */
        int CountNumbers = 1;//The counter is needed for the calculation of the avarage.
        double Min = double.Parse(Console.ReadLine());
        double Max = Min;
        double Avrg = 0.0;
        double SumOfNumbers = 0.0;
        SumOfNumbers += Min;
        /*
         * Since we don't need to remember the individual values we
         * can do all the calculation on the fly in the for loop.
         */
        for (int i = 0; i < Value-1; i++)
        {
            //We get the next value. Here we start from the second value
            //because we used the first one to initialize Min and Max.
            double CurrentEntry = double.Parse(Console.ReadLine());
            //We increment the counter.
            CountNumbers++;
            //We add the new value to the sum.
            SumOfNumbers += CurrentEntry;
            //We check if we need to change Min or Max.
            if (CurrentEntry < Min)
            {
                Min = CurrentEntry;
            }
            if (CurrentEntry > Max)
            {
                Max = CurrentEntry;
            }
        }
        //After we are done with the for-loop we can
        //use the counter and the sum to calculate the avarage.
        Avrg = SumOfNumbers / CountNumbers;
        //All we need to do now is to print. ;)
        Console.Write("min= {0}\nmax= {1}\nsum= {2}\navg= {3:F2}", Min, Max, SumOfNumbers, Avrg);
        Console.WriteLine();
    }
}

