﻿/*
 Problem 12.* Randomize the Numbers 1…N
 Write a program that enters in integer n and 
 prints the numbers 1, 2, …, n in random order. 
 */
using System;
class RandomizedNumbers
{
    static void Main()
    {
        Console.WriteLine("Value for N:");
        int n = Int32.Parse(Console.ReadLine());
        //We are going to use a boolean array to mark
        //all the values we have used already.
        bool[] CheckedNumbers = new bool[n+1];
        Random rand = new Random();
        //This variable will store the current random number.
        int temp = 0;
        //Counter for the printed value.
        int NumbersPrinted = 0;

        //We initialize all the members of the array with 'false'.
        for (int i = 0; i < n+1; i++)
        {
            CheckedNumbers[i] = false;
        }

        //While we still haven't printed enough numbers...
        while (NumbersPrinted < n)
        {
            //Get the next random number
            temp = rand.Next(1, n + 1);
            //Since the numbers are from 1 to N
            //we can use the array index as a reference to the
            //random value we want to check.
            if (!CheckedNumbers[temp])
            {
                //If we still haven't used that value we mark it
                //as used, print it and increment the counter.
                CheckedNumbers[temp] = true;
                Console.Write("{0}, ", temp);
                NumbersPrinted++;
            }
        }
        Console.WriteLine();
    }
}

