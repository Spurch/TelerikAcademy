﻿/*
 Problem 16. Decimal to Hexadecimal Number
 Using loops write a program that converts an integer number to
 its hexadecimal representation.
 The input is entered as long. The output should be a variable of type string.
 Do not use the built-in .NET functionality. 
 */
using System;
class DecToHex
{
    static void Main()
    {
        Console.WriteLine("Enter decimal value: ");
        long DecValue = Int64.Parse(Console.ReadLine());
        string HexValue = "";
        int Reminder = 0;
        Console.Write("The hex value of {0} is: ", DecValue);
        do
        {
            //We get the current reminder.
            Reminder = (int)DecValue % 16;
            //Since we are converting to hex we first 
            //need to check if the reminder is below 10.
            if ((int)DecValue % 16 <= 9)
            {
                //We decrease the value of DecValue
                DecValue /= 16;
                //We append the current reminder to the string.
                HexValue += Reminder;
            }
            //If the reminder is >10 then we use a switch statement
            //to handle the cases between 10 and 15.
            else
            {
                switch (Reminder)
                {
                    case 10 :
                        DecValue /= 16;
                        HexValue += "A";
                        break;
                    case 11:
                        DecValue /= 16;
                        HexValue += "B";
                        break;
                    case 12:
                        DecValue /= 16;
                        HexValue += "C";
                        break;
                    case 13:
                        DecValue /= 16;
                        HexValue += "D";
                        break;
                    case 14:
                        DecValue /= 16;
                        HexValue += "E";
                        break;
                    case 15:
                        DecValue /= 16;
                        HexValue += "F";
                        break;
                }
            }
            //While the DecimalValue is bigger than 0.
        } while (DecValue > 0);
        //We print the resulting string backwards 
        //to get the correct hex representation of the decimal number.
        for (int i = HexValue.Length - 1; i >= 0; i--)
        {
            Console.Write(HexValue[i]);
        }
        Console.WriteLine();
    }
}

