﻿/*
 Problem 13. Binary to Decimal Number
 Using loops write a program that converts a binary integer number to its decimal form.
 The input is entered as string. The output should be a variable of type long.
 Do not use the built-in .NET functionality. 
 */
using System;
class BinToDec
{
    static void Main()
    {
        Console.WriteLine("Enter binary value: ");
        string BinaryValue = Console.ReadLine();
        //Long variable to hold the final result.
        long DecimalValue = 0;
        //This variable will hold the current bit value.
        int temp = 0;
        //We need a counter because we are going to read the string backwards.
        int flag = 0;
        //We start going through the string backwards.
        for (int i = BinaryValue.Length-1; i >= 0; i--)
        {
            //We parse the string to check the current bit value.
            temp = Int32.Parse(BinaryValue[i].ToString());
            //We are interested only in the 1s for our calculation.
            if (temp == 1)
            {
                //We increment the sum in the final result
                //1<<flag basically gives us 2^flag.
                DecimalValue += temp * (1<<flag);
            }
            //We increase the counter.
            flag++;
        }
        Console.WriteLine(DecimalValue);
    }
}

