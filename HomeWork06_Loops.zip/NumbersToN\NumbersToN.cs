﻿/*
 Problem 1. Numbers from 1 to N
 Write a program that enters from the console a positive integer n and prints 
 all the numbers from 1 to n, on a single line, separated by a space. 
 */
using System;
class NumbersToN
{
    static void Main()
    {
        Console.Write("Enter value for N:");
        int Value = Int32.Parse(Console.ReadLine());
        //Everything is pretty self-explanatory.
        //Just a simple for-loop that iterates through
        //the range and prints the values.
        //NOTE: We start the iteration from 1 till N(inclusively).
        for (int i = 1; i <= Value; i++)
        {
            Console.Write("{0} ", i);
        }
        Console.WriteLine();
    }
}

