﻿/*
 Problem 14. Decimal to Binary Number
    Using loops write a program that converts an integer number to its binary representation.
    The input is entered as long. The output should be a variable of type string.
    Do not use the built-in .NET functionality. 
 */
using System;
class DecToBin
{
    static void Main()
    {
        Console.WriteLine("Enter decimal value: ");
        long DecimalValue = Int64.Parse(Console.ReadLine());
        //We are going to store the current reminder here.
        int Reminder = 0;
        //The string for the result.
        string result = "";
        Console.Write("The binary value of {0} is: ", DecimalValue);
        do
        {
            //We get the current reminder.
            Reminder = (int)DecimalValue % 2;
            //We decrease the value of DecimalValue
            DecimalValue /= 2;
            //We append the current reminder to the string.
            result += Reminder;
            //While the DecimalValue is bigger than 0.
        } while (DecimalValue > 0);
        //We print the resulting string backwards 
        //to get the correct binary representation of the decimal number.
        for (int i = result.Length-1; i >= 0; i--)
        {
            Console.Write(result[i]);
        }
        Console.WriteLine();
    }
}

