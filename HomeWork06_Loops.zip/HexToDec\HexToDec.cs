﻿/*
 Problem 15. Hexadecimal to Decimal Number
 Using loops write a program that converts a hexadecimal integer number to its decimal form.
 The input is entered as string. The output should be a variable of type long.
 Do not use the built-in .NET functionality. 
 */
using System;
class HexToDec
{
    static void Main()
    {
        Console.WriteLine("Enter hex value (using capital letter only): ");
        string HexValue = Console.ReadLine();

        //This variable will store the final result.
        long DecValue = 0;
        //This variable will store the temp letter during calculations.
        string TempString = "";
        //This variable will store the temp digit during calculations.
        int TempNum = 0;
        //This variable will keep track of the position we are currently on.
        int PositionFlag = 0;

        //NOTE: We read the string backwards!
        for (int i = HexValue.Length-1; i >= 0; i--)
        {
            //First we check if we have a digit or a letter on the current position.
            if (Int32.TryParse(HexValue[i].ToString(), out TempNum))
            {
                /*
                 * Here we use a little bitwise trick to get the power
                 * of 16 we need. We know that 1<<N gives us 2^N.
                 * We also know that 16 = 2^4 which means that
                 * 1<<(4*PositionFlag) will give us (2^4)^PositionFlag
                 */
                DecValue += TempNum * (1 << (4 * PositionFlag));
            }
            else
            {
                //In case of a letter we use a switch statement to 
                //calculate accordingly. 
                TempString = HexValue[i].ToString();
                switch (TempString)
                {
                    case "A":
                        DecValue += 10 * (1 << (4 * PositionFlag));
                        break;
                    case "B":
                        DecValue += 11 * (1 << (4 * PositionFlag));
                        break;
                    case "C":
                        DecValue += 12 * (1 << (4 * PositionFlag));
                        break;
                    case "D":
                        DecValue += 13 * (1 << (4 * PositionFlag));
                        break;
                    case "E":
                        DecValue += 14 * (1 << (4 * PositionFlag));
                        break;
                    case "F":
                        DecValue += 15 * (1 << (4 * PositionFlag));
                        break;
                }
            }
            //We must not forget to move the position!
            PositionFlag++;
        }
        Console.WriteLine(DecValue);
    }
}

