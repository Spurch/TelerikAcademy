﻿/*
 Problem 6. Calculate N! / K!
 Write a program that calculates n! / k! for given n and k (1 < k < n < 100).
 Use only one loop. 
 */
using System;
class CalculateNK
{
    static void Main()
    {
        Console.WriteLine("Enter value for N:");
        int n = Int32.Parse(Console.ReadLine());
        Console.WriteLine("Enter value for K:");
        int k = Int32.Parse(Console.ReadLine());
        double result = 1;
        /*
         * Here we can use a little trick from combinatorics theory
         * Since we know that 1 < K < N < 100 this means that not only
         * we know the left and right borders of the range of N but also 
         * that K! is basically a subset of the N! set - because K < N
         * This basically means that the result of N! / K! will be 
         * as simple as N*(N-1)*(N-2)*(N-3)...(K+1)
         */
        for (int i = n; i > k; i--)
        {
            result *= i; 
        }
        Console.WriteLine(result);
    }
}

