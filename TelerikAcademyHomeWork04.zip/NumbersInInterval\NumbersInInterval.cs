﻿/*
 Problem 11.* Numbers in Interval Dividable by Given Number
 Write a program that reads two positive integer numbers and 
 prints how many numbers p exist between them such that the 
 reminder of the division by 5 is 0. 
 */
using System;
class NumbersInInterval
{
    static void Main()
    {
        Console.Write("Range starting value: ");
        int start = Int32.Parse(Console.ReadLine());
        Console.Write("Range end value: ");
        int end = Int32.Parse(Console.ReadLine());
        int count = 0;
        if (start == 0)
        {
            for (start = 5; start <= end; start += 5)
            {
                Console.Write("{0}, ", start);
                count++;
            }
            Console.WriteLine("\nValues in range: {0}", count);
        }
        else
        {
            while (!(start % 5 == 0))
            {
                //Console.WriteLine(start);
                start++;
            }
            for (; start <= end; start += 5)
            {
                Console.Write("{0}, ", start);
                count++;
            }
            Console.WriteLine("\nValues in range: {0}", count);
        }
    }
}

