﻿/*
Problem 2. Print Company Information
A company has name, address, phone number, fax number, web site and manager. 
The manager has first name, last name, age and a phone number.
Write a program that reads the information about a company and its manager 
and prints it back on the console. 
 */
using System;
class CompanyInfo
{
    static void Main()
    {
        string CompanyName;
        string CompanyAddress;
        string Phone;
        string Fax;
        string WebSite;
        string[] Manager = new string[4];
        
        Console.WriteLine("Company name:");
        CompanyName = Console.ReadLine();
        
        Console.WriteLine("Company address:");
        CompanyAddress = Console.ReadLine();
        
        Console.WriteLine("Phone:");
        Phone = Console.ReadLine();
        
        Console.WriteLine("Fax:");
        Fax = Console.ReadLine();
        
        Console.WriteLine("Web site:");
        WebSite = Console.ReadLine();

        Console.WriteLine("Manager first name:");
        Manager[0] = Console.ReadLine();

        Console.WriteLine("Manager last name:");
        Manager[1] = Console.ReadLine();

        Console.WriteLine("Manager age:");
        Manager[2] = Console.ReadLine();

        Console.WriteLine("Manager phone:");
        Manager[3] = Console.ReadLine();
        Console.WriteLine();
        Console.Write("{0}\nAddress: {1}\nTel. {2}\nFax: {3}\nWeb site:{4}\nManager: {5} {6}(age: {7}, tel. {8})\n",
            CompanyName, CompanyAddress, Phone, Fax, WebSite, 
            Manager[0], Manager[1], Manager[2], Manager[3]);
    }
}

