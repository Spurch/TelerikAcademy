﻿/*
 Problem 7. Sum of 5 Numbers
 Write a program that enters 5 numbers (given in a single line, separated by a space), 
 calculates and prints their sum. 
 */
using System;
class SumOfFive
{
    static void Main()
    {
        Console.WriteLine("Enter 5 numbers to calculate:");
        string Numbers = Console.ReadLine();
        string[] Values = Numbers.Split(' ');
        double TempValue = 0.0;
        double sum = 0.0;
        foreach (var value in Values)
        {
            if (double.TryParse(value, out TempValue))
            {
                sum += TempValue;
            }
        }
        Console.WriteLine("The sum is: {0}", sum);
    }
}

