﻿/*
 Problem 5. Formatting Numbers
    Write a program that reads 3 numbers:
        integer a (0 <= a <= 500)
        floating-point b
        floating-point c
    The program then prints them in 4 virtual columns on the console. 
    Each column should have a width of 10 characters.
        The number a should be printed in hexadecimal, left aligned
        Then the number a should be printed in binary form, padded with zeroes
        The number b should be printed with 2 digits after the decimal point, right aligned
        The number c should be printed with 3 digits after the decimal point, left aligned. 
 */
using System;
class FormattingNumbers
{
    static void Main()
    {
        Console.WriteLine("Integer value:");
        uint IntegerValue = UInt32.Parse(Console.ReadLine());
        if (IntegerValue >= 0 && IntegerValue <= 500)
        {
            Console.WriteLine("First floating-point value:");
            double DoubleValueOne = double.Parse(Console.ReadLine());
            Console.WriteLine("Second floating-point value:");
            double DoubleValueTwo = double.Parse(Console.ReadLine());
            //By using this additional string we ensure that the Hex value 
            //will be centrilized in the console output.
            string HexCenter = IntegerValue.ToString("X");
            HexCenter = HexCenter.PadLeft(HexCenter.Length + (10 - HexCenter.Length) / 2, ' ').PadRight(10, ' ');

            Console.WriteLine("{0,-10:X}|{1,10}|{2,10:F2}|{3,-10:F3}|", HexCenter, Convert.ToString(IntegerValue, 2).PadLeft(10, '0'), DoubleValueOne, DoubleValueTwo);
        }
        else
        {
            Console.WriteLine("Incorrect Integer value range!");
        }
    }
}

