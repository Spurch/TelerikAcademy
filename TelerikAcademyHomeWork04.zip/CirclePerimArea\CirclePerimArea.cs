﻿/*
 Problem 3. Circle Perimeter and Area
 Write a program that reads the radius r of a circle and prints its 
 perimeter and area formatted with 2 digits after the decimal point.
 */
using System;
class CirclePerimArea
{
    static void Main()
    {
        Console.Write("Enter circle radius: ");
        double CircleRadius = double.Parse(Console.ReadLine());
        double CirclePer = 2 * Math.PI * CircleRadius;
        double CircleArea = Math.PI * Math.Pow(CircleRadius, 2);
        Console.Write("Circle perimeter is: {0:F2}\nCircle area is: {1:F2}\n", CirclePer, CircleArea);
    }
}

