﻿/*
 Problem 9. Sum of n Numbers
 Write a program that enters a number n and after that enters more n numbers 
 and calculates and prints their sum. Note: You may need to use a for-loop. 
 */
using System;
class NNumbersSum
{
    static void Main()
    {
        Console.Write("Enter value: ");
        int ValueN = 0;
        if (Int32.TryParse(Console.ReadLine(), out ValueN))
        {
            double SumOfN = 0.0;
            Console.WriteLine("Enter {0} values to calculate(each on a new line):");
            int Count = 0;
            double temp = 0.0;
            while (Count < ValueN)
            {
                if (double.TryParse(Console.ReadLine(), out temp))
                {
                    SumOfN += temp;
                    Count++;
                }
                else
                {
                    Console.WriteLine("Invalid entry!Please re-enter value!");
                }
            }
            Console.WriteLine("The sum is: {0}", SumOfN);
        }
        else
        {
            Console.WriteLine("Incorrect value!");
        }
    }
}

