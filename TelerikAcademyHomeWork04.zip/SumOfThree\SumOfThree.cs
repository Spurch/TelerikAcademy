﻿/*
 Problem 1. Sum of 3 Numbers
 Write a program that reads 3 real numbers from the console and prints their sum.
 */
using System;
class SumOfThree
{
    static void Main()
    {
        Console.WriteLine("Enter 1st value:");
        double FirstVal = double.Parse(Console.ReadLine());
        Console.WriteLine("Enter 2nd value:");
        double SecondVal = double.Parse(Console.ReadLine());
        Console.WriteLine("Enter 3rd value:");
        double ThirdVal = double.Parse(Console.ReadLine());
        double Result = FirstVal + SecondVal + ThirdVal;
        Console.WriteLine("The sum is {0}" , Result);
    }
}

