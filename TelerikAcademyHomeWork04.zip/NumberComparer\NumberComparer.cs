﻿/*
Problem 4. Number Comparer
Write a program that gets two numbers from the console and prints the greater of them.
Try to implement this without if statements.
 */
using System;
class NumberComparer
{
    static void Main()
    {
        Console.WriteLine("Enter 1st value:");
        decimal FirstValue = decimal.Parse(Console.ReadLine());
        Console.WriteLine("Enter 2nd value:");
        decimal SecondValue = decimal.Parse(Console.ReadLine());
        Console.WriteLine(FirstValue > SecondValue ? FirstValue : SecondValue);
    }
}

