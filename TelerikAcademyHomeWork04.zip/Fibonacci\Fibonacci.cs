﻿/*
Problem 10. Fibonacci Numbers
Write a program that reads a number n and prints on the console the 
first n members of the Fibonacci sequence (at a single line, separated by
comma and space - ,) : 0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, ….
Note: You may need to learn how to use loops. 
 */
using System;
class Fibonacci
{
    static void Fib(int prev, int next, int flag, int n)
    {
        Console.Write("{0}, ", prev);
        if(flag < n){
            Fib(next, prev+next, flag+1, n);
        }
    }
    static void Main()
    {
        Console.Write("How many Fibonacci numbers you want? ");
        int Value = Int32.Parse(Console.ReadLine());
        Fib(0, 1, 1, Value);
        Console.WriteLine();
    }
}

