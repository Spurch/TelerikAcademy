﻿/*
Problem 13.* Comparing Floats
Write a program that safely compares floating-point numbers (double) with precision eps = 0.000001.
Note: Two floating-point numbers a and b cannot be compared directly by a == b because of the nature 
of the floating-point arithmetic. Therefore, we assume two numbers are equal if they are more closely 
to each other than a fixed constant eps.
*/
using System;
    class ComparingFloats
    {
        static void Main()
        {
            double presicion = 0.000001;
            //We ask the user to enter the two values we are going to compare;
            Console.WriteLine("Please enter the first floating point value using . as a delimiter:");
            //We can initialize the double variable using the direct Console input;
            double x = Double.Parse(Console.ReadLine());
            Console.WriteLine("Please enter the second floating point value using . as a delimiter:");
            double y = Double.Parse(Console.ReadLine());
            Console.WriteLine("First floating point value is: {0}", x);
            Console.WriteLine("Second floating point value is: {0}", y);
            //We check if the absolute value of the difference between the two values
            //is smaller than the desired precision;
            if (Math.Abs(x - y) < presicion)
            {
                Console.WriteLine("Using 0.000001 precision they are equal!");
            }
            else
            {
                Console.WriteLine("Using 0.000001 precision they are not equal!");
            }
        }
    }

