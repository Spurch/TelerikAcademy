﻿/*Problem 10. Employee Data
A marketing company wants to keep record of its employees. 
Each record would have the following characteristics:

    First name
    Last name
    Age (0...100)
    Gender (m or f)
    Personal ID number (e.g. 8306112507)
    Unique employee number (27560000…27569999)

Declare the variables needed to keep the information for a single
employee using appropriate primitive data types. Use descriptive names. Print the data at the console.
 */
using System;
    class EmployeeData
    {
        //Simple way of doing things:
        static void Main()
        {
            //We are using just basic variable types to
            //store the information for just one employee
            //and print it on the Console.
            string FirstName = "Charles";
            string LastName = "Dickens";
            sbyte Age = 58;
            char Gender = 'M';
            ulong ID = 0702126802;
            uint EmployeeNumber = 27560000;
            //We can use string variables as well, it depends on what we need and what we 
            //are going to do with those variables.
            //string ID = "0702126802";
            //string EmployeeNumber = "27560000";
            Console.WriteLine("Last name: {0}", LastName);
            Console.WriteLine("First name: {0}", FirstName);
            Console.WriteLine("Age: {0}\nGender:{1}" , Age, Gender);
            Console.WriteLine("ID: {0}\nEmployee number: {1}", ID, EmployeeNumber);
        }


        //TO TEST: Remove the comment tag on the next line only! Don't forget the comment all of the code above!
        /*
        //Better way of doing things:
        static void Main()
        {
            string FirstName = "Charles";
            string LastName = "Dickens";
            sbyte Age = 58;
            char Gender = 'M';
            //We know that the ID won't exceed a 10digit value.
            //Moreover most of the time we probably won't need a person ID value stored as Integer.
            //The same applies for the EmployeeNumber value, which won't exceed a 8digit value.
            //By using a char array we are using less space than both int or uint and we 
            //can always convert the values in integers if we want to make calculations.
            
            char[] ID = new char[10] {'0', '7', '0','2','1','2','6','8','0','2'};
            char[] EmployeeNumber = new char[8] { '2', '7', '5', '6', '0', '0', '0', '0'};
            //We can use string variables as well, it depends on what we need and what we 
            //are going to do with those variables.
            //string ID = "0702126802";
            //string EmployeeNumber = "27560000";
            Console.WriteLine("Last name: {0}", LastName);
            Console.WriteLine("First name: {0}", FirstName);
            Console.WriteLine("Age: {0}\nGender:{1}", Age, Gender);
            //We are using the basic string constructor new string() to convert the char array into string.
            Console.WriteLine("ID: {0}\nEmployee number: {1}", new string(ID), new string(EmployeeNumber));
        }
        //TO TEST: Remove the comment tag on the next line only!
        */
    }
