﻿/*
Problem 11. Bank Account Data
A bank account has a holder name (first name, middle name and last name), 
available amount of money (balance), bank name, IBAN, 3 credit card numbers associated with the account.
Declare the variables needed to keep the information for a single bank account using the appropriate 
data types and descriptive names. 
*/
using System;
    class BankAccountData
    {
        static void Main()
        {
            string FirstName = "Charles";
            string MiddleName = "John Huffman";
            string LastName = "Dickens";
            string BankName = "Bank Of England";
            //We are using decimal because of it's range and precision in calculations.
            decimal Balance = 12000.54M;
            string IBAN = "GB82WEST12345698765432";
            /*
             * We want to use a numeric value for the card number
             * for it can give us valuable information such as:
             * type of card, is the number valid, etc. All of which
             * is based on card number calculations.
             */
            ulong CardNumber01 = 4260821102934869;
            ulong CardNumber02 = 4281823402956848;
            ulong CardNumber03 = 4223821592967834;
            //Or we can use an array:
            //ulong[] CardNumbers = new ulong[3] {4260821102934869, 4281823402956848, 4223821592967834};
        }
    }

