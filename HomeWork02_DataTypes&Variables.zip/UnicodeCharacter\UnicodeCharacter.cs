﻿using System;
    class UnicodeCharacter
    {
        static void Main()
        {
            //Using the desired syntax:
            char CharVariable = '\u002A';
            Console.WriteLine("Using the \'\\u002A\' syntax: " + CharVariable);
            //Using direct type cast:
            int CodeValue = 42;
            char UnicodeCharValue = (char)CodeValue;
            Console.WriteLine("Using direct type cast: " + UnicodeCharValue);
        }
    }