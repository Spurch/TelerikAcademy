﻿/*
 Problem 14.* Print the ASCII Table
 Find online more information about ASCII (American Standard Code for Information Interchange)
 and write a program that prints the entire ASCII table of characters on the console (characters from 0 to 255).
 Find online more information about ASCII (American Standard Code for Information Interchange) 
 and write a program that prints the entire ASCII table of characters on the console (characters from 0 to 255).
 */
using System;
    class Program
    {
        static void Main()
        {
            //One variable to increment through the symbols.
            //And give the current symbol number.
            byte count = 0;
            //Two for loops that we use to represent the table as
            //a 2D matrix - one loop for the rows and one for the 
            //columns.
            for (int i = 0; i < 16; i++)
            {
                for (int j = 0; j < 16; j++)
                {
                    //Printing the current symbol number as symbol.
                    Console.Write((char)count + " ");
                    //We increment to the next symbol
                    //in the table
                    count++;
                }
                Console.WriteLine();
            }
        }
    }

