﻿//Problem 1. Declare Variables
//Declare five variables choosing for each of them the most appropriate of the types byte, sbyte, short, ushort, 
//int, uint, long, ulong to represent the following values: 52130, -115, 4825932, 97, -10000.
//Choose a large enough type for each number to ensure it will fit in it. Try to compile the code.

using System;

    class DeclareVariables
    {
        static void Main()
        {
            byte ByteVariable = 97;
            sbyte ShortByteVariable = -115;
            ushort UShortVariable = 52130;
            short ShortVariable = -10000;
            int IntVariable = 4825932;
        }
    }

