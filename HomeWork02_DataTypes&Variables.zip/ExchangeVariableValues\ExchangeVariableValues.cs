﻿/*Problem 9. Exchange Variable Values
Declare two integer variables a and b and assign them with 5 and 10 and 
after that exchange their values by using some programming logic.
Print the variable values before and after the exchange.
*/
using System;

    class ExchangeVariableValues
    {
        static void Main()
        {
            /* We are using the XOR based value swap algorithm to solve this problem.
             * XOR stands for Exclusive-OR - a logical function that outputs TRUE 
             * if and only if one operant is TRUE and the other is FALSE.
             */
            int a = 5;
            int b = 10;
            Console.WriteLine("a is {0} and b is {1}." , a, b);
            a ^= b;//a XOR b
            b ^= a;//b XOR a
            a ^= b;//a XOR b
            /*
             To give a simple example, consider a=11001 and b=01011
             * a XOR b = 11001 XOR 01011 = 10010 (now a is 10010)
             * b XOR a = 01011 XOR 10010 = 11001 (now b is 11001 which equals the starting value of a)
             * a XOR b = 10010 XOR 11001 = 01011 (now a is 01011 which equals the starting value of b)
             */
            Console.WriteLine("a is {0} and b is {1}.", a, b);
        }
    }
