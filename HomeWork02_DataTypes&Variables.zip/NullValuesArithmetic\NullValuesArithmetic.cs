﻿/*
Problem 12. Null Values Arithmetic
Create a program that assigns null values to an integer and to a double variable.
Try to print these variables at the console.
Try to add some number or the null literal to these variables and print the result.
*/
using System;
    class Program
    {
        static void Main()
        {
            int? AnIntegerVariable = null;
            double? ADoubleVariable = null;
            Console.WriteLine("Null value variables:");
            Console.WriteLine(AnIntegerVariable);
            Console.WriteLine(ADoubleVariable);
            AnIntegerVariable = 5;
            ADoubleVariable = 13.4;
            Console.WriteLine("Variables values:");
            Console.WriteLine(AnIntegerVariable);
            Console.WriteLine(ADoubleVariable);
        }
    }
