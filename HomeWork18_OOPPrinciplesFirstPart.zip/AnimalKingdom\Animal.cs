﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnimalKingdom
{
    class Animal
    {
        private string animalName = string.Empty;
        private double animalAge = default(double);
        private bool isFemale = default(bool);

        public Animal() { }

        public Animal(string name):
            this()
        {
            this.NAME = name;
        }

        public Animal(string name, double age):
            this(name)
        {
            this.AGE = age;
        }
        public Animal(string name, double age, bool sex) :
            this(name, age)
        {
            this.isFemale = sex;
        }

        //Method that returns the sum of the age of a given animal array.
        public static double CalculateAnimalAge(Animal[] animalArray)
        {
            double result = default(double);
            for (int i = 0; i < animalArray.Length; i++)
            {
                result += animalArray[i].AGE;
            }
            return result;
        }

        //Method that uses standard calculations to calculate the average age 
        //of a given array of animals. This method uses the CalculateAnimalAge() method.
        public static double CalculateAverageAge(Animal[] animalArray)
        {
            double result = default(double);
            double age = CalculateAnimalAge(animalArray);
            result = age / animalArray.Length;
            return result;
        }

        //Calculating the Average age of a given animal array using LINQ query.
        public static double CalculateAverageLINQ(Animal[] animalArray)
        {
            var result = (from animal in animalArray
                          select animal.AGE).Average();

            return result;
        }
        public string NAME
        {
            get
            {
                return this.animalName;
            }
            set
            {
                this.animalName = value;
            }
        }
        public double AGE
        {
            get
            {
                return this.animalAge;
            }
            set
            {
                this.animalAge = value;
            }
        }
        //NOTE: We are making the sex setter protected.
        //This way we can assure that we can set the 
        //SEX variable in the child classes(like Cat)
        //but not in the child classes of the child classes(like Kitten and TomCat).
        public bool SEX
        {
            get
            {
                return this.isFemale;
            }
            protected set
            {
                this.isFemale = value;
            }
        }
    }
}
