﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnimalKingdom
{
    class Dog: Animal, ISound
    {
        public Dog() { }

        public Dog(string name):
        base(name, 0, false) 
        { }
        public Dog(string name, double age, bool sex):
        base(name, age, sex)
        { }
        public string MakeSound()
        {
            return string.Format("Bau! Bau!");
        }
    }
}
