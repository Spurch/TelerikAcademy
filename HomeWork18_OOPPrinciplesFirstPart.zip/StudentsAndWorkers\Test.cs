﻿namespace StudentsAndWorkers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    class Test
    {
        static void Main()
        {
            List<Student> studentList = new List<Student>();
            List<Worker> workerList = new List<Worker>();
            try
            {
                Student newStudent00 = new Student("Ivan", "Todorov", 2.5);
                studentList.Add(newStudent00);
                Student newStudent01 = new Student("Petar", "Todorov", 2.0);
                studentList.Add(newStudent01);
                Student newStudent02 = new Student("Todor", "Ivanov", 4.5);
                studentList.Add(newStudent02);
                Student newStudent03 = new Student("Petar", "Nikolov", 5.5);
                studentList.Add(newStudent03);
                Student newStudent04 = new Student("Nikola", "Georgiev", 6.0);
                studentList.Add(newStudent04);
                Student newStudent05 = new Student("Georgi", "Todorov", 4.0);
                studentList.Add(newStudent05);
                Student newStudent06 = new Student("Dian", "Georgiev", 4.0);
                studentList.Add(newStudent06);
                Student newStudent07 = new Student("Stoyan", "Angelov", 3.5);
                studentList.Add(newStudent07);
                Student newStudent08 = new Student("Angel", "Petrov", 3.0);
                studentList.Add(newStudent08);
                Student newStudent09 = new Student("Dian", "Plamenov", 5.0);
                studentList.Add(newStudent09);

                Worker newWorker00 = new Worker("Ivaylo", "Todorov", 8, 5, 348);
                workerList.Add(newWorker00);
                Worker newWorker01 = new Worker("Petar", "Todorov", 12, 5, 487);
                workerList.Add(newWorker01);
                Worker newWorker02 = new Worker("Todor", "Ivanov", 4, 5, 243);
                workerList.Add(newWorker02);
                Worker newWorker03 = new Worker("Emil", "Nikolov", 8, 3, 265);
                workerList.Add(newWorker03);
                Worker newWorker04 = new Worker("Nikola", "Georgiev", 12, 3, 215);
                workerList.Add(newWorker04);
                Worker newWorker05 = new Worker("Georgi", "Todorov", 6, 5, 285);
                workerList.Add(newWorker05);
                Worker newWorker06 = new Worker("Blagovest", "Georgiev", 8, 5, 335);
                workerList.Add(newWorker06);
                Worker newWorker07 = new Worker("Stoyan", "Angelov", 4, 5, 324);
                workerList.Add(newWorker07);
                Worker newWorker08 = new Worker("Angel", "Petrov", 12, 5, 217);
                workerList.Add(newWorker08);
                Worker newWorker09 = new Worker("Dian", "Plamenov", 6, 5, 352);
                workerList.Add(newWorker09);

                Console.WriteLine("----------------------------------");
                Console.WriteLine("Students list by grade:");
                Console.WriteLine("----------------------------------");
                var studentsByGrade = studentList.OrderBy(x => x.GRADE);
                foreach (var student in studentsByGrade)
                {
                    Console.WriteLine(student.ToString());
                }

                Console.WriteLine("----------------------------------");
                Console.WriteLine("Workers list by salary per hour:");
                Console.WriteLine("----------------------------------");
                var workersByMoneyPerHour = workerList.OrderByDescending(x => x.MoneyPerHour());
                foreach (var worker in workersByMoneyPerHour)
                {
                    Console.WriteLine(worker.ToString());
                }

                //Here we will get all students and workers as Humans
                //with ToString() - Human name:...
                Console.WriteLine("----------------------------------");
                Console.WriteLine("Both lists together by name:");
                Console.WriteLine("----------------------------------");
                var allHumanList = studentList.Cast<Human>().Union(workerList.Cast<Human>());
                List<Human> result = allHumanList.OrderBy(x => x.FIRSTNAME).ThenBy(y => y.LASTNAME).ToList();
                foreach (Human human in result)
                {
                    Console.WriteLine(human.ToString());
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
                
        }
    }

}