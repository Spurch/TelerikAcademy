﻿namespace SchoolProblem
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    class Student: People, ISchool
    {
        private Guid studentId;
        public Student() { }

        public Student(string name, Guid id)
        {
            this.ID = id;
            this.NAME = name;
        }
        public override string ToString()
        {
            return string.Format("Student name: {0}\nStudent ID: {1}", this.NAME, this.ID);
        }
        public string GetComment()
        {
            return string.Format("This is a comment to the Student class!");
        }

        public Guid ID
        {
            get
            {
                return this.studentId;
            }
            set
            {
                this.studentId = value;
            }
        }
    }
}
