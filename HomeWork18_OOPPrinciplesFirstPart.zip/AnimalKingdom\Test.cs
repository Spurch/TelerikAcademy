﻿namespace AnimalKingdom
{
    using System;
    class Test
    {
        static void Main()
        {
            Kitten[] newKitten = new Kitten[5];
            newKitten[0] = new Kitten("Prejda", 5);
            newKitten[1] = new Kitten("Puh", 1.5);
            newKitten[2] = new Kitten("Glezla", 2.5);
            newKitten[3] = new Kitten("Kotka", 2);
            newKitten[4] = new Kitten("Kitty", 3.5);

            TomCat[] newTomCat = new TomCat[3];
            newTomCat[0] = new TomCat("Kittin", 1);
            newTomCat[1] = new TomCat("Glezlio", 2.5);
            newTomCat[2] = new TomCat("Erik", 3);

            Dog[] newDog = new Dog[4];
            newDog[0] = new Dog("Rexy", 3.5, false);
            newDog[1] = new Dog("Djeki", 2.5, false);
            newDog[2] = new Dog("Kami", 4.0, true);
            newDog[3] = new Dog("Tara", 1.5, true);

            Console.WriteLine("Average age using standart calc: {0}", Animal.CalculateAverageAge(newKitten));
            Console.WriteLine("Average age using LINQ calc: {0}", Animal.CalculateAverageLINQ(newKitten)); 
        }
    }
}
