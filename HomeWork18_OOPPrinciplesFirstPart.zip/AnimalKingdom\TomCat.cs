﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnimalKingdom
{
    class TomCat: Cat
    {
        public TomCat() { }
        public TomCat(string name):
        base(name, 0, false) 
        { }
        public TomCat(string name, double age) :
            base(name, age, false)
        { }
    }
}
