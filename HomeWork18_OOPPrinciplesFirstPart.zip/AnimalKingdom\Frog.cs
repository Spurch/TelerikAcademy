﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnimalKingdom
{
    class Frog: Animal, ISound
    {
        public Frog() { }
        public Frog(string name):
        base(name, 0, false) 
        { }
        public Frog(string name, double age, bool sex):
        base(name, age, sex)
        { }
        public string MakeSound()
        {
            return string.Format("Quak! Quak!");
        }
    }
}
