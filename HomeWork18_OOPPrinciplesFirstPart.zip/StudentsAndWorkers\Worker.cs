﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentsAndWorkers
{
    class Worker : Human
    {
        private int workDaysPerWeek = default(int);
        private double worksHoursPerDay = default(double);

        public Worker() { }
        public Worker(string firstName, string lastName):
            this()
        {
            this.FIRSTNAME = firstName;
            this.LASTNAME = lastName;
        }
        public Worker(string firstName, string lastName, double workHours, int workDays, double weekSalary):
            this(firstName, lastName)
        {
            this.WorkHoursPerDay = workHours;
            this.WorkDaysPerWeek = workDays;
            this.WeekSalary = weekSalary;
        }

        //We use the keyword new in order to override the base class ToString().
        //By doing so we get the Worker.ToString() when we call a Worker as Worker
        //and to get the Human.ToString() when we call a Worker as Human.
        public new string ToString()
        {
            return string.Format("Worker: {0} {1}, Week salary: {2}/{3:F2} per hour.", 
                this.FIRSTNAME, this.LASTNAME, this.WeekSalary, this.MoneyPerHour());
        }
        public double MoneyPerHour()
        {
            return WeekSalary/(WorkHoursPerDay*WorkDaysPerWeek);
        }
        public double WeekSalary { get; set; }
        public int WorkDaysPerWeek
        {
            get
            {
                return this.workDaysPerWeek;
            }
            set
            {
                if (value > 5) { 
                    throw new ArgumentOutOfRangeException("Work days per week must be 5 or less!"); }
                if (value < 0) { 
                    throw new ArgumentOutOfRangeException("Work days per week must be non-negative!"); }
                this.workDaysPerWeek = value;
            }
        }
        public double WorkHoursPerDay {
            get 
            {
                return this.worksHoursPerDay;
            }
            set
            {
                if (value > 24) { 
                    throw new ArgumentOutOfRangeException("Work hours per day must be less than 24!"); }
                if (value < 0) { 
                    throw new ArgumentOutOfRangeException("Work hours per day must be non-negative!"); }
                this.worksHoursPerDay = value;
            }
        }
    }
}
