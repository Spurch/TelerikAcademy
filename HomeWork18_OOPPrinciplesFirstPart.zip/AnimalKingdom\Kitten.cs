﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnimalKingdom
{
    class Kitten : Cat
    {
        public Kitten() { }
        public Kitten(string name):
        base(name, 0, true) 
        { }
        public Kitten(string name, double age):
            base(name, age, true)
        { }
    }
}
