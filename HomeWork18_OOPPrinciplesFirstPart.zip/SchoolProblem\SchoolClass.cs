﻿/*
 * A class that will represent the different class groups 
 * in a given school. This class contains a set of teachers
 * a set of students and a unique identifier for each SchoolClass entity.
 */
namespace SchoolProblem
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    class SchoolClass: School, ISchool
    {
        private string classId;
        private List<Teacher> teachersList;
        private List<Student> studentsList;

        public SchoolClass() { }
        public SchoolClass(string id)
        {
            this.ID = id;
            this.STUDENTS = new List<Student>();
            this.TEACHERS = new List<Teacher>();
        }
        public SchoolClass(string id, List<Teacher> teachers, List<Student> students)
        {
            this.ID = id;
            this.TEACHERS = teachers;
            this.STUDENTS = students;
        }

        public void PrintStudentsList()
        {
            foreach (var student in this.STUDENTS)
            {
                Console.WriteLine(student.ToString());
            }
        }

        public void PrintTeachersList()
        {
            foreach (var teacher in this.TEACHERS)
            {
                Console.WriteLine(teacher.ToString());
            }
        }

        public override string ToString()
        {
            return string.Format("Class ID: {0}\n", this.ID);
        }
        public new string GetComment()
        {
            return string.Format("This is a comment to the School class objects!");
        }
        public string ID
        {
            get
            {
                return this.classId;
            }
            set
            {
                this.classId = value;
            }
        }
        public List<Teacher> TEACHERS
        {
            get
            {
                return this.teachersList;
            }
            set
            {
                this.teachersList = value;
            }
        }
        public List<Student> STUDENTS
        {
            get
            {
                return this.studentsList;
            }
            set
            {
                this.studentsList = value;
            }
        }
    }
}
