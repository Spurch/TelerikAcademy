﻿namespace SchoolProblem
{
    using System;
    class Test
    {
        static void Main()
        {
            School newSchool = new School("NPMG");
            SchoolClass newClass = new SchoolClass("12");
            Discipline newDiscipline = new Discipline("Mathematics", 50, 20);
            Student newStudent = new Student("Nikolay", Guid.NewGuid());
            Teacher newTeacher = new Teacher("Bradata");
            newTeacher.DISCIPLINES.Add(newDiscipline);
            newClass.STUDENTS.Add(newStudent);
            newClass.TEACHERS.Add(newTeacher);
            Console.WriteLine(newSchool.ToString());
            Console.WriteLine(newClass.ToString());
            Console.WriteLine(newDiscipline.ToString());
            Console.WriteLine(newStudent.ToString());
            Console.WriteLine(newTeacher.ToString());
            Console.WriteLine(newTeacher.GetComment());
            
        }
    }
}
