﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolProblem
{
    class School: ISchool
    {
        private string schoolName = string.Empty;
        private List<SchoolClass> listOfClasses;

        public School() { }

        public School(string name)
        {
            this.NAME = name;
        }
        public School(string name, List<SchoolClass> listOfClasses)
        {
            this.NAME = name;
            this.CLASSES = listOfClasses;
        }

        public string GetComment()
        {
            return string.Format("This is a comment in the School class!");
        }
        public override string ToString()
        {
            return string.Format("School name: {0}\n", schoolName);
        }

        public string NAME
        {
            get
            {
                return this.schoolName;
            }
            set
            {
                this.schoolName = value;
            }
        }
        public List<SchoolClass> CLASSES
        {
            get
            {
                return this.listOfClasses;
            }
            set
            {
                this.listOfClasses = value;
            }
        }
    }
}
