﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentsAndWorkers
{
    class Student: Human
    {
        private double grade = default(double);

        public Student() { }

        public Student(string firstName, string lastName):
            this()
        {
            this.FIRSTNAME = firstName;
            this.LASTNAME = lastName;
        }
        public Student(string firstName, string lastName, double grade): 
            this(firstName, lastName)
        {
            this.GRADE = grade;
        }

        //We use the keyword new in order to override the base class ToString().
        //By doing so we get the Student.ToString() when we call a Student as Student
        //and to get the Human.ToString() when we call a Student as Human.
        public new string ToString()
        {
            return string.Format("Student: {0} {1}, Grade: {2}", 
                this.FIRSTNAME, this.LASTNAME, this.GRADE);
        }
        public double GRADE
        {
            get
            {
                return this.grade;
            }
            set
            {
                if (value > 6) { throw new ArgumentOutOfRangeException("Grade must be 6 or less!"); }
                if (value < 0) { throw new ArgumentOutOfRangeException("Grade must be non-negative!"); }
                this.grade = value;
            }
        }
    }
}
