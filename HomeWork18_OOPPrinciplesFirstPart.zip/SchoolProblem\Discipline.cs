﻿namespace SchoolProblem
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    class Discipline : ISchool
    {
        private string disciplineName;
        private double numberOfLectures;
        private double numberOfExercises;

        public Discipline() { }

        public Discipline(string name)
        {
            this.NAME = name;
        }

        public Discipline(string name, int lectures, int exercises)
        {
            this.NAME = name;
            this.LECTURES = lectures;
            this.EXERCISES = exercises;
        }

        public override string ToString()
        {
            return string.Format("Discipline: {0}\nNumber of lectures:{1}\nNumber of exercises:{2}\n", this.NAME, this.LECTURES, this.EXERCISES);
        }
        public string GetComment()
        {
            return string.Format("This is a comment to the Discipline objects!");
        }

        public string NAME
        {
            get
            {
                return this.disciplineName;
            }
            set
            {
                this.disciplineName = value;
            }
        }

        public double LECTURES
        {
            get
            {
                return this.numberOfLectures;
            }
            set
            {
                this.numberOfLectures = value;
            }
        }
        public double EXERCISES
        {
            get
            {
                return this.numberOfExercises;
            }
            set
            {
                this.numberOfExercises = value;
            }
        }
    }
}
