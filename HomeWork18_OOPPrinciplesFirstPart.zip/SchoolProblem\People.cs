﻿/*
 * A class that will hold a person's name. 
 * Both Student and Teacher will inherit this class.
 */
namespace SchoolProblem
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    class People
    {
        private string personName = string.Empty;
        public People() { }

        public People(string name)
        {
            this.personName = name;
        }
        public override string ToString()
        {
            return string.Format("Person name: {0}", this.NAME);
        }
        public string NAME
        {
            get
            {
                return this.personName;
            }
            set
            {
                this.personName = value;
            }
        }
    }
}
