﻿namespace SchoolProblem
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    class Teacher: People, ISchool
    {
        private List<Discipline> disciplineList;
        public Teacher() { }

        public Teacher(string name)
        {
            this.NAME = name;
            this.DISCIPLINES = new List<Discipline>();
        }
        public Teacher(string name, List<Discipline> disciplineList)
        {
            this.NAME = name;
            this.DISCIPLINES = disciplineList;
        }

        public static double GetTeacherLectureHours(Teacher teacher)
        {
            double resultHours = default(double);
            foreach (var dics in teacher.DISCIPLINES)
            {
                resultHours += dics.LECTURES;
            }

            return resultHours;
        }
        public static double GetTeacherExerciseHours(Teacher teacher)
        {
            double resultHours = default(double);
            foreach (var dics in teacher.DISCIPLINES)
            {
                resultHours += dics.EXERCISES;
            }

            return resultHours;
        }

        public override string ToString()
        {
            return string.Format("Teacher name: {0}\nTotal amount of lecture hours: {1}\n", 
                this.NAME, GetTeacherLectureHours(this));
        }
        public string GetComment()
        {
            return string.Format("This is a comment to the Teacher class!");
        }

        public List<Discipline> DISCIPLINES
        {
            get
            {
                return this.disciplineList;
            }
            set
            {
                this.disciplineList = value;
            }
        }
    }
}
