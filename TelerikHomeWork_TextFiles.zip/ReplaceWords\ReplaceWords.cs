﻿/*
 Problem 8. Replace whole word
    Modify the solution of the previous problem to replace only whole words (not strings). 
 */
using System;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
class ReplaceWords
{
    static void Main()
    {
        string Start = "sit";
        string Finish = Start.ToUpper();

        StringBuilder builder = new StringBuilder();
        builder.Append(File.ReadAllText("..//..//InputFile.txt"));
        string Text = builder.ToString();
        Text = Regex.Replace(Text, @"\b" + Start + @"\b", Finish);

        File.WriteAllText("..//..//InputFile.txt", Text);
    }
}

