﻿/*
 Problem 1. Odd lines
    Write a program that reads a text file and prints on the console its odd lines. 
 */
using System;
using System.IO;
class OddLines
{
    static void Main()
    {
        StreamReader sr = new StreamReader("..//..//OddLines.txt");
        int i = 1;
        while (!sr.EndOfStream)
        {
            if (i % 2 == 1)
            {
                Console.WriteLine(sr.ReadLine());
            }
            else
            {
                sr.ReadLine();
            }
            i++;
        }
        sr.Close();
    }
}

