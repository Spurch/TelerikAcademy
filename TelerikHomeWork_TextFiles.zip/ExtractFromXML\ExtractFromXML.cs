﻿/*
 Problem 10. Extract text from XML
    Write a program that extracts from given XML file all the text without the tags.

Example:
<?xml version="1.0">
    <student>
        <name>Pesho</name>
        <age>21</age>
        <interests count="3">
            <interest>Games</interest>
            <interest>C#</interest>
            <interest>Java</interest>
        </interests>
    </student> 
 */
using System;
using System.IO;
using System.Text;
class ExtractFromXML
{
    static void Main()
    {
        StreamReader InputReader = new StreamReader("..//..//InputFile.txt");
        StringBuilder builder = new StringBuilder();
        char temp = ' ';
        while (!InputReader.EndOfStream)
        {
            do
            {
                temp = (char)InputReader.Read();
            } while (temp != '>');
            temp = (char)InputReader.Read();
            if (temp != '<')
            {
                builder.Append(temp);
                temp = (char)InputReader.Read();
                while (temp != '<' && temp != '/' && !InputReader.EndOfStream)
                {
                    builder.Append(temp);
                    temp = (char)InputReader.Read();
                }
                builder.Append(" ");
            }
        }
        InputReader.Close();

        StreamWriter ResultWriter = new StreamWriter("..//..//Result.txt");
        ResultWriter.WriteLine(builder.ToString());
        ResultWriter.Close();
    }
}

