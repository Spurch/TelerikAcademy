﻿/*
 Problem 6. Save sorted names
 Write a program that reads a text file containing
 a list of strings, sorts them and saves them to another text file. 
 */
using System;
using System.Collections.Generic;
using System.IO;
class SortedNames
{
    static void Main()
    {
        StreamReader InputReader = new StreamReader("..//..//InputFile.txt");
        StreamWriter ResultWriter = new StreamWriter("..//..//Result.txt");
        List<string> ListOfNames = new List<string>();
        while (!InputReader.EndOfStream)
        {
            ListOfNames.Add(InputReader.ReadLine());
        }
        ListOfNames.Sort();

        foreach (var Name in ListOfNames)
        {
            ResultWriter.WriteLine(Name);
        }
        ResultWriter.Close();
        InputReader.Close();
    }
}

