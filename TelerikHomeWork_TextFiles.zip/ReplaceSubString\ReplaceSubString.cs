﻿/*
 Problem 7. Replace sub-string
 Write a program that replaces all occurrences of the sub-string start with
 the sub-string finish in a text file.
 Ensure it will work with large files (e.g. 100 MB). 
 */
using System;
using System.IO;
using System.Text;
class Program
{
    static void Main()
    {
        string Start = "m";
        string Finish = "$*$";

        StringBuilder builder = new StringBuilder();
        builder.Append(File.ReadAllText("..//..//InputFile.txt"));
        builder.Replace(Start, Finish);

        File.WriteAllText("..//..//InputFile.txt", builder.ToString());
    }
}

