﻿/*
 Problem 4. Compare text files
    Write a program that compares two text files line by line and prints the number 
    of lines that are the same and the number of lines that are different.
    Assume the files have equal number of lines. 
 */
using System;
using System.IO;
class CompareTextFiles
{
    static void Main()
    {
        StreamReader FirstReader = new StreamReader("..//..//FirstFile.txt");
        StreamReader SecondReader = new StreamReader("..//..//SecondFile.txt");
        int SimilarCounter = 0;
        int DiffCounter = 0;
        string a = "";
        string b = "";
        while (!FirstReader.EndOfStream)
        {
            a = FirstReader.ReadLine();
            b = SecondReader.ReadLine();
            if (a.Equals(b))
            {
                SimilarCounter++;
            }
            else
            {
                DiffCounter++;
            }
        }
        FirstReader.Close();
        SecondReader.Close();
        Console.WriteLine("There are {0} similar lines and {1} different lines!", SimilarCounter, DiffCounter);
    }
}

