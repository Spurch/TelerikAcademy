﻿/*
 Problem 3. Line numbers
    Write a program that reads a text file and inserts line numbers in front of each of its lines.
    The result should be written to another text file. 
 */
using System;
using System.IO;
using System.Text;
class LineNumbers
{
    static void Main()
    {
        StreamReader InputReader = new StreamReader("..//..//InputFile.txt");
        StreamWriter ResultWriter = new StreamWriter("..//..//Result.txt");
        StringBuilder builder = new StringBuilder();
        int i = 1;
        while (!InputReader.EndOfStream)
        {
            builder.Clear();
            builder.Append(i + ". " + InputReader.ReadLine());
            ResultWriter.WriteLine(builder.ToString());
            i++;
        }

        ResultWriter.Close();
        InputReader.Close();
    }
}

