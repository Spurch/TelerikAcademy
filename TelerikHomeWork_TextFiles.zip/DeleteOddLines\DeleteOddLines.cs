﻿/*
 Problem 9. Delete odd lines
    Write a program that deletes from given text file all odd lines.
    The result should be in the same file. 
 */
using System;
using System.IO;
using System.Text;
class DeleteOddLines
{
    static void Main()
    {
        StreamReader InputReader = new StreamReader("..//..//InputFile.txt");
        StringBuilder builder = new StringBuilder();
        int i = 1;
        while (!InputReader.EndOfStream)
        {
            if (i % 2 == 0)
            {
                builder.AppendLine(InputReader.ReadLine());
            }
            else
            {
                InputReader.ReadLine();
            }
            i++;
        }
        InputReader.Close();

        StreamWriter ResultWriter = new StreamWriter("..//..//InputFile.txt");
        ResultWriter.WriteLine(builder.ToString());
        ResultWriter.Close();
        
    }
}

