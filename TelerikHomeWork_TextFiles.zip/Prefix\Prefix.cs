﻿/*
 Problem 11. Prefix "test"
    Write a program that deletes from a text file all words that start with the prefix test.
    Words contain only the symbols 0…9, a…z, A…Z, _. 
 */
using System;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Linq;
using System.Collections.Generic;
class Prefix
{
    public static bool CheckCurrentLine(string Str)
    {
        /*
         * We split the current line of the text to words.
         */
        List<string> Words = Str.Split(new[] { ' ', ',', '.', '!', '?', '-' }).ToList();
        bool isValid = false;
        /*
         * If we detect a word with a symbol different than letter, digit or _
         * the method returns False and the CurrentLine will be excluded in the Result.txt
         */
        foreach (var Word in Words)
        {
            //We parse the current word to a char array.
            char[] WordToLetter = Word.ToCharArray();
            for (int i = 0; i < WordToLetter.Length; i++)
            {
                //Then we check the content of the word/char array.
                if (!char.IsLetterOrDigit(WordToLetter[i]) && WordToLetter[i] != '_')
                {
                    isValid = false;
                    return isValid;
                }
                else
                {
                    //If everything is OK we return TRUE.
                    isValid = true;
                }
            }
        }
        return isValid;
    }
    static void Main()
    {
        try
        {
            StringBuilder ResultBuilder = new StringBuilder();

            using (StreamReader InputReader = new StreamReader("..//..//InputFile.txt"))
            {
                string CurrentLine;
                //While we haven't reached the EOF.
                while (!InputReader.EndOfStream)
                {
                    CurrentLine = InputReader.ReadLine();
                    //If the current line is in valid format we execute the replace.
                    if (CheckCurrentLine(CurrentLine))
                    {
                        var CurrentMatch = Regex.Replace(CurrentLine, @"\btest\w+\b ", string.Empty);
                        ResultBuilder.AppendLine(CurrentMatch);
                    }

                }
            }

            using (StreamWriter OutputWriter = new StreamWriter("..//..//Result.txt"))
            {
                OutputWriter.WriteLine(ResultBuilder);
            }
        }
        catch (ArgumentException argsEx)
        {
            Console.WriteLine(argsEx.Message);
        }
        catch (FileNotFoundException FnFEx)
        {
            Console.WriteLine(FnFEx.Message);
        }

    }
}

