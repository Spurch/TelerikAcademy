﻿/*
 Problem 2. Concatenate text files
    Write a program that concatenates two text files into another text file.
 */
using System;
using System.IO;
using System.Text;
class ConcatenateFiles
{
    static void Main()
    {
        StreamReader FirstReader = new StreamReader("..//..//FirstFileToConcate.txt");
        StreamWriter ResultWriter = new StreamWriter("..//..//Result.txt");
        while (!FirstReader.EndOfStream)
        {
            ResultWriter.WriteLine(FirstReader.ReadLine());
        }
     
        StreamReader SecondReader = new StreamReader("..//..//SecondFileToConcate.txt");
        while (!SecondReader.EndOfStream)
        {
            ResultWriter.WriteLine(SecondReader.ReadLine());
        }

        ResultWriter.Close();
        FirstReader.Close();
        SecondReader.Close();
    }
}

