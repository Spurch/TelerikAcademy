﻿/*
 Problem 13. Count words
    Write a program that reads a list of words from the file words.txt and finds how many times each of the words is contained in another file test.txt.
    The result should be written in the file result.txt and the words should be sorted by the number of their occurrences in descending order.
    Handle all possible exceptions in your methods. 
 */
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Linq;

namespace CountWords
{
    class CountWords
    {
        static void Main()
        {
            try
            {
                StringBuilder ResultBuilder = new StringBuilder();
                StringBuilder builder = new StringBuilder();
                //We read the whole text.
                builder.Append(File.ReadAllText("..//..//test.txt"));

                //We convert it to string and use the string to create an array of words.
                string Text = builder.ToString();
                string[] TextSource = Text.Split(new char[] { '.', '?', '!', ' ', ';', ':', ',' }, StringSplitOptions.RemoveEmptyEntries);
                var ListOfWords = new List<WordCount>();

                //We read the words from the words.txt file and add them to 
                //a composite list of type WordCount.
                using (StreamReader WordsReader = new StreamReader("..//..//words.txt"))
                {
                    while (!WordsReader.EndOfStream)
                    {
                        //We create a new WordCount object for each word in the list
                        //and initialize it with 0 counts.
                        ListOfWords.Add(new WordCount(0, WordsReader.ReadLine()));
                    }
                    for (int i = 0; i < ListOfWords.Count; i++)
                    {
                        //For each word in the list we check how many times the given word 
                        //appears in the array of words from the test.txt .
                        var matchQuery = from word in TextSource
                                         where word == ListOfWords[i].Word
                                         select word;
                        //We then increment each word counter accordingly.
                        ListOfWords[i].Counter += matchQuery.Count();
                    }
                }

                //We sort the updated list by the Counter in descending order.
                ListOfWords = (from word in ListOfWords
                               orderby word.Counter descending
                               select word).ToList();

                //We Append the results for each word in the list to a StringBuilder.
                foreach (var word in ListOfWords)
                {
                    ResultBuilder.AppendLine(word.Word + " - " + word.Counter + " times.");
                }
                //We write the StringBuilder to the result file.
                using (StreamWriter OutputWriter = new StreamWriter("..//..//result.txt"))
                {
                    OutputWriter.WriteLine(ResultBuilder);
                }
            }
            catch (ArgumentException argsEx)
            {
                Console.WriteLine(argsEx.Message);
            }
            catch (FileNotFoundException FnFEx)
            {
                Console.WriteLine(FnFEx.Message);
            }
        }
    }

}