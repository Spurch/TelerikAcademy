﻿/*
Problem 9. Trapezoids
Write an expression that calculates trapezoid's area by given sides a and b and height h. 
 */
using System;
class Trapezoids
{
    static void Main()
    {
        Console.WriteLine("Enter side A:");
        double SideA = double.Parse(Console.ReadLine());
        Console.WriteLine("Enter side B:");
        double SideB = double.Parse(Console.ReadLine());
        Console.WriteLine("Enter height:");
        double Height = double.Parse(Console.ReadLine());

        double Area = 0.5 * (SideA + SideB) * Height;
        Console.WriteLine("The area is {0}", Area);
    }
}

