﻿/*
 * Problem 1. Odd or Even Integers
Write an expression that checks if given integer is odd or even.
 */
using System;
    class OddOrEven
    {
        static void Main()
        {
            Console.WriteLine("Please enter a number:");
            int NumberToCheck = Int32.Parse(Console.ReadLine());
            if (Math.Abs(NumberToCheck) % 2 == 0)
            {
                Console.WriteLine("The number is even!");
            }
            else
            {
                Console.WriteLine("The number is odd!");
            }
        }
    }

