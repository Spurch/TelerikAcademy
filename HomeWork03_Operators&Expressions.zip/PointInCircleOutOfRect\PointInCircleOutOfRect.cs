﻿/*
Problem 10. Point Inside a Circle & Outside of a Rectangle
Write an expression that checks for given point (x, y) if it is within the circle 
K({1, 1}, 1.5) and out of the rectangle R(top=1, left=-1, width=6, height=2).
 */
using System;
class PointInCircleOutOfRect
{
    static void Main()
    {
        //Setting the starting paremeters.
        float CircleCenterX = 1.0F;
        float CircleCenterY = 1.0F;
        float CircleRadius = 1.5F;

        //Getting user input.
        Console.WriteLine("Enter x coordinate: ");
        float x = float.Parse(Console.ReadLine());
        Console.WriteLine("Enter y coordinate: ");
        float y = float.Parse(Console.ReadLine());

        //Calculations needed to determine if the point is inside the circle.
        double XCalc = Math.Pow((x - CircleCenterX), 2);
        double YCalc = Math.Pow((y - CircleCenterY), 2);

        //If this statement is true then the point is inside the circle.
        if ((XCalc + YCalc) <= Math.Pow(CircleRadius, 2))
        {
            //If this statement is true and the point is
            //inside the circle and outside of the rectangle.
            if (y > 1)
            {
                Console.WriteLine("yes");
            }
            else
            {
                Console.WriteLine("no");
            }
        }
        else
        {
            Console.WriteLine("no");
        }
    }
}

