﻿/*
 Problem 12. Extract Bit from Integer
 Write an expression that extracts from given integer n the value of given bit at index p. 
 */
using System;
class ExtractBitFromInteger
{
    static void Main()
    {
        Console.WriteLine("Enter integer value:");
        int Value = Int32.Parse(Console.ReadLine());
        Console.WriteLine("Enter Bit position:");
        int Pos = Int32.Parse(Console.ReadLine());

        int Mask = 1 << Pos;
        int ValueMask = Value & Mask;
        int Bit = ValueMask >> Pos;
        Console.WriteLine("Bit#{0} is: {1}",Pos, Bit);
        /*
        //We can use a string based approach to solve the problem:
        //We use the Convert class to get the binary representation on the number.
        //After that we use PadLeft method to add all the leading 0s otherwise
        //we will get the binary of the number without the leading 0s.
        string BinaryValue = Convert.ToString(Value, 2).PadLeft(16, '0');
        Console.WriteLine("Integer value is: {0}", Value);
        Console.WriteLine("Binary value is: {0}", BinaryValue);
        //Getting the bit at position #Pos (Remember that a string is just an array of chars).
        Console.WriteLine("Bit#{0} is: {1}", Pos, BinaryValue[BinaryValue.Length - (Pos+1)]);
        */ 
    }
}

