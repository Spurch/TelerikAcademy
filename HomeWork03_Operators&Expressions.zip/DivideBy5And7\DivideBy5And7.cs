﻿/*
 * Problem 3. Divide by 7 and 5
Write a Boolean expression that checks for given integer 
if it can be divided (without remainder) by 7 and 5 at the same time.
 */
using System;
class DivideBy5And7
{
    static void Main()
    {
        Console.WriteLine("Please enter a number to check:");
        int NumberToCheck = Int32.Parse(Console.ReadLine());
        if(NumberToCheck%5==0 && NumberToCheck%7==0)
        {
            Console.WriteLine("The number {0} can be divided by 7 and 5." , NumberToCheck);
        }
        else
        {
            Console.WriteLine("The number {0} can't be divided by 7 and 5.", NumberToCheck);
        }
    }
}

