﻿/*
 *Problem 6. Four-Digit Number

    Write a program that takes as input a four-digit number in format abcd (e.g. 2011) and performs the following:
        Calculates the sum of the digits (in our example 2 + 0 + 1 + 1 = 4).
        Prints on the console the number in reversed order: dcba (in our example 1102).
        Puts the last digit in the first position: dabc (in our example 1201).
        Exchanges the second and the third digits: acbd (in our example 2101).

The number has always exactly 4 digits and cannot start with 0. 
 */
using System;
class FourDigitNumber
{
    static void Main()
    {
        int sum = 0;
        Console.WriteLine("Please enter a four-digit number(no starting 0 allowed!):");
        char[] Number = new char[4];

        //Reading the number from the console input.
        for (int i = 0; i < 4; i++)
        {
            Number[i] = (char)Console.Read();
        }

        //Getting the sum of the digits.
        for (int i = 0; i < 4; i++)
        {
            sum += Int32.Parse(Number[i].ToString());
        }
        Console.WriteLine("The sum of the digits is: {0}" , sum);

        //Printing the Number in reverse order.
        Console.Write("Digits in reverse order: ");
        for (int i = 3; i >= 0; i--)
        {
            Console.Write(Number[i]);
        }
        Console.WriteLine();

        //Switching the 2nd and the 3th digits.
        //Using a temp array for this operation 
        //in order to preserve the original array.
        char[] TempArr = new char[4];
        Console.Write("Second and third digits exchanged: ");
        //Using the build-in Copy method of the Array class.
        Array.Copy(Number , TempArr, 4);
        //Basic 2 variables swap using a third one.
        char x = TempArr[1];
        TempArr[1] = TempArr[2];
        TempArr[2] = x;
        Console.WriteLine(TempArr);

        //Putting the last digit at first position.
        //This requires some more digit swapping.
        Console.Write("Last digit at first place: ");
        char SwapVar = Number[0];
        Number[0] = Number[3];
        Number[3] = Number[2];
        Number[2] = Number[1];
        Number[1] = SwapVar;
        Console.WriteLine(Number);
    }
}

