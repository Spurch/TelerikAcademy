﻿/*
 * Problem 7. Point in a Circle
 * Write an expression that checks if given point (x, y) is inside a circle K({0, 0}, 2). 
 */
using System;
class PointInsideCircle
{
    static void Main()
    {
        float CircleCenterX = 0.0F;
        float CircleCenterY = 0.0F;
        float CircleRadius = 2.0F;

        Console.WriteLine("Enter x coordinate: ");
        float x = float.Parse(Console.ReadLine());
        Console.WriteLine("Enter y coordinate: ");
        float y = float.Parse(Console.ReadLine()); 

        double XCalc = Math.Pow((x - CircleCenterX),2);
        double YCalc = Math.Pow((y - CircleCenterY),2);
        Console.WriteLine(XCalc + YCalc <= Math.Pow(CircleRadius,2));
    }
}

