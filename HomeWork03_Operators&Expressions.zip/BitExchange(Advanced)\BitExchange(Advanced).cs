﻿/*
Problem 16.** Bit Exchange (Advanced)
Write a program that exchanges bits {p, p+1, …, p+k-1} with bits {q, q+1, …, q+k-1} 
of a given 32-bit unsigned integer.
The first and the second sequence of bits may not overlap. 
 */
using System;
class BitExchangeAdvanced
{
    static void Main()
    {
        Console.WriteLine("Enter integer value:");
        long Value = Int64.Parse(Console.ReadLine());
        Console.WriteLine("Enter first sequence starting position:");
        int i = Int32.Parse(Console.ReadLine());
        Console.WriteLine("Enter second sequence starting position:");
        int j = Int32.Parse(Console.ReadLine());
        Console.WriteLine("Enter the number of bits to swap:");
        int n = Int32.Parse(Console.ReadLine());
        long ResultValue = 0;

        //If the difference between the two starting positions is smaller
        //or equal to the step we are going to have an overlap.
        if (Math.Abs(i - j) <= n)
        {
            Console.WriteLine("Overlapping!");
        }
        else
        {
            long TempCalc = ((Value >> i) ^ (Value >> j)) & ((1 << n) - 1);
            ResultValue = Value ^ ((TempCalc << i) | (TempCalc << j));
            Console.WriteLine(ResultValue);
        }
    }
}

