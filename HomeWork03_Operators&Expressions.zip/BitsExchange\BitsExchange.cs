﻿/*
 Problem 15.* Bits Exchange
 Write a program that exchanges bits 3, 4 and 5 with 
 bits 24, 25 and 26 of given 32-bit unsigned integer.
 */
using System;
class BitsExchange
{
    static void Main()
    {
        Console.WriteLine("Enter integer value:");
        long Value = Int64.Parse(Console.ReadLine());
        int i = 3;
        int j = 24;
        int n = 3;
        long ResultValue = 0;

        long TempCalc = ((Value >> i) ^ (Value >> j)) & ((1 << n) - 1);
        ResultValue = Value ^ ((TempCalc << i) | (TempCalc << j));
        Console.WriteLine(ResultValue);
       
    }
}

