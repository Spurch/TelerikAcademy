﻿/*Problem 5. Third Digit is 7?
Write an expression that checks for given integer if its third digit from right-to-left is 7.
 */
using System;
class DigitCheck
{
    static void Main()
    {
        Console.WriteLine("Enter an integer to check:");
        string NumberToCheck = Console.ReadLine();
        bool flag = false;
        if(NumberToCheck.Length >= 3)
        {
            flag = (NumberToCheck[NumberToCheck.Length - 3] == '7');
            Console.WriteLine(flag);
        }else{
            Console.WriteLine(flag);
        }
    }
}

