﻿/*
 * Problem 2. Gravitation on the Moon
The gravitational field of the Moon is approximately 17% of that on the Earth.
Write a program that calculates the weight of a man on the moon by a given weight on the Earth.
 */
using System;
class MoonGravity
{
    static void Main()
    {
        Console.WriteLine("Please enter the person's weight:");
        float EarthWeight = float.Parse(Console.ReadLine());
        float MoonWeight = (EarthWeight*17)/100;
        Console.WriteLine("The person will weight on the moon will be: {0} ", MoonWeight);
    }
}

