﻿/*
Problem 11. Bitwise: Extract Bit #3

    Using bitwise operators, write an expression for finding the value of the bit #3 of a given unsigned integer.
    The bits are counted from right to left, starting from bit #0.
    The result of the expression should be either 1 or 0.
 
 */
using System;
class BitWiseExtractBit
{
    static void Main()
    {
        Console.WriteLine("Enter integer value:");
        int Value = Int32.Parse(Console.ReadLine());

        int Mask = 1 << 3;
        int ValueMask = Value & Mask;
        int Bit = ValueMask >> 3;
        Console.WriteLine("Bit#3 is: {0}", Bit);
        /*
        //Or we can use a string based approach to solve the problem:
        //We use the Convert class to get the binary representation on the number.
        //After that we use PadLeft method to add all the leading 0s otherwise
        //we will get the binary of the number without the leading 0s.
        string BinaryValue = Convert.ToString(Value, 2).PadLeft(16, '0');
        Console.WriteLine("Integer value is: {0}", Value);
        Console.WriteLine("Binary value is: {0}",BinaryValue);
        //Getting the bit at position #3 (Remember that a string is just an array of chars).
        Console.WriteLine("Bit#3 is: {0}", BinaryValue[BinaryValue.Length-4]);
        */
    }
}

