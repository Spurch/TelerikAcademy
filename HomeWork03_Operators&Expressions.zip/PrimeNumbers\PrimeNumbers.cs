﻿/*
Problem 8. Prime Number Check
    Write an expression that checks if given positive integer number n (n <= 100) is prime 
 * (i.e. it is divisible without remainder only to itself and 1).
    Note: You should check if the number is positive
 */
using System;
class PrimeNumbers
{
    static void Main()
    {
        Console.WriteLine("Enter a positive number to check(between 0 and 100): ");
        int NumberToCheck = Int32.Parse(Console.ReadLine());
        bool flag = false;
        if (NumberToCheck <= 1)
        {
            Console.WriteLine(flag);
        }else if(NumberToCheck == 2)
        {
            Console.WriteLine(!flag);
        }
        else if (NumberToCheck > 2 && NumberToCheck <= 7)
        {
            if (NumberToCheck % 2 == 0)
            {
                Console.WriteLine(flag);
            }
            else
            {
                Console.WriteLine(!flag);
            }
        }
        else
        {
            int NumberSqrt = (int)Math.Sqrt(NumberToCheck);
            for (int i = 2; i < NumberSqrt; i++)
            {
                if (NumberToCheck % i == 0)
                {
                    flag = false;
                }
                else
                {
                    flag = true;
                }
            }
            Console.WriteLine(flag);
        }
    }
}

