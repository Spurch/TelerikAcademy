﻿/*
 *Problem 4. Rectangles
Write an expression that calculates rectangle’s perimeter and area by given width and height.
 */
using System;
class Rectangle
{
    static void Main()
    {
        Console.WriteLine("Enter rectangle width:");
        double RectWidth = Double.Parse(Console.ReadLine());
        Console.WriteLine("Enter rectangle height:");
        double RectHeight = Double.Parse(Console.ReadLine());
        double RectArea = RectHeight * RectWidth;
        double RectPerm = 2 * RectHeight + 2 * RectWidth;
        Console.WriteLine("Width: {0}\nHeight: {1}\nArea: {2}\nPerimeter: {3}" , RectWidth , RectHeight , RectArea , RectPerm);
    }
}

