﻿//Problem 7. Print First and Last Name.
//Create console application that prints your first and last name, each at a separate line.
using System;

namespace FirstLastName
{
    class FirstLastName
    {
        static void Main()
        {
            Console.WriteLine("Terry");
            Console.WriteLine("Pratchett");
        }
    }
}
