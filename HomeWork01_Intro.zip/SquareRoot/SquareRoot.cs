﻿//Problem 8. Square root.
//Create a console application that calculates and prints the square root of the number 12345.
using System;

namespace SquareRoot
{
    class SquareRoot
    {
        static void Main()
        {
            double sqrt = Math.Sqrt(12345);
            Console.WriteLine(sqrt);
        }
    }
}
