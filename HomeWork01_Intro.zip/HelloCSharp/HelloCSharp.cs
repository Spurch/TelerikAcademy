﻿//4. Hello World.
//Create, compile and run a “Hello C#” console application.
using System;

namespace HelloCSharp
{
    class HelloCSharp
    {
        static void Main()
        {
            Console.WriteLine("Hello C#");
        }
    }
}
