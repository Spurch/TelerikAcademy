﻿//Problem 14. Current Date and Time.
//Create a console application that prints the current date and time.
using System;

namespace CurrentDateAndTime
{
    class CurrentDateAndTime
    {
        static void Main()
        {
            Console.WriteLine(DateTime.Today);
        }
    }
}
