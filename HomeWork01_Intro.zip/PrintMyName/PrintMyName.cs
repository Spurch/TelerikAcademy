﻿//Problem 5. Print Your Name.
//Application to print name.
using System;

namespace PrintMyName
{
    class PrintMyName
    {
        static void Main()
        {
            Console.WriteLine("Neil Geiman");
        }
    }
}
