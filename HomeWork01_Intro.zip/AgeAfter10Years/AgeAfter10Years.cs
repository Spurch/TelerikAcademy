﻿//Problem 15. Age after 10 Years.
//Write a program to read your birthday from the console and 
//print how old you are now and how old you will be after 10 years.
using System;

namespace AgeAfter10Years
{
    class AgeAfter10Years
    {
        static void Main()
        {
            string BirthDate = Console.ReadLine();
            DateTime BDate = DateTime.Parse(BirthDate);
            DateTime CurrentDate = DateTime.Now;
            if (BDate < CurrentDate)
            {
                TimeSpan Span = CurrentDate - BDate;
                int years = (int)(Span.TotalDays / 365);
                Console.WriteLine("You are {0} years old. After 10 years you will be {1} years old.", years, years+10);
            }
            else if (BDate > CurrentDate)
            {
                Console.WriteLine("You've not been born yet!");
            }
        }
    }
}
