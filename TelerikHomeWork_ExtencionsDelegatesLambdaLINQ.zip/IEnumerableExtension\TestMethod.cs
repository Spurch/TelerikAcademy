﻿namespace IEnumerableExtension
{
    using System;
    using IEnumerableExtensions;
    class TestMethod
    {
        public static void Main()
        {
            int[] arr = new int[10];
            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = i+1;
            }
            Console.WriteLine("Sum is: {0}", arr.Sum(x => x));
            Console.WriteLine("Product is: {0}", arr.Product(x => x));
            Console.WriteLine("The avarage is: {0}", arr.Average(x => x));
            Console.WriteLine("Min is: {0}", arr.Min());
            Console.WriteLine("Max is: {0}", arr.Max());
        }
    }
}
