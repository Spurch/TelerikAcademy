﻿namespace Student
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    class StudentMethods
    {
        //PROBLEM 3
        public static Student[] FirstBeforeLast(Student[] studentArray)
        {
            if (studentArray.Length == 0) { throw new ArgumentException("Array is empty!"); }
            var resultStudents = from student in studentArray
                                 where student.FIRSTNAME.CompareTo(student.LASTNAME) < 0
                                 select student;
            return resultStudents.ToArray();
        }

        //PROBLEM 4
        public static string[] SortByAge(Student[] studentArray, int startAge, int endAge)
        {
            if (studentArray.Length == 0) { throw new ArgumentException("Array is empty!"); }
            if (startAge <= 0 || endAge <= 0) { throw new ArgumentException("Age boundaries must be non-negative and non-zero!"); }
            if (startAge > endAge) { throw new ArgumentException("Starting age must be smaller than end age!"); }
            var resultStudent = from student in studentArray
                                where student.AGE > startAge && student.AGE < endAge
                                from x in new string[] { student.FIRSTNAME, student.LASTNAME }
                                select x;
            return resultStudent.ToArray();
        }

        //PROBLEM 5
        //Lambda expression variant.
        public static Student[] SortByName(Student[] studentArray)
        {
            var sortedStudentArray = studentArray.OrderByDescending(x => x.FIRSTNAME).ThenByDescending(y => y.LASTNAME);
            return sortedStudentArray.ToArray();
        }

        //PROBLEM 5
        //LINQ expression variant.
        public static Student[] SortByNameLINQ(Student[] studentArray)
        {
            var sortedStudentArray = (from student in studentArray
                                      orderby student.FIRSTNAME, student.LASTNAME descending
                                      select student).ToArray();
            return sortedStudentArray.ToArray();
        }

        //PROBLEM 9
        public static List<Student> ExtractByGroup(List<Student> studentList, string value)
        {
            var resultStudentList = (from student in studentList
                                     where student.GROUP.NUMBER.Equals(value)
                                     select student);
            return resultStudentList.ToList();
        }

        //PROBLEM 10
        public static List<Student> ExtractByGroupExtension(List<Student> studentList, string value)
        {
            var resultStudentList = studentList.Where(x => x.GROUP.NUMBER.Equals(value)).OrderBy(x => x.FIRSTNAME);
            return resultStudentList.ToList();
        }
        
        //PROBLEM 11
        public static Student[] ExtractByMail(Student[] studentArray, string value)
        {
            var resultStudentArray = (from student in studentArray
                                      where student.MAIL.Substring(student.MAIL.Length - value.Length, value.Length).Equals(value)
                                      select student);
            return resultStudentArray.ToArray();
        }

        //PROBLEM 12
        public static Student[] ExtractByPhone(Student[] studentArray, string value)
        {
            var resultStudentArray = (from student in studentArray
                                      where student.MOBILE.Substring(0, value.Length).Equals(value)
                                      select student);
            return resultStudentArray.ToArray();
        }

        //PROBLEM 13
        public static void ExtractByMarks(Student[] studentArray, double value)
        {
            var resultStudentArray = (from student in studentArray
                                      where student.MARKS.Contains(value)
                                      select new { FullName = student.FIRSTNAME + " " + student.LASTNAME, Marks = student.MARKS });
            foreach (var student in resultStudentArray)
            {
                Console.Write("Name:{0}\nMarks:", student.FullName);
                foreach (var mark in student.Marks)
                {
                    Console.Write("{0} ", mark);
                }
                Console.WriteLine();
            }
        }

        //PROBLEM 14
        public static void ExtractByMarksNumber(Student[] studentArray, int value)
        {
            var resultStudentArray = studentArray.Where(x => x.MARKS.Count == 2);
            foreach (var student in resultStudentArray)
            {
                Console.Write("Name:{0} {1}\nMarks:", student.FIRSTNAME, student.LASTNAME);
                foreach (var mark in student.MARKS)
                {
                    Console.Write("{0} ", mark);
                }
                Console.WriteLine();
            }
        }

        //PROBLEM 15
        public static List<List<double>> ExtractStudentsByEnrollYear(Student[] studentArray, int year)
        {
            var resultStudentArray = (from student in studentArray
                                      where student.FN.Substring(4, 2).Equals(year.ToString().Substring(2, 2))
                                      select student.MARKS);

            return resultStudentArray.ToList();
        }

        //PROBLEM 18
        public static List<Student> StudentsByGroupNumber(List<Student> studentList)
        {
            var resultStudentList = (from student in studentList
                                     orderby student.GROUP.NUMBER
                                     select student);
            return resultStudentList.ToList();
        }

        //PROBLEM 19
        public static List<Student> StudentsByGroupNumberExtension(List<Student> studentList)
        {
            var resultStudentList = studentList.OrderBy(x => x.GROUP.NUMBER);
            return resultStudentList.ToList();
        }
    }
}
