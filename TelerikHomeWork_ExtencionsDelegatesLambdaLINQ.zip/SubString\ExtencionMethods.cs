﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SubString
{
    public static class ExtencionMethods
    {
        public static StringBuilder SubString(this StringBuilder builder, int index, int length)
        {
            if (index == 0 && length == 0)
            {
                StringBuilder emptyBuilder = new StringBuilder();
                return emptyBuilder;
            }
            else if (index < 0 || length < 0)
            {
                throw new IndexOutOfRangeException("Both index and length must be non-negative values!");
            }
            else if (index + length > builder.Length)
            {
                throw new IndexOutOfRangeException("Length value will violate the boundaries of the array!");
            }
            else
            {
                StringBuilder subBuilder = new StringBuilder();
                for (int i = 0; i < length; i++)
                {
                    subBuilder.Append(builder[index + i]);
                }
                return subBuilder;
            }
        }
    }
}
