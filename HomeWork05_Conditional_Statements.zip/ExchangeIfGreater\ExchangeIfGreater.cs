﻿/*
 Problem 1. Exchange If Greater
 Write an if-statement that takes two double variables a and b and exchanges their 
 values if the first one is greater than the second one. 
 As a result print the values a and b, separated by a space. 
 */
using System;
class ExchangeIfGreater
{
    static void Main()
    {
        Console.WriteLine("Enter 1st value:");
        double FirstValue = double.Parse(Console.ReadLine());
        Console.WriteLine("Enter 2nd value:");
        double SecondValue = double.Parse(Console.ReadLine());
        if (FirstValue > SecondValue)
        {
            double temp = FirstValue;
            FirstValue = SecondValue;
            SecondValue = temp;
        }
        Console.WriteLine("{0}  {1}", FirstValue, SecondValue);
    }
}

