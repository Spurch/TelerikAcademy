﻿/*
 Problem 8. Digit as Word
 Write a program that asks for a digit (0-9), and depending on the input, shows the digit as a word (in English).
 Print “not a digit” in case of invalid input.
 Use a switch statement. 
 */
using System;
class DigitAsWord
{
    static void Main()
    {
        Console.WriteLine("Enter a digit(0-9): ");
        string digit = Console.ReadLine();
        //Basic straight forward way:
        switch (digit)
        {
            case "0":
                Console.WriteLine("zero");
                break;
            case "1":
                Console.WriteLine("one");
                break;
            case "2":
                Console.WriteLine("two");
                break;
            case "3":
                Console.WriteLine("three");
                break;
            case "4":
                Console.WriteLine("four");
                break;
            case "5":
                Console.WriteLine("five");
                break;
            case "6":
                Console.WriteLine("six");
                break;
            case "7":
                Console.WriteLine("seven");
                break;
            case "8":
                Console.WriteLine("eight");
                break;
            case "9":
                Console.WriteLine("nine");
                break;
            default:
                Console.WriteLine("Not a digit!");
                break;
        }
        //Or we can use a little trick to check
        //less conditions in runtime.
        /*
        int value = 0;
        //First we check if the input is a digit at all.
        if (Int32.TryParse(digit, out value))
        {
            //After that we check if the digit entered is before
            //or after 5(this single check will let us get the answer
            //going through only half of the options.)
            if (value < 5)
            {
                switch (value)
                {
                    case 0:
                        Console.WriteLine("zero");
                        break;
                    case 1:
                        Console.WriteLine("one");
                        break;
                    case 2:
                        Console.WriteLine("two");
                        break;
                    case 3:
                        Console.WriteLine("three");
                        break;
                    case 4:
                        Console.WriteLine("four");
                        break;
                    default:
                        Console.WriteLine("Not a Digit!");
                        break;
                }
            }
            else
            {
                switch (value)
                {
                    case 5:
                        Console.WriteLine("five");
                        break;
                    case 6:
                        Console.WriteLine("six");
                        break;
                    case 7:
                        Console.WriteLine("seven");
                        break;
                    case 8:
                        Console.WriteLine("eight");
                        break;
                    case 9:
                        Console.WriteLine("nine");
                        break;
                    default:
                        Console.WriteLine("Not a digit!");
                        break;
                }
            }
        }
        else
        {
            Console.WriteLine("Not a Digit!");
        }
        */
    }
}

