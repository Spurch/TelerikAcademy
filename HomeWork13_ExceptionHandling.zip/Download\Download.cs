﻿/*
 Problem 4. Download file

    Write a program that downloads a file from Internet (e.g. Ninja image) and stores it the current directory.
    Find in Google how to download files in C#.
    Be sure to catch all exceptions and to free any used resources in the finally block.
 
 */
using System;
using System.Net;
using System.Security;
class Download
{
    public static string ADDRESS = "http://telerikacademy.com/Content/Images/news-img01.png";
    static void Main()
    {
        WebClient DownloadClient = new WebClient();
        try
        {
            DownloadClient.DownloadFile(ADDRESS, @"C:\Users\image.png");
            Console.WriteLine("Download - Done!");
        }
        catch (ArgumentNullException)
        {
            Console.WriteLine("The provided address is null!");
        }
        catch (ArgumentException)
        {
            Console.WriteLine("The method is called with some invalid arguments!");
        }
        catch (NotSupportedException)
        {
            Console.WriteLine("Unable to call a sync method simultaneously on multiple threads!");
        }
        catch (SecurityException)
        {
            Console.WriteLine("You do not have enough credentials to access the file specified!");
        }
        catch (WebException)
        {
            Console.WriteLine("Invalid URI/Error during download!");
        }
        finally
        {
            DownloadClient.Dispose();
        }
    }
}

