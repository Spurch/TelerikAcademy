﻿/*
 Problem 3. Read file contents

    Write a program that enters file name along with its full file path (e.g. C:\WINDOWS\win.ini), reads its contents and prints it on the console.
    Find in MSDN how to use System.IO.File.ReadAllText(…).
    Be sure to catch all possible exceptions and print user-friendly error messages. 
 */
using System;
using System.IO;
using System.Security;
class ReadFile
{
    public static string FILE_PATH = "..//..//..//README.txt";
    static void Main()
    {
        Console.WriteLine(FILE_PATH);
        try
        {
            Console.WriteLine(File.ReadAllText(FILE_PATH));
        }
        catch (ArgumentNullException)
        {
            Console.WriteLine("Path string is null!");
        }
        catch (PathTooLongException)
        {
            Console.WriteLine("The provided path string is too long!");
        }
        catch (DirectoryNotFoundException)
        {
            Console.WriteLine("The path is invalid!");
        }
        catch (FileNotFoundException)
        {
            Console.WriteLine("The file provided by the given path does not exists!");
        }
        catch (IOException)
        {
            Console.WriteLine("There was a problem with opening/reading the file!");
        }
        catch (NotSupportedException)
        {
            Console.WriteLine("The path provided is in invalid format!");
        }
        catch (ArgumentException) {
            Console.WriteLine("The path provided is empty or incorrect!");
        }
        catch (SecurityException)
        {
            Console.WriteLine("You do not have enough credentials to access the file specified!");
        }
        catch (UnauthorizedAccessException)
        {
            Console.WriteLine("The file is not supported on the current platform or the path specified a directory!");
        }
    }
}

