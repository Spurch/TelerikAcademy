﻿/*
 Problem 2. Maximal sum
 Write a program that reads a rectangular matrix of size N x M and finds
 in it the square 3 x 3 that has maximal sum of its elements. 
 */
using System;
class MaximumSum
{
    static void Main()
    {
        Console.WriteLine("-----------------------------------------------------------------------------");
        Console.WriteLine("Problem N2 - Maximal sum.");
        Console.WriteLine("-----------------------------------------------------------------------------");
        Console.WriteLine("Enter value for N:");
        int N = Int32.Parse(Console.ReadLine());
        Console.WriteLine("Enter value for M:");
        int M = Int32.Parse(Console.ReadLine());
        Console.WriteLine("-----------------------------------------------------------------------------");
        Console.WriteLine("Generating random matrix {0}x{1}...", N, M);
        Console.WriteLine("-----------------------------------------------------------------------------");

        int[,] Arr = new int[N , M];
        int PlatformWidth = 3;
        int PlatformHeight = 3;
        Random rand = new Random();

        int CurrentSum = 0;
        int BestSum = 0;
        int BestRow = 0;
        int BestCol = 0;

        //After we get the size of the matrix we fill it up with random values.
        for (int i = 0; i < N; i++)
        {
            for (int j = 0; j < M; j++)
            {
                //We use Random object rand to get pseudo-random values in a given range.
                int value = rand.Next(1, 9999);
                Arr[i, j] = value;
            }
        }

        //We print the generated matrix.
        for (int i = 0; i < N; i++)
        {
            for (int j = 0; j < M; j++)
            {
                Console.Write("{0} ", Arr[i, j]);
            }
            Console.WriteLine();
        }

        //We iterate through the matrix without going out of bounds/range.
        for (int i = 0; i < Arr.GetLength(0) - PlatformHeight + 1; i++)
        {
            for (int j = 0; j < Arr.GetLength(1) - PlatformWidth + 1; j++)
            {
                CurrentSum = 0;
                //For every row and column we check the current platform.
                for (int row = i; row < i + PlatformHeight; row++)
                {
                    for (int col = j; col < j + PlatformWidth; col++)
                    {
                        CurrentSum += Arr[row, col];        
                    }
                }
                //We check the sum after each platform.
                if (CurrentSum > BestSum)
                {
                    BestSum = CurrentSum;
                    BestRow = i;
                    BestCol = j;
                }
            }
        }
        //We print the best platform.
        Console.WriteLine("-----------------------------------------------------------------------------");
        Console.WriteLine("Best platform starts at ({0},{1})", BestRow, BestCol);
        //We iterate from BestRow and BestCol till the size of the platform.
        for (int i = BestRow; i < BestRow + PlatformHeight; i++)
        {
            for (int j = BestCol; j < BestCol + PlatformWidth; j++)
            {
                Console.Write("{0} ", Arr[i, j]);
            }
            Console.WriteLine();
        }
        //We print the sum of the platform.
        Console.WriteLine("-----------------------------------------------------------------------------");
        Console.WriteLine("The sum is: {0}", BestSum);
    }
}

