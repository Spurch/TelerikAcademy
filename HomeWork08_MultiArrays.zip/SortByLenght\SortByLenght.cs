﻿/*
 Problem 5. Sort by string length
 You are given an array of strings. Write a method that sorts the array by 
 the length of its elements (the number of characters composing them). 
 */
using System;
using System.Collections.Generic;
class SortByLenght
{
    //I am using a modified version of the QuickSort realization from the previous homework.
    //We pass the string array as a reference type
    static public int ChoosePivot(ref string[] Arr, int Left, int Right)
    {
        //Basically all we need to do is to work with the string lenght.
        int pivot = Arr[Right].Length;
        int i = Left - 1;

        for (int j = Left; j < Right; j++)
        {
            //We compare based on lenght.
            if (Arr[j].Length <= pivot)
            {
                i++;
                string temp = Arr[i];
                Arr[i] = Arr[j];
                Arr[j] = temp;
            }
        }
        string stemp = Arr[i + 1];
        Arr[i + 1] = Arr[Right];
        Arr[Right] = stemp;
        return (i + 1);
    }

    //Again passing the string array as a reference type.
    static public void QSort(ref string[] Arr, int Left, int Right)
    {
        int Pivot = 0;
        if (Left < Right)
        {
            //Here we must add the ref keyword in order 
            //to call the methods.
            Pivot = ChoosePivot(ref Arr, Left, Right);
            QSort(ref Arr, Left, Pivot - 1);
            QSort(ref Arr, Pivot + 1, Right);
        }
    }


    static void Main()
    {
        Console.WriteLine("-----------------------------------------------------------------------------");
        Console.WriteLine("Problem N5 - Sort an array of strings based on strings lenght.");
        Console.WriteLine("-----------------------------------------------------------------------------");
        Console.WriteLine("Enter strings on one line each value separated by a , and/or a space:");
        //We get the user input and pass is to a new string array.
        string[] StrArray = Console.ReadLine().Split(new char[] { ' ', ',', '\t' }, StringSplitOptions.RemoveEmptyEntries);
        
        //We simply pass the newly created string array to the QuickSort method.
        QSort(ref StrArray, 0, StrArray.GetLength(0)-1);

        //we print the sorted array afterwords.
        for (int i = 0; i < StrArray.GetLength(0); i++)
        {
            Console.WriteLine(StrArray[i]);    
        }
        
    }
}

