﻿/*
 Problem 10. Find sum in array
 Write a program that finds in given array of integers 
 a sequence of given sum S (if present). 
 */
using System;
class SumInArray
{ 
    //Method that gets a string of integers and an empty integer array as an input and outputs
    //The integer from the string parsed in the empty integer array.
    static public void ArrayParser(string InputString, out int[] ResultArray)
    {
        //Variable that counts how many integer elements we have parsed.
        int NumbersCounter = 0;
        //Variable that counts how many non-integer elements we have ignored.
        int OtherCounter = 0;
        //Variable for the current value that we parse.
        int CurrentValue = 0;
        //A temp working string[] variable that we use during parsing.
        string[] TempParser;

        //We split the input string.
        TempParser = InputString.Split(new Char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);

        //We loop through the splited string to parse the integer values.
        foreach (var Number in TempParser)
        {
            if (Int32.TryParse(Number, out CurrentValue))
            {
                //We increment the integer elements counter.
                NumbersCounter++;
            }
            else
            {
                //We increment the non-integer elements counter.
                OtherCounter++;
            }
        }
        //We initiazlize the output integer array with the appropriate size.
        ResultArray = new int[NumbersCounter];
        int i = 0;
        //We iterate through the tempparser once again in order to fill in the 
        //output integer array.
        foreach (var Number in TempParser)
        {
            if (Int32.TryParse(Number, out CurrentValue))
            {
                ResultArray[i] = CurrentValue;
                i++;
            }
        }
    }

    static void Main()
    {
        Console.WriteLine("-----------------------------------------------------------------------------");
        Console.WriteLine("Problem N10 - Find sum of a sequence in an array (if present).");
        Console.WriteLine("-----------------------------------------------------------------------------");
        Console.WriteLine("Enter number sequence each value separated by a , and/or a space: a, b, c, ...");
        string StringNumbers = Console.ReadLine();
        int[] NumbersArray;
        int CurrentSum = 0;
        int StartIndex = 0;
        int EndIndex = 0;
        Console.WriteLine("Enter sum to look for:");
        int Sum = Int32.Parse(Console.ReadLine());

        //First we parse the input string.
        ArrayParser(StringNumbers, out NumbersArray);
  
        for (int i = 0; i < NumbersArray.Length; i++)
        {
            CurrentSum = 0;
            for (int j = i; j < NumbersArray.Length; j++)
            {
                CurrentSum += NumbersArray[j];
                if (CurrentSum == Sum)
                {
                    StartIndex = i;
                    EndIndex = j;
                }
            }
        }

        Console.WriteLine("Result: ");
        for (int i = StartIndex; i <= EndIndex; i++)
        {
            Console.Write("{0}, ", NumbersArray[i]);
        }

        Console.WriteLine();
    }
}

