﻿/*
 Problem 3. Compare char arrays
 Write a program that compares two char arrays lexicographically (letter by letter). 
 */
using System;
using System.Linq;
class CompareCharArray
{
    static void Main()
    {
        Console.WriteLine("-----------------------------------------------------------------------------");
        Console.WriteLine("Problem N3 - Compare char arrays letter by letter.");
        Console.WriteLine("-----------------------------------------------------------------------------");

        Console.WriteLine("Enter first array:");
        char[] FirstCharArray = Console.ReadLine().
            Split(new char[] { ' ', ',', '\t' }, StringSplitOptions.RemoveEmptyEntries)
            .Select(x => char.Parse(x)).ToArray();

        Console.WriteLine("Enter second array:");
        char[] SecondCharArray = Console.ReadLine().
            Split(new char[] { ' ', ',', '\t' }, StringSplitOptions.RemoveEmptyEntries)
            .Select(x => char.Parse(x)).ToArray();

        bool isEqual = true;

        if (FirstCharArray.Length != SecondCharArray.Length)
        {
            isEqual = false;
            Console.WriteLine("Arrays differ in size!");
            Console.WriteLine(isEqual);
        }
        else
        {
            for (int i = 0; i < FirstCharArray.Length; i++)
            {
                if (FirstCharArray[i] != SecondCharArray[i])
                {
                    isEqual = false;
                }
            }
            Console.WriteLine(isEqual);
        }

    }
}

