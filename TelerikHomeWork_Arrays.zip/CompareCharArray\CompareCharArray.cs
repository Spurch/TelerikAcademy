﻿/*
 Problem 3. Compare char arrays
 Write a program that compares two char arrays lexicographically (letter by letter). 
 */
using System;
class CompareCharArray
{
    static void Main()
    {
        Console.WriteLine("-----------------------------------------------------------------------------");
        Console.WriteLine("Problem N3 - Compare char arrays letter by letter.");
        Console.WriteLine("-----------------------------------------------------------------------------");

        char[] FirstCharArray;
        char[] SecondCharArray;
        bool isEqual = true;

        FirstCharArray = new char[] { 'a', 'b', 'c', 'd' };
        SecondCharArray = new char[] { 'a', 'b', 'c', 'd' };

        for (int i = 0; i < FirstCharArray.Length-1; i++)
        {
            if (FirstCharArray[i] != SecondCharArray[i])
            {
                isEqual = false;
            }
        }
        Console.WriteLine(isEqual);
    }
}

