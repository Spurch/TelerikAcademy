﻿/*
 Problem 14. Quick sort
 Write a program that sorts an array of integers using the Quick sort algorithm. 
 */
using System;
class QuickSort
{
    static public void ArrayParser(string InputString, out int[] ResultArray)
    {
        //Variable that counts how many integer elements we have parsed.
        int NumbersCounter = 0;
        //Variable that counts how many non-integer elements we have ignored.
        int OtherCounter = 0;
        //Variable for the current value that we parse.
        int CurrentValue = 0;
        //A temp working string[] variable that we use during parsing.
        string[] TempParser;

        //We split the input string.
        TempParser = InputString.Split(new Char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);

        //We loop through the splited string to parse the integer values.
        foreach (var Number in TempParser)
        {
            if (Int32.TryParse(Number, out CurrentValue))
            {
                //We increment the integer elements counter.
                NumbersCounter++;
            }
            else
            {
                //We increment the non-integer elements counter.
                OtherCounter++;
            }
        }
        //We initiazlize the output integer array with the appropriate size.
        ResultArray = new int[NumbersCounter];
        int i = 0;
        //We iterate through the tempparser once again in order to fill in the 
        //output integer array.
        foreach (var Number in TempParser)
        {
            if (Int32.TryParse(Number, out CurrentValue))
            {
                ResultArray[i] = CurrentValue;
                i++;
            }
        }
    }

    static public int ChoosePivot(int[] Arr, int Left, int Right)
    {
        int pivot = Arr[Right];
        int i = Left - 1;

        for (int j = Left; j < Right; j++)
        {
            if (Arr[j] <= pivot)
            {
                i++;
                int temp = Arr[i];
                Arr[i] = Arr[j];
                Arr[j] = temp;
            }
        }
        int stemp = Arr[i + 1];
        Arr[i + 1] = Arr[Right];
        Arr[Right] = stemp;
        return (i + 1);
    }

    static public void QSort(int[] Arr, int Left, int Right)
    {
        int Pivot = 0;
        if (Left < Right)
        {
            Pivot = ChoosePivot(Arr, Left, Right);
            QSort(Arr, Left, Pivot - 1);
            QSort(Arr, Pivot + 1, Right);
        }
    }

    static void Main()
    {
        Console.WriteLine("-----------------------------------------------------------------------------");
        Console.WriteLine("Problem N14 - Sorting an array using the QuickSort algorithm.");
        Console.WriteLine("-----------------------------------------------------------------------------");
        Console.WriteLine("Enter number sequence each value separated by a , and/or a space: a, b, c, ...");
        string StringNumbers = Console.ReadLine();
        int[] NumbersArray;

        //First we parse the input string.
        ArrayParser(StringNumbers, out NumbersArray);
        QSort(NumbersArray, 0, NumbersArray.Length-1);
        for (int i = 0; i < NumbersArray.Length; i++)
        {
            Console.Write("{0}, ", NumbersArray[i]);
        }
    }
}

