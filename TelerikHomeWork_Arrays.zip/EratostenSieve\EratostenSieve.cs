﻿/*
 Problem 15. Prime numbers
 Write a program that finds all prime numbers in the range [1...10 000 000]. 
 Use the Sieve of Eratosthenes algorithm. 
 */
using System;
using System.IO;
class EratostenSieve
{
    static void Main()
    {
        Console.WriteLine("-----------------------------------------------------------------------------");
        Console.WriteLine("Problem N15 - Prime Numbers using Sieve algorithm.");
        Console.WriteLine("-----------------------------------------------------------------------------");
        int MaxRange = 10000000;
        int MaxRangeSqrt = (int)Math.Sqrt(MaxRange);

        bool[] Sieve = new bool[MaxRange];

        for (int i = 0; i < MaxRange; i++)
        {
            Sieve[i] = true;
        }

        for (int i = 2; i < MaxRangeSqrt; i++)
        {
            if (Sieve[i])
            {
                for (int j = i * i; j < MaxRange; j += i)
                {
                    Sieve[j] = false;
                }   
            }
        }

        for (int i = 2; i < MaxRange; i++)
        {
            if (Sieve[i])
            {
                Console.Write("{0}, ", i);
            }
        }
    }
}

