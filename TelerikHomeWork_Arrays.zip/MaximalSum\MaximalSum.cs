﻿/*
 Problem 8. Maximal sum
 Write a program that finds the sequence of maximal sum in given array. 
 */
using System;
class MaximalSum
{
    //Method that gets a string of integers and an empty integer array as an input and outputs
    //The integer from the string parsed in the empty integer array.
    static public void ArrayParser(string InputString, out int[] ResultArray)
    {
        //Variable that counts how many integer elements we have parsed.
        int NumbersCounter = 0;
        //Variable that counts how many non-integer elements we have ignored.
        int OtherCounter = 0;
        //Variable for the current value that we parse.
        int CurrentValue = 0;
        //A temp working string[] variable that we use during parsing.
        string[] TempParser;

        //We split the input string.
        TempParser = InputString.Split(new Char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);

        //We loop through the splited string to parse the integer values.
        foreach (var Number in TempParser)
        {
            if (Int32.TryParse(Number, out CurrentValue))
            {
                //We increment the integer elements counter.
                NumbersCounter++;
            }
            else
            {
                //We increment the non-integer elements counter.
                OtherCounter++;
            }
        }
        //We initiazlize the output integer array with the appropriate size.
        ResultArray = new int[NumbersCounter];
        int i = 0;
        //We iterate through the tempparser once again in order to fill in the 
        //output integer array.
        foreach (var Number in TempParser)
        {
            if (Int32.TryParse(Number, out CurrentValue))
            {
                ResultArray[i] = CurrentValue;
                i++;
            }
        }
    }

    static void Main()
    {
        Console.WriteLine("-----------------------------------------------------------------------------");
        Console.WriteLine("Problem N8 - Maximal sum of a sequence in an array.");
        Console.WriteLine("-----------------------------------------------------------------------------");
        Console.WriteLine("Enter number sequence each value separated by a , and/or a space: a, b, c, ...");
        string StringNumbers = Console.ReadLine();
        int[] NumbersArray;
        int CurrentSum;
        int MaxSum;
        int Start = 0;
        int End = 0;
        int CurrentStart = 0;

        //First we parse the input string.
        ArrayParser(StringNumbers, out NumbersArray);
        CurrentSum = NumbersArray[0];
        MaxSum = NumbersArray[0];
        for (int i = 0; i < NumbersArray.Length-1; i++)
        {
            CurrentSum += NumbersArray[i];

            if (CurrentSum > MaxSum)
            {
                MaxSum = CurrentSum;
                Start = CurrentStart;
                End = i;
            }
            if (CurrentSum <= 0)
            {
                CurrentSum = 0;
                CurrentStart = i + 1;
            }
        }
        Console.WriteLine("The sequence is: ");
        for (int i = Start; i <= End; i++)
        {
            Console.Write("{0}, ", NumbersArray[i]);
        }
        Console.WriteLine();
    }
}

