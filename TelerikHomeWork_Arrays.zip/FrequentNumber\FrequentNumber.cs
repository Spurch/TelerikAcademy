﻿/*
 Problem 9. Frequent number
 Write a program that finds the most frequent number in an array. 
 */
using System;
class FrequentNumber
{
    //Method that gets a string of integers and an empty integer array as an input and outputs
    //The integer from the string parsed in the empty integer array.
    static public void ArrayParser(string InputString, out int[] ResultArray)
    {
        //Variable that counts how many integer elements we have parsed.
        int NumbersCounter = 0;
        //Variable that counts how many non-integer elements we have ignored.
        int OtherCounter = 0;
        //Variable for the current value that we parse.
        int CurrentValue = 0;
        //A temp working string[] variable that we use during parsing.
        string[] TempParser;

        //We split the input string.
        TempParser = InputString.Split(new Char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);

        //We loop through the splited string to parse the integer values.
        foreach (var Number in TempParser)
        {
            if (Int32.TryParse(Number, out CurrentValue))
            {
                //We increment the integer elements counter.
                NumbersCounter++;
            }
            else
            {
                //We increment the non-integer elements counter.
                OtherCounter++;
            }
        }
        //We initiazlize the output integer array with the appropriate size.
        ResultArray = new int[NumbersCounter];
        int i = 0;
        //We iterate through the tempparser once again in order to fill in the 
        //output integer array.
        foreach (var Number in TempParser)
        {
            if (Int32.TryParse(Number, out CurrentValue))
            {
                ResultArray[i] = CurrentValue;
                i++;
            }
        }
    }

    static void Main()
    {
        Console.WriteLine("-----------------------------------------------------------------------------");
        Console.WriteLine("Problem N9 - Most frequent number in an array.");
        Console.WriteLine("-----------------------------------------------------------------------------");
        Console.WriteLine("Enter number sequence each value separated by a , and/or a space: a, b, c, ...");
        string StringNumbers = Console.ReadLine();
        int[] NumbersArray;
        int Counter = 0;
        int MostFrequent = 0;
        int MaxCounter = 0;
  
        //First we parse the input string.
        ArrayParser(StringNumbers, out NumbersArray);

        for (int i = 0; i < NumbersArray.Length; i++)
        {
            Counter = 0;
            for (int j = 0; j < NumbersArray.Length; j++)
			{
                if (NumbersArray[j] == NumbersArray[i])
                {
                    Counter++;
                    if (Counter > MaxCounter)
                    {
                        MaxCounter = Counter;
                        MostFrequent = NumbersArray[i];
                    }
                }
			}
           
        }
        Console.WriteLine("Most frequent: {0}, {1} times!", MostFrequent, MaxCounter);
    }
}

