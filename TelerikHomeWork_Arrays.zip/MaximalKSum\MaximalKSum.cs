﻿/*
Problem 6. Maximal K sum
Write a program that reads two integer numbers N and K and an array of N elements from the console.
Find in the array those K elements that have maximal sum. 
 */
using System;
class MaximalKSum
{ 
    //Method that gets a string of integers and an empty integer array as an input and outputs
    //The integer from the string parsed in the empty integer array.
    static public void ArrayParser(string InputString, out int[] ResultArray)
    {
        //Variable that counts how many integer elements we have parsed.
        int NumbersCounter = 0;
        //Variable that counts how many non-integer elements we have ignored.
        int OtherCounter = 0;
        //Variable for the current value that we parse.
        int CurrentValue = 0;
        //A temp working string[] variable that we use during parsing.
        string[] TempParser;

        //We split the input string.
        TempParser = InputString.Split(new Char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);

        //We loop through the splited string to parse the integer values.
        foreach (var Number in TempParser)
        {
            if (Int32.TryParse(Number, out CurrentValue))
            {
                //We increment the integer elements counter.
                NumbersCounter++;
            }
            else
            {
                //We increment the non-integer elements counter.
                OtherCounter++;
            }
        }
        //We initiazlize the output integer array with the appropriate size.
        ResultArray = new int[NumbersCounter];
        int i = 0;
        //We iterate through the tempparser once again in order to fill in the 
        //output integer array.
        foreach (var Number in TempParser)
        {
            if (Int32.TryParse(Number, out CurrentValue))
            {
                ResultArray[i] = CurrentValue;
                i++;
            }
        }
    }

    static void Main()
    {
        Console.WriteLine("-----------------------------------------------------------------------------");
        Console.WriteLine("Problem N6 - Maximal sum of K elements of N sized array.");
        Console.WriteLine("-----------------------------------------------------------------------------");
        Console.WriteLine("Enter number sequence each value separated by a , and/or a space: a, b, c, ...");
        string StringNumbers = Console.ReadLine();
        int[] NumbersArray;
        int MaxSum = 0;

        Console.WriteLine("Enter value for K:");
        int K = Int32.Parse(Console.ReadLine());

        //First we parse the input string.
        ArrayParser(StringNumbers, out NumbersArray);
        Array.Sort(NumbersArray);

        for (int i = NumbersArray.Length-K; i < NumbersArray.Length; i++)
        {
            MaxSum += NumbersArray[i];
        }
        Console.WriteLine("Maximal sum is: {0}", MaxSum);
    }
}

