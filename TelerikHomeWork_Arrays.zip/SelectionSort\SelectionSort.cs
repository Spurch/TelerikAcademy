﻿/*
 Problem 7. Selection sort
 Sorting an array means to arrange its elements in increasing order. 
 Write a program to sort an array.
 Use the Selection sort algorithm: Find the smallest element, 
 move it at the first position, find the smallest from the rest, 
 move it at the second position, etc. 
 */
using System;
class SelectionSort
{
    //Method that gets a string of integers and an empty integer array as an input and outputs
    //The integer from the string parsed in the empty integer array.
    static public void ArrayParser(string InputString, out int[] ResultArray)
    {
        //Variable that counts how many integer elements we have parsed.
        int NumbersCounter = 0;
        //Variable that counts how many non-integer elements we have ignored.
        int OtherCounter = 0;
        //Variable for the current value that we parse.
        int CurrentValue = 0;
        //A temp working string[] variable that we use during parsing.
        string[] TempParser;

        //We split the input string.
        TempParser = InputString.Split(new Char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);

        //We loop through the splited string to parse the integer values.
        foreach (var Number in TempParser)
        {
            if (Int32.TryParse(Number, out CurrentValue))
            {
                //We increment the integer elements counter.
                NumbersCounter++;
            }
            else
            {
                //We increment the non-integer elements counter.
                OtherCounter++;
            }
        }
        //We initiazlize the output integer array with the appropriate size.
        ResultArray = new int[NumbersCounter];
        int i = 0;
        //We iterate through the tempparser once again in order to fill in the 
        //output integer array.
        foreach (var Number in TempParser)
        {
            if (Int32.TryParse(Number, out CurrentValue))
            {
                ResultArray[i] = CurrentValue;
                i++;
            }
        }
    }

    static void Main()
    {
        Console.WriteLine("-----------------------------------------------------------------------------");
        Console.WriteLine("Problem N7 - Sorting an array using Selection Sort.");
        Console.WriteLine("-----------------------------------------------------------------------------");
        Console.WriteLine("Enter number sequence each value separated by a , and/or a space: a, b, c, ...");
        string StringNumbers = Console.ReadLine();
        int[] NumbersArray;
        int MinElement = 0;

        //First we parse the input string.
        ArrayParser(StringNumbers, out NumbersArray);
        for (int i = 0; i < NumbersArray.Length-1; i++)
        {
            MinElement = i;
            for (int j = i+1; j < NumbersArray.Length; j++)
            {
                if (NumbersArray[j] < NumbersArray[MinElement])
                {
                    MinElement = j;
                }
            }
            if(MinElement != i){
                int temp = NumbersArray[i];
                NumbersArray[i] = NumbersArray[MinElement];
                NumbersArray[MinElement] = temp;
            }
        }

        for (int i = 0; i < NumbersArray.Length; i++)
        {
            Console.Write("{0},", NumbersArray[i]);
        }
        Console.WriteLine();
    }
}

