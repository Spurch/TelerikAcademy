﻿/*
 Problem 13.* Merge sort
 Write a program that sorts an array of integers using the Merge sort algorithm. 
 */
using System;
class MergeSort
{
    //Method that gets a string of integers and an empty integer array as an input and outputs
    //The integer from the string parsed in the empty integer array.
    static public void ArrayParser(string InputString, out int[] ResultArray)
    {
        //Variable that counts how many integer elements we have parsed.
        int NumbersCounter = 0;
        //Variable that counts how many non-integer elements we have ignored.
        int OtherCounter = 0;
        //Variable for the current value that we parse.
        int CurrentValue = 0;
        //A temp working string[] variable that we use during parsing.
        string[] TempParser;

        //We split the input string.
        TempParser = InputString.Split(new Char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);

        //We loop through the splited string to parse the integer values.
        foreach (var Number in TempParser)
        {
            if (Int32.TryParse(Number, out CurrentValue))
            {
                //We increment the integer elements counter.
                NumbersCounter++;
            }
            else
            {
                //We increment the non-integer elements counter.
                OtherCounter++;
            }
        }
        //We initiazlize the output integer array with the appropriate size.
        ResultArray = new int[NumbersCounter];
        int i = 0;
        //We iterate through the tempparser once again in order to fill in the 
        //output integer array.
        foreach (var Number in TempParser)
        {
            if (Int32.TryParse(Number, out CurrentValue))
            {
                ResultArray[i] = CurrentValue;
                i++;
            }
        }
    }

    static public void Merge(int[] Arr, int Start, int Middle, int End, int[] CopyArr)
    {
        int x = Start;
        int y = Middle;
        for (int i = Start; i < End; i++)
        {
            if(x < Middle && (y >= End || Arr[x] <= Arr[y])){
                CopyArr[i] = Arr[x];
                x++;
            }else{
                CopyArr[i] = Arr[y];
                y++;
            }
        }
    }

    static public void Split(int[] Arr, int Start, int End, int[] CopyArr)
    {
        if (End - Start >= 2)
        {
            int Middle = (End + Start)/2;
            Split(Arr, Start, Middle, CopyArr);
            Split(Arr, Middle, End, CopyArr);
            Merge(Arr, Start, Middle, End, CopyArr);
            Copy(CopyArr, Start, End, Arr);
        }
    }

    static public void Copy(int[] CopyArr, int Start, int End, int[] Arr)
    {
        for (int i = Start; i < End; i++)
        {
            Arr[i] = CopyArr[i];
        }
    }
    static void Main()
    {
        Console.WriteLine("-----------------------------------------------------------------------------");
        Console.WriteLine("Problem N13 - Sort an array using MergeSort.");
        Console.WriteLine("-----------------------------------------------------------------------------");
        Console.WriteLine("Enter number sequence each value separated by a , and/or a space: a, b, c, ...");
        string StringNumbers = Console.ReadLine();
        int[] NumbersArray;
        int[] CopyArray;
        
        //First we parse the input string.
        ArrayParser(StringNumbers, out NumbersArray);
        CopyArray = new int[NumbersArray.Length];

        Split(NumbersArray, 0, NumbersArray.Length, CopyArray);
        Console.WriteLine("Sorted array after MergeSort: ");
        for (int i = 0; i < NumbersArray.Length; i++)
        {
            Console.Write("{0}, ", NumbersArray[i]);
        }
        Console.WriteLine();
    }
}

