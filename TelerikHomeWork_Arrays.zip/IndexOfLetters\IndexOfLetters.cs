﻿/*
 Problem 12. Index of letters
 Write a program that creates an array containing all letters from the alphabet (A-Z).
 Read a word from the console and print the index of each of its letters in the array. 
 */
using System;
class IndexOfLetters
{
    static void Main()
    {
        char[] LettersArray = new char[26];
        for (int i = 0; i < LettersArray.Length; i++)
        {
            LettersArray[i] = (char)(i + 65);
        }

        Console.WriteLine("-----------------------------------------------------------------------------");
        Console.WriteLine("Problem N12 - Index of Letters.");
        Console.WriteLine("-----------------------------------------------------------------------------");
        Console.WriteLine("Enter a word in CAPS:");
        string Word = Console.ReadLine();
        char[] WordToLetters = Word.ToCharArray();
        for (int i = 0; i < WordToLetters.Length; i++)
        {
            int j = 0;
            while (WordToLetters[i] != LettersArray[j])
            {
                j++;
            }
            Console.WriteLine("The letter {0} is at {1} position in the array.", WordToLetters[i], j);
        }
    }
}

