﻿/*
 Problem 11. Binary search
 Write a program that finds the index of given element in
 a sorted array of integers by using the Binary search algorithm. 
 */
using System;
class BinarySearch
{
    //Method that gets a string of integers and an empty integer array as an input and outputs
    //The integer from the string parsed in the empty integer array.
    static public void ArrayParser(string InputString, out int[] ResultArray)
    {
        //Variable that counts how many integer elements we have parsed.
        int NumbersCounter = 0;
        //Variable that counts how many non-integer elements we have ignored.
        int OtherCounter = 0;
        //Variable for the current value that we parse.
        int CurrentValue = 0;
        //A temp working string[] variable that we use during parsing.
        string[] TempParser;

        //We split the input string.
        TempParser = InputString.Split(new Char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);

        //We loop through the splited string to parse the integer values.
        foreach (var Number in TempParser)
        {
            if (Int32.TryParse(Number, out CurrentValue))
            {
                //We increment the integer elements counter.
                NumbersCounter++;
            }
            else
            {
                //We increment the non-integer elements counter.
                OtherCounter++;
            }
        }
        //We initiazlize the output integer array with the appropriate size.
        ResultArray = new int[NumbersCounter];
        int i = 0;
        //We iterate through the tempparser once again in order to fill in the 
        //output integer array.
        foreach (var Number in TempParser)
        {
            if (Int32.TryParse(Number, out CurrentValue))
            {
                ResultArray[i] = CurrentValue;
                i++;
            }
        }
    }

    static public void BinSearch(int[] Arr, int Element ,int Start ,int End)
    {
        int Middle = ((Start + End) / 2);
        int Pivot = Arr[Middle];
        if (End > Start)
        {
            Console.WriteLine("Element not found!");
        }
        else if (Pivot == Element)
        {
            Console.WriteLine("Element found at index: {0}", Middle);
        }
        else if (Pivot > Element)
        {
            BinSearch(Arr, Element, 0, Middle-1);
        }
        else if (Pivot < Element)
        {
            BinSearch(Arr, Element, Middle+1, Arr.Length);
        }
    }

    static void Main()
    {
        Console.WriteLine("-----------------------------------------------------------------------------");
        Console.WriteLine("Problem N11 - Binary search in an array.");
        Console.WriteLine("-----------------------------------------------------------------------------");
        Console.WriteLine("Enter number sequence each value separated by a , and/or a space: a, b, c, ...");
        string StringNumbers = Console.ReadLine();
        int[] NumbersArray;
        int Value = 0;

        //First we parse the input string.
        ArrayParser(StringNumbers, out NumbersArray);
        Array.Sort(NumbersArray);
        Console.WriteLine("Sorted array:");
        for (int i = 0; i < NumbersArray.Length; i++)
        {
            Console.Write("{0}, ", NumbersArray[i]);
        }

        Console.WriteLine("\nPlease enter value to search for: ");
        Value = Int32.Parse(Console.ReadLine());
        BinSearch(NumbersArray, Value, 0, NumbersArray.Length);
    }
}

