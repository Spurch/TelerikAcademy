﻿/*
 Problem 2. Compare arrays
 Write a program that reads 
 two integer arrays from the console and compares them element by element. 
 */
using System;
class CompareArrays
{
    //Method that gets a string of integers and an empty integer array as an input and outputs
    //The integer from the string parsed in the empty integer array.
    static public void ArrayParser(string InputString, out int[] ResultArray)
    {
        //Variable that counts how many integer elements we have parsed.
        int NumbersCounter = 0;
        //Variable that counts how many non-integer elements we have ignored.
        int OtherCounter = 0;
        //Variable for the current value that we parse.
        int CurrentValue = 0;
        //A temp working string[] variable that we use during parsing.
        string[] TempParser;

        //We split the input string.
        TempParser = InputString.Split(new Char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);

        //We loop through the splited string to parse the integer values.
        foreach (var Number in TempParser)
        {
            if (Int32.TryParse(Number, out CurrentValue))
            {
                //We increment the integer elements counter.
                NumbersCounter++;
            }
            else
            {
                //We increment the non-integer elements counter.
                OtherCounter++;
            }
        }
        //We initiazlize the output integer array with the appropriate size.
        ResultArray = new int[NumbersCounter];
        int i = 0;
        //We iterate through the tempparser once again in order to fill in the 
        //output integer array.
        foreach (var Number in TempParser)
        {
            if (Int32.TryParse(Number, out CurrentValue))
            {
                ResultArray[i] = CurrentValue;
                i++;
            }
        }
    }


    static void Main()
    {
        Console.WriteLine("-----------------------------------------------------------------------------");
        Console.WriteLine("Problem N2 - Compare arrays.");
        Console.WriteLine("-----------------------------------------------------------------------------");

        string FirstStr = "";
        //string FirstNumStr = "";
        string SecondStr = "";
        //string SecondNumStr = "";
        int[] FirstArray;
        int[] SecondArray;
        bool isEqual = false;


        Console.WriteLine("Please enter 2 integer arrays.\nEach array should be entered "
            + "at a single line - numbers separated by a space.\nPress ENTER to finish entering an array!");
        Console.WriteLine("-----------------------------------------------------------------------------");
        Console.WriteLine("\nEnter first array:");

        FirstStr = Console.ReadLine();
        ArrayParser(FirstStr, out FirstArray);

        Console.WriteLine("------------------------------------------------------------------");
        Console.WriteLine("NOTE: Enter the same amount of numbers as in the First array!");
        Console.WriteLine("------------------------------------------------------------------");
        Console.WriteLine("Enter second array:");

        SecondStr = Console.ReadLine();
        ArrayParser(SecondStr, out SecondArray);
        Console.WriteLine("------------------------------------------------------------------");


        if (FirstArray.Length == SecondArray.Length && FirstArray.Length > 0)
        {
            isEqual = true;
        }

        switch (isEqual)
        {
            case false:
                Console.WriteLine("The arrays differ in size or one of them is empty!");
                break;

            case true:
                Console.WriteLine("Arrays have the same size!");
                int i = 0;
                while (isEqual && i < SecondArray.Length)
                {
                    if (FirstArray[i] != SecondArray[i])
                    {
                        isEqual = false;
                        Console.WriteLine("The arrays are not equal!");
                        Console.WriteLine("------------------------------------------------------------------");
                        Console.WriteLine("| Two arrays side by side:|");
                        Console.WriteLine("---------------------------");
                        Console.WriteLine("| 1st array  |  2nd array |");
                        Console.WriteLine("---------------------------");
                        for (i = 0; i < SecondArray.Length; i++)
                        {
                            Console.WriteLine("{0,12} | {1,11}|", FirstArray[i], SecondArray[i]);

                        }
                        Console.WriteLine("---------------------------");
                    }
                    i++;
                }
                if (isEqual == true)
                {
                    Console.WriteLine("Arrays are the same!");
                    Console.WriteLine("------------------------------------------------------------------");
                    Console.WriteLine("| Two arrays side by side:|");
                    Console.WriteLine("---------------------------");
                    Console.WriteLine("| 1st array  |  2nd array |");
                    Console.WriteLine("---------------------------");
                    for (i = 0; i < SecondArray.Length; i++)
                    {
                        Console.WriteLine("{0,12} | {1,11}|", FirstArray[i], SecondArray[i]);

                    }
                    Console.WriteLine("---------------------------");
                }
                break;

        }
    }
}

