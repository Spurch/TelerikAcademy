﻿/*
 Problem 4. Maximal sequence
 Write a program that finds the maximal sequence of equal elements in an array. 
 */
using System;
class MaximalSequnce
{
    //Method that gets a string of integers and an empty integer array as an input and outputs
    //The integer from the string parsed in the empty integer array.
    static public void ArrayParser(string InputString, out int[] ResultArray)
    {
        //Variable that counts how many integer elements we have parsed.
        int NumbersCounter = 0;
        //Variable that counts how many non-integer elements we have ignored.
        int OtherCounter = 0;
        //Variable for the current value that we parse.
        int CurrentValue = 0;
        //A temp working string[] variable that we use during parsing.
        string[] TempParser;

        //We split the input string.
        TempParser = InputString.Split(new Char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);

        //We loop through the splited string to parse the integer values.
        foreach (var Number in TempParser)
        {
            if (Int32.TryParse(Number, out CurrentValue))
            {
                //We increment the integer elements counter.
                NumbersCounter++;
            }
            else
            {
                //We increment the non-integer elements counter.
                OtherCounter++;
            }
        }
        //We initiazlize the output integer array with the appropriate size.
        ResultArray = new int[NumbersCounter];
        int i = 0;
        //We iterate through the tempparser once again in order to fill in the 
        //output integer array.
        foreach (var Number in TempParser)
        {
            if (Int32.TryParse(Number, out CurrentValue))
            {
                ResultArray[i] = CurrentValue;
                i++;
            }
        }
    }

    static void Main()
    {
        Console.WriteLine("-----------------------------------------------------------------------------");
        Console.WriteLine("Problem N4 - Find maximal sequence of equal values.");
        Console.WriteLine("-----------------------------------------------------------------------------");
        Console.WriteLine("Enter number sequence each value separated by a , and/or a space: a, b, c, ...");
        string StringNumbers = Console.ReadLine();
        string MaxSequence = "";
        string CurrentSequence = "";
        int[] NumbersArray;

        //First we parse the input string.
        ArrayParser(StringNumbers, out NumbersArray);
        //We intialize both the current and the final strings with the first value in the array.
        CurrentSequence += NumbersArray[0];
        MaxSequence += NumbersArray[0];
        //For each element in the output array we compare the current element with the next one.
        //That is why we iterate to Lenght-1 otherwise we will get an IndexOutOfBound exception error.
        for (int i = 0; i < NumbersArray.Length-1; i++)
        {
            //Are they the same?
            if (NumbersArray[i] == NumbersArray[i + 1])
            {
                //We fill in the temp working variable.
                CurrentSequence += ", " + NumbersArray[i];
            }
            else
            {
                //If the lenght of the working string is bigger than
                //the lenght of the final string then we put the temp string into the final one.
                if (CurrentSequence.Length > MaxSequence.Length)
                {
                    MaxSequence = CurrentSequence;
                    
                }
                //We need to reset the temp working string and add the next array value to it.
                //NOTE: We need to reset and add the next value in the array in order to iterate 
                //through the array correctly!
                CurrentSequence = "" + NumbersArray[i+1];
            }
        }
        Console.WriteLine(MaxSequence);
    }
}

