﻿namespace SchoolProblem
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    class Student: People, ISchool
    {
        private string studentId = string.Empty;
        public Student() { }

        public Student(string name, string id)
        {
            this.ID = id;
            this.NAME = name;
        }
        public override string ToString()
        {
            return string.Format("");
        }
        public string GetComment()
        {
            return string.Format("");
        }

        public string ID
        {
            get
            {
                return this.studentId;
            }
            set
            {
                this.studentId = value;
            }
        }
    }
}
