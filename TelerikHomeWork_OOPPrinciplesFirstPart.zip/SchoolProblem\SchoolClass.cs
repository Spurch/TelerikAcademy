﻿/*
 * A class that will represent the different class groups 
 * in a given school. This class contains a set of teachers
 * a set of students and a unique identifier for each SchoolClass entity.
 */
namespace SchoolProblem
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    class SchoolClass: ISchool
    {
        private string classId;
        private List<Teacher> teachersList;
        private List<Student> studentsList;

        public SchoolClass() { }
        public SchoolClass(string id)
        {
            this.ID = id;
        }
        public SchoolClass(string id, List<Teacher> teachers, List<Student> students)
        {
            this.ID = id;
            this.TEACHERS = teachers;
            this.STUDENTS = students;
        }
        public override string ToString()
        {
            return string.Format("");
        }
        public string GetComment()
        {
            return string.Format("");
        }

        public void AddStudent(Student newStudent)
        {
            this.STUDENTS.Add(newStudent);
        }
        public void RemoveStudent(Student exStudent)
        {
            this.STUDENTS.Remove(exStudent);
        }

        public void AddTeacher(Teacher newTeacher)
        {
            this.TEACHERS.Add(newTeacher);
        }
        public void RemoveTeacher(Teacher exTeacher)
        {
            this.TEACHERS.Remove(exTeacher);
        }

        public string ID
        {
            get
            {
                return this.classId;
            }
            set
            {
                this.classId = value;
            }
        }
        public List<Teacher> TEACHERS
        {
            private get
            {
                return this.teachersList;
            }
            set
            {
                this.teachersList = value;
            }
        }
        public List<Student> STUDENTS
        {
            private get
            {
                return this.studentsList;
            }
            set
            {
                this.studentsList = value;
            }
        }
    }
}
