﻿/*
 * 
 */
namespace SchoolProblem
{
    using System;
    class Program
    {
        static void Main()
        {

        }
    }
}
