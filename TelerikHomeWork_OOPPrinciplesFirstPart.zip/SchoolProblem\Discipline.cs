﻿namespace SchoolProblem
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    class Discipline : ISchool
    {
        private string disciplineName;
        private double numberOfLectures;
        private double numberOfExercises;

        public Discipline() { }

        public Discipline(string name)
        {
            this.NAME = name;
        }

        public Discipline(string name, int lectures, int exercises)
        {
            this.NAME = name;
            this.LECTURES = lectures;
            this.EXERCISES = exercises;
        }

        public override string ToString()
        {
            return string.Format("");
        }
        public string GetComment()
        {
            return string.Format("");
        }

        public string NAME
        {
            get
            {
                return this.disciplineName;
            }
            set
            {
                this.disciplineName = value;
            }
        }

        public double LECTURES
        {
            get
            {
                return this.numberOfLectures;
            }
            set
            {
                this.numberOfLectures = value;
            }
        }
        public double EXERCISES
        {
            get
            {
                return this.numberOfExercises;
            }
            set
            {
                this.numberOfExercises = value;
            }
        }
    }
}
