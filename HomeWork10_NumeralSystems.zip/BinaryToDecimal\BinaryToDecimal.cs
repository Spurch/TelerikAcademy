﻿/*
 Problem 2. Binary to decimal
    Write a program to convert binary numbers to their decimal representation. 
 */
using System;
class BinaryToDecimal
{
    public static decimal BinToDec(string BinaryValue)
    {
        //Long variable to hold the final result.
        decimal DecimalValue = 0;
        //This variable will hold the current bit value.
        int temp = 0;
        //We need a counter because we are going to read the string backwards.
        int flag = 0;
        //We start going through the string backwards.
        for (int i = BinaryValue.Length - 1; i >= 0; i--)
        {
            //We parse the string to check the current bit value.
            temp = Int32.Parse(BinaryValue[i].ToString());
            //We are interested only in the 1s for our calculation.
            if (temp == 1)
            {
                //We increment the sum in the final result
                //1<<flag basically gives us 2^flag.
                DecimalValue += temp * (1 << flag);
            }
            //We increase the counter.
            flag++;
        }
        return DecimalValue;
    }
    static void Main()
    {
        Console.WriteLine("Input value:");
        string Value = Console.ReadLine();
        Console.WriteLine(BinToDec(Value));
    }
}

