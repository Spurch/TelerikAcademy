﻿/*
 Problem 5. Hexadecimal to binary
    Write a program to convert hexadecimal numbers to binary numbers (directly). 
 */
using System;
using System.Text;

class HexToBinary
{
    public static string HexToBin(string HexValue)
    {
        StringBuilder ResultString = new StringBuilder(HexValue.Length * 4);
        foreach (char c in HexValue)
        {
            //If its a normal dec value we get the value directly.
            if (c >= '0' && c <= '9')
            {
                ResultString.Append(ReadyValues[c - '0']);
            }
            //if its a letter - we substract a/A and add 10
            //as a/A represents the value 10 in hexadecimal.
            else if (c >= 'a' && c <= 'f')
            {
                ResultString.Append(ReadyValues[c - 'a' + 10]);
            }
            else if (c >= 'A' && c <= 'F')
            {
                ResultString.Append(ReadyValues[c - 'A' + 10]);
            }
            else
            {
                throw new FormatException("Invalid hex digit: " + c);
            }
        }
        return ResultString.ToString();
    }
    static void Main()
    {
        Console.WriteLine("Input value:");
        string Value = Console.ReadLine();
        Console.WriteLine(HexToBin(Value));
    }

    //We prepare an array with the binary values
    //for all hex digits from 1 to F/15.
    static readonly string[] ReadyValues =
{"0000", "0001", "0010", "0011",
"0100", "0101", "0110", "0111",
"1000", "1001", "1010", "1011",
"1100", "1101", "1110", "1111"};

}


