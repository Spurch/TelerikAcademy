﻿/*
 Problem 6. Binary to hexadecimal
 Write a program to convert binary numbers to hexadecimal numbers (directly). 
 */
using System;
using System.Collections.Generic;
class BinaryToHex
{
    public static string BinToHex(string BinaryValue)
    {
        List<string> ReadyValues = new List<string>() {"0000", "0001", "0010", "0011",
                                                       "0100", "0101", "0110", "0111",
                                                       "1000", "1001", "1010", "1011",
                                                       "1100", "1101", "1110", "1111"};
        BinaryValue.ToUpper();
        if (BinaryValue.Length % 4 > 0)
        {
            BinaryValue = new string('0', 4 - (BinaryValue.Length % 4)) + BinaryValue;
        }
        string HexValue = "";
        int Flag = 0;
        for (int i = 0; i < BinaryValue.Length / 4; i++)
        {
            string TempStr = BinaryValue.Substring(i * 4, 4);
            Flag = ReadyValues.IndexOf(TempStr);
            if (Flag == -1)
            {
                Console.WriteLine("Invalid input. Execution terminated.");
                return "-1";
            }
            if (Flag < 10)
                HexValue = HexValue + (char)(Flag + 48);
            else
                HexValue = HexValue + (char)(Flag + 55);
        }
        return HexValue;
    }
    static void Main()
    {
        Console.WriteLine("Input value:");
        string Value = Console.ReadLine();
        Console.WriteLine(BinToHex(Value));
    }
}

