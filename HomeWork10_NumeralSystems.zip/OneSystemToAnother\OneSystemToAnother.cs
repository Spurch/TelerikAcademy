﻿/*
 Problem 7. One system to any other
 Write a program to convert from any numeral system of
 given base s to any other numeral system of base d (2 ≤ s, d ≤ 16). 
 */
using System;
using System.Text;
class OneSystemToAnother
{
    private static string ConvertNumber(long Number, int System)
    {
        StringBuilder ResultString = new StringBuilder();
        long Remainder = 0;
        while (Number > 0)
        {
            Remainder = Number % System;
            ResultString.Insert(0, CalculateRem(Remainder));
            Number /= System;
        }
        return ResultString.ToString();
    }
    private static string CalculateRem(long Value)
    {
        switch (Value)
        {
            case 0:
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
            case 7:
            case 8:
            case 9:
                return Value.ToString();
            case 10: return "A";
            case 11: return "B";
            case 12: return "C";
            case 13: return "D";
            case 14: return "E";
            case 15: return "F";
            default: throw new ArgumentOutOfRangeException("Invalid numeral system!");
        }
    }
    static void Main()
    {
        Console.WriteLine("Enter first system S (2 <= S <=16): ");
        int S = int.Parse(Console.ReadLine());
        Console.WriteLine("Enter value to convert:");
        string number = Console.ReadLine();
        Console.WriteLine("Enter second system D (2<= D <=16): ");
        int D = int.Parse(Console.ReadLine());
        long DecimalValue = Convert.ToInt64(number, S);
        if (D == 10)
        {
            Console.WriteLine(DecimalValue);
        }
        else
        {
            string ResultString = ConvertNumber(DecimalValue, D);
            Console.WriteLine(ResultString);
        }
    }
}
