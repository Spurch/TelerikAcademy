﻿/*
 Problem 3. Decimal to hexadecimal
    Write a program to convert decimal numbers to their hexadecimal representation. 
 */
using System;
class DecimalToHex
{
    public static string DecToHex(decimal Value)
    {
        string HexValue = "";
        int Reminder = 0;
        do
        {
            //We get the current reminder.
            Reminder = (int)Value % 16;
            //Since we are converting to hex we first 
            //need to check if the reminder is below 10.
            if ((int)Value % 16 <= 9)
            {
                //We decrease the value of Value
                Value /= 16;
                //We append the current reminder to the string.
                HexValue += Reminder;
            }
            //If the reminder is >10 then we use a switch statement
            //to handle the cases between 10 and 15.
            else
            {
                switch (Reminder)
                {
                    case 10:
                        Value /= 16;
                        HexValue += "A";
                        break;
                    case 11:
                        Value /= 16;
                        HexValue += "B";
                        break;
                    case 12:
                        Value /= 16;
                        HexValue += "C";
                        break;
                    case 13:
                        Value /= 16;
                        HexValue += "D";
                        break;
                    case 14:
                        Value /= 16;
                        HexValue += "E";
                        break;
                    case 15:
                        Value /= 16;
                        HexValue += "F";
                        break;
                }
            }
            //While the Value is bigger than 0.
        } while (Value > 0.5M);

        char[] Arr = HexValue.ToCharArray();
        Array.Reverse(Arr);
        return new string(Arr);
    }
    static void Main()
    {
        Console.WriteLine("Input value:");
        decimal Value = decimal.Parse(Console.ReadLine());
        Console.WriteLine(DecToHex(Value)); 
    }
}

