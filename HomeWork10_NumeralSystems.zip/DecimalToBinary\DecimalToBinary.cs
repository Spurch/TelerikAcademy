﻿/*
Problem 1. Decimal to binary
    Write a program to convert decimal numbers to their binary representation.
 */
using System;
class DecimalToBinary
{
    public static string DecToBin(decimal Value)
    {
        //We are going to store the current reminder here.
        int Reminder = 0;
        //The string for the result.
        string result = "";
        do
        {
            //We get the current reminder.
            Reminder = (int)Value % 2;
            //We decrease the value of Value
            Value /= 2;
            //We append the current reminder to the string.
            result += Reminder;
            //While the Value is bigger than 0.
        } while (Value > 0.5M);

        char[] Arr = result.ToCharArray();
        Array.Reverse(Arr);
        return new string(Arr);
    }
    static void Main()
    {
        Console.WriteLine("Input value:");
        decimal Value = decimal.Parse(Console.ReadLine());
        Console.WriteLine(DecToBin(Value)); 
    }
}

