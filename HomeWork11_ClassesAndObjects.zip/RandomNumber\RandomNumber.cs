﻿/*
 Problem 2. Random numbers
 Write a program that generates and prints to the console 10 
 random values in the range [100, 200]. 
 */
using System;
class RandomNumber
{
    static void Main()
    {
        int Count = 10;
        int Min = 100;
        int Max = 200;
        int[] RandArr = new int[Count];
        Console.WriteLine("---------------------------------------------------------------");
        Console.WriteLine("Generating {0} random numbers in the range [{1}, {2}]...", Count, Min, Max);
        Console.WriteLine("---------------------------------------------------------------");
        Console.WriteLine();
        Random rand = new Random();
        for (int i = 0; i < Count; i++)
        {
            RandArr[i] = rand.Next(Min, Max + 1); 
        }
        Console.WriteLine(string.Join(",", RandArr));
        Console.WriteLine();
    }
}

