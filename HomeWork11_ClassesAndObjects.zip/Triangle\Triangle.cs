﻿/*
 Problem 4. Triangle surface
    Write methods that calculate the surface of a triangle by given:
        Side and an altitude to it;
        Three sides;
        Two sides and an angle between them;
    Use System.Math. 
 */
using System;
class Triangle
{
    public static double TriangleSurfaceBySides(double a, double b, double c)
    {
        double P = 0.5 * (a + b + c);
        double Surface = Math.Sqrt(P*(P-a)*(P-b)*(P-c));
        return Surface;
    }

    public static double TriangleSurfaceBySideAltitude(double a, double ha)
    {
        double Surface = 0.5 * (a * ha);
        return Surface;
    }

    public static double TriangleSurfaceBySidesAngle(double a, double b, double Angle){
        Angle = (Math.PI * Angle) / 180;
        double Surface = 0.5 * (a*b*Math.Sin(Angle));
        return Surface;
    }
    static void Main()
    {
        double a = 3;
        double b = 4;
        double c = 5;
        double height = 4;
        double Angle = 90;
        Console.Write("Surface by three sides: ");
        Console.WriteLine(TriangleSurfaceBySides(a,b,c));
        Console.Write("Surface by two sides and an angle: ");
        Console.WriteLine(TriangleSurfaceBySidesAngle(a,b,Angle));
        Console.Write("Surface by a side and altitude: ");
        Console.WriteLine(TriangleSurfaceBySideAltitude(a,height));
    }
}

