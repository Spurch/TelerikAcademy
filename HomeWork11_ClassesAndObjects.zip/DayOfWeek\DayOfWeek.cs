﻿/*
 Problem 3. Day of week
    Write a program that prints to the console which day of the week is today.
    Use System.DateTime. 
 */
using System;
class DayOfWeek
{
    static void Main()
    {
        Console.WriteLine("Today, {0} is {1}. The {2} day of {3}.",DateTime.Now.ToShortDateString(), DateTime.Now.DayOfWeek, DateTime.Now.DayOfYear, DateTime.Now.Year);
    }
}

