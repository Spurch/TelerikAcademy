﻿/*
 Problem 1. Leap year
    Write a program that reads a year from the console and checks whether it is a leap one.
    Use System.DateTime. 
 */
using System;
class LeapYear
{

    static void Main()
    {
        Console.WriteLine("Please enter an year:");
        int year;
        if (Int32.TryParse(Console.ReadLine(), out year) && year <= 9999 && year >= 1)
        {
            Console.WriteLine("Is year {0} a leap year? {1}", year, DateTime.IsLeapYear(year));
        }else{
            Console.WriteLine("Incorrect input!");
        }
    }
}

