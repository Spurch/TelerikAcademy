﻿/*
 *Problem 5. Workdays
 Write a method that calculates the number of workdays between 
 today and given date, passed as parameter.
 Consider that workdays are all days from Monday to Friday except a 
 fixed list of public holidays specified preliminary as array. 
 */
using System;
using System.Collections.Generic;
class WorkDays
{
    public static bool isHoliday(DateTime Date)
    {
        var HolidaysList = new List<DateTime>();
        HolidaysList.Add(new DateTime(2015, 03, 02));//Added as a holiday because of the 3th of March.
        HolidaysList.Add(new DateTime(2015, 03, 03));//The liberation of Bulgaria from Otoman slavery.
        HolidaysList.Add(new DateTime(2015, 04, 10));//Easter holiday.
        HolidaysList.Add(new DateTime(2015, 04, 11));//Easter holiday.
        HolidaysList.Add(new DateTime(2015, 04, 12));//Easter holiday.
        HolidaysList.Add(new DateTime(2015, 04, 13));//Easter holiday.
        HolidaysList.Add(new DateTime(2015, 05, 01));//Labor's day.
        HolidaysList.Add(new DateTime(2015, 05, 06));//St. George's Day - The day of the Bulgarian Army and courage.
        HolidaysList.Add(new DateTime(2015, 09, 21));//Bulgarian Independence Day.
        HolidaysList.Add(new DateTime(2015, 09, 22));//Bulgarian Independence Day.
        HolidaysList.Add(new DateTime(2015, 12, 24));//Christmas holidays.
        HolidaysList.Add(new DateTime(2015, 12, 25));//Christmas holidays.
        HolidaysList.Add(new DateTime(2015, 12, 26));//Christmas holidays.
        HolidaysList.Add(new DateTime(2015, 12, 31));//New year's eve.
        HolidaysList.Add(new DateTime(2016, 01, 01));//New year's eve.

        bool isHD = false;
        if (Date == HolidaysList.Find(temp => temp == Date))
        {
            isHD = true;
        }
        return isHD;
    }
    public static int GetWorkDays(DateTime TillDate)
    {
        int NumberOfWorkDays = 0;
        DateTime CurrentDate = DateTime.Today;
        if (TillDate < CurrentDate)
        {
            Console.WriteLine("Incorrect Input!");
        }
        for (var day = CurrentDate; day.Date <= TillDate.Date; day = day.AddDays(1))
        {
            if (!isHoliday(day))
            {
                if (day.DayOfWeek.ToString() != "Saturday" && day.DayOfWeek.ToString() != "Sunday")
                {
                    NumberOfWorkDays++;
                }
            }
        }
        return NumberOfWorkDays;
    }
    static void Main()
    {
        DateTime date = new DateTime(2015, 03, 03);
        Console.WriteLine(GetWorkDays(date));
    }
}

