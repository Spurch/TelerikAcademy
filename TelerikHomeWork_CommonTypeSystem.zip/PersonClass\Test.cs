﻿namespace PersonClass
{
    using System;
    class Test
    {
        static void Main()
        {
            Person newPerson00 = new Person("Petko", 25);
            Person newPerson01 = new Person("Mitko");
            Person newPerson02 = new Person("Ivcho", null);
            Console.WriteLine("--------------------");
            Console.WriteLine(newPerson00.ToString());
            Console.WriteLine("--------------------");
            Console.WriteLine(newPerson01.ToString());
            Console.WriteLine("--------------------");
            Console.WriteLine(newPerson02.ToString());
            Console.WriteLine("--------------------");
        }
    }

}