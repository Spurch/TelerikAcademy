﻿namespace StudentClass
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    enum UNIVERSITY { SU, TU, NBU, NULL}
    enum FACULTY { FBO, BF, MF, FMI, NULL}
    enum SPECIALTY { INFORMATICS, COMPUTERSCIENCE, KST, NULL}
    class Student: ICloneable, IComparable<Student>
    {
        private string firstName = string.Empty;
        private string middleName = string.Empty;
        private string lastName = string.Empty;
        private string studentSSN = string.Empty;
        private string studentAddress = string.Empty;
        private string mobilePhone = string.Empty;
        private string mailAddress = string.Empty;
        private string studentCourse = string.Empty;
        private UNIVERSITY university;
        private FACULTY faculty;
        private SPECIALTY specialty;

        #region Constructors
        private Student() 
        { 
            this.StudentUniversity = UNIVERSITY.NULL;
            this.StudentSpecialty = SPECIALTY.NULL;
            this.StudentFaculty = FACULTY.NULL;
        }
        public Student(string firstName, string middleName, string lastName, string studentSSN):
            this()
        {
            this.FIRSTNAME = firstName;
            this.MIDDLENAME = middleName;
            this.LASTNAME = lastName;
            this.SSN = studentSSN;
        }
        public Student(string firstName, string middleName, string lastName, string studentSSN, string address, string mobile, string mail, string course):
            this(firstName, middleName, lastName, studentSSN)
        {
            this.ADDRESS = address;
            this.MOBILE = mobile;
            this.MAIL = mail;
            this.COURSE = course;
        }

        public Student(string firstName, string middleName, string lastName, string studentSSN, 
            string address, string mobile, string mail, string course, UNIVERSITY university, FACULTY faculty, SPECIALTY speacialty):
            this(firstName, middleName, lastName, studentSSN, address, mobile, mail, course)
        {
            this.StudentUniversity = university;
            this.StudentFaculty = faculty;
            this.StudentSpecialty = speacialty;
        }
        #endregion

        #region Methods

        object ICloneable.Clone()
        {
            return this.Clone();
        }

        public Student Clone()
        {
            return new Student(this.FIRSTNAME, this.MIDDLENAME, this.LASTNAME, this.SSN, this.ADDRESS, this.MOBILE,
                this.MAIL, this.COURSE, this.StudentUniversity, this.StudentFaculty, this.StudentSpecialty);
        }

        public int CompareTo(Student otherStudent){
            if (string.Compare(this.FULLNAME, otherStudent.FULLNAME) < 0)
            {
                return -1;
            }
            else if (string.Compare(this.FULLNAME, otherStudent.FULLNAME) == 0)
            {
                if (string.Compare(this.SSN, otherStudent.SSN) < 0)
                {
                    return -1;
                }
                else if (string.Compare(this.SSN, otherStudent.SSN) == 0)
                {
                    return 0;
                }
                else
                {
                    return 1;
                }
            }
            else
            {
                return 1;
            }
        }
        public override string ToString()
        {
            return string.Format("Student:\nName:{0}\nSSN:{1}\nDetails:\nAddress:{2}, Mobile:{3}, Mail:{4}\nCourse:{5}, {6}, {7}, {8}",
                this.FULLNAME, this.SSN, this.ADDRESS, this.MOBILE, this.MAIL, this.COURSE, this.StudentUniversity, this.StudentFaculty, this.StudentSpecialty);
        }

        public override bool Equals(object obj)
        {
            Student s1 = obj as Student;
            return this.studentSSN == s1.studentSSN && this.FULLNAME == s1.FULLNAME;
        }

        public override int GetHashCode()
        {
            return this.SSN.GetHashCode() ^ this.FULLNAME.GetHashCode() ^ 119 ^ 243;
        }

        public static bool operator ==(Student s1, Student s2)
        {
            return s1.Equals(s2);
        }
        public static bool operator !=(Student s1, Student s2)
        {
            return !(s1.Equals(s2));
        }
        #endregion

        #region Properties
        public string SSN
        {
            get
            {
                return this.studentSSN;
            }
            set 
            {
                this.studentSSN = value;
            }
        }
        public string FULLNAME
        {
            get
            {
                return this.FIRSTNAME + " " + this.MIDDLENAME + " " + this.LASTNAME;
            }
        }
        public string FIRSTNAME
        {
            get
            {
                return this.firstName;
            }
            set
            {
                this.firstName = value;
            }
        }
        public string MIDDLENAME
        {
            get
            {
                return this.middleName;
            }
            set
            {
                this.middleName = value;
            }
        }
        public string LASTNAME
        {
            get
            {
                return this.lastName;
            }
            set
            {
                this.lastName = value;
            }
        }
        public string ADDRESS
        {
            get
            {
                return this.studentAddress;
            }
            set
            {
                this.studentAddress = value;
            }
        }
        public string MOBILE
        {
            get
            {
                return this.mobilePhone;
            }
            set
            {
                this.mobilePhone = value;
            }
        }
        public string MAIL
        {
            get
            {
                return this.mailAddress;
            }
            set
            {
                this.mailAddress = value;
            }
        }
        public string COURSE
        {
            get
            {
                return this.studentCourse;
            }
            set
            {
                this.studentCourse = value;
            }
        }
        public UNIVERSITY StudentUniversity
        {
            get
            {
                return this.university;
            }
            set
            {
                this.university = value;
            }
        }
        public FACULTY StudentFaculty
        {
            get
            {
                return this.faculty;
            }
            set
            {
                this.faculty = value;
            }
        }
        public SPECIALTY StudentSpecialty
        {
            get
            {
                return this.specialty;
            }
            set
            {
                this.specialty = value;
            }
        }
        #endregion
    }
}
