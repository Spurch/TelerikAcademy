﻿namespace StudentClass
{
    using System;
    class Test
    {
        static void Main()
        {
            Student newStudent00 = new Student("Stoyan", "Pavlov", "Nikolov", "1234567", "Sofia, Bulgaria", "0888457869", "s.nikolov@gmail.com", "0001", UNIVERSITY.NBU, FACULTY.FBO, SPECIALTY.COMPUTERSCIENCE);
            Student newStudent01 = new Student("Petar", "Stoyanov", "Ivanov", "3334567", "Sofia, Bulgaria", "0887841356", "petarivanov@gmail.com", "0002", UNIVERSITY.SU, FACULTY.BF, SPECIALTY.INFORMATICS);
            Student newStudent02 = new Student("Petar", "Stoyanov", "Ivanov", "3334567", "Sofia, Bulgaria", "0887841356", "petarivanov@gmail.com", "0002", UNIVERSITY.SU, FACULTY.BF, SPECIALTY.INFORMATICS);
            Console.WriteLine(newStudent00.ToString());
            Console.WriteLine(newStudent00.Equals(newStudent01));
            Console.WriteLine("Is student 01 == to student 02: {0}", newStudent01 == newStudent02);
            Console.WriteLine("Is student 00 != to student 01: {0}", newStudent00 != newStudent01);
            Console.WriteLine("Compare student 00 with student 01: {0}", newStudent00.CompareTo(newStudent01));

            Student newClone = newStudent00.Clone();
            Console.WriteLine("Is clone equal to original: {0}", newClone.Equals(newStudent00));
        }
    }

}