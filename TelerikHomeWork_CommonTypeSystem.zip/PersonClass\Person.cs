﻿namespace PersonClass
{
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

    class Person
    {
        private uint? age;
        private string name;

        private Person() { }

        public Person(string name):
            this()
        {
            this.NAME = name;
            this.AGE = null;
        }
        public Person(string name, uint? age):
            this(name)
        {
            this.AGE = age;
        }

        public override string ToString()
        {
            if (this.AGE == null)
            {
                return string.Format("Person name:{0}\nNo age specified!", this.NAME);
            }
            else
            {
                return string.Format("Person name:{0}\nPerson age:{1}", this.NAME, this.AGE);
            }
        }

        public string NAME
        {
            get
            {
                return this.name;
            }
            set
            {
                this.name = value;
            }
        }
        public uint? AGE
        {
            get
            {
                return this.age;
            }
            set
            {
                this.age = value;
            }
        }
    }
}
