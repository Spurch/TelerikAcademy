﻿/*
 Problem 4. Binary search
 Write a program, that reads from the console an array of N integers and an integer K,
 sorts the array and using the method Array.BinSearch() finds the largest number in the 
 array which is ≤ K. 
 */
using System;
using System.Linq;
class BinSearch
{
    static void Main()
    {
        Console.WriteLine("-----------------------------------------------------------------------------");
        Console.WriteLine("Problem N4 - Using the integrated BinarySearch to look for a value.");
        Console.WriteLine("-----------------------------------------------------------------------------");
        Console.WriteLine("Enter integers on one line each value separated by a , and/or a space:");
        int[] arr = Console.ReadLine().
            Split(new char[] { ' ', ',', '\t' }, StringSplitOptions.RemoveEmptyEntries)
            .Select(x => int.Parse(x)).ToArray();
        Console.WriteLine("Enter value for K:");
        int K = Int32.Parse(Console.ReadLine());

        //We sort the array.
        Array.Sort(arr);
        Console.WriteLine("-----------------------------------------------------------------------------");
        Console.WriteLine("Array after sorting: ");
        for (int i = 0; i < arr.Length; i++)
        {
            Console.Write("{0}, ", arr[i]);
        }
        Console.WriteLine();
        Console.WriteLine("-----------------------------------------------------------------------------");
        //If K is smaller than the first element of the array then we don't have 
        //such element X that X <=K.
        if (K < arr[0])
        {
            Console.WriteLine("There is no such element in the array.");
        }
        //If K is larger than the last element of the array then we do have 
        //such element X that X <=K and that is the last element of the array.
        else if (K >= arr[arr.Length - 1])
        {
            Console.WriteLine("The element is {0} at {1} position in the array.", arr[arr.Length - 1], arr.Length - 1);
        }
        else
        {
            //We use BinarySearch to check for the element
            int index = Array.BinarySearch(arr, K);
            //If the index is positive then we have a X sush as X == K.
            //And its on the [index] position of the array.
            if (index > 0)
            {
                Console.WriteLine("The element is {0} at {1} position in the array.", arr[index], index);
            }
            //If index is negative then we don't have an element X such as X == K.
            //The negative value of index is actually the bitwise compliment of the
            //next element in the array that is larger than K.
            if (index < 0)
            {
                //We get element actual position by using XOR.
                index = ~index;
                //Then we get the element at position [index-1] - this is the largest X such as X <= K.
                Console.WriteLine("The element is {0} at {1} position in the array.", arr[index-1], index-1);
            }

        }
    }
}

