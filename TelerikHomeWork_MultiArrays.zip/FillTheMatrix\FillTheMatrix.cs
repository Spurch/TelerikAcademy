﻿/*
 * 
 */
using System;
class FillTheMatrix
{
    public static void ResetMatrix(int[,] Arr, int size)
    {
        for (int i = 0; i < size; i++)
        {
            for (int j = 0; j < size; j++)
            {
                Arr[i, j] = 0;

            }
        }
    }
    static void Main()
    {
        Console.WriteLine("-----------------------------------------------------------------------------");
        Console.WriteLine("Problem N1 - Fill and print matrices.");
        Console.WriteLine("-----------------------------------------------------------------------------");
        Console.WriteLine("Enter value for N:");
        int n = Int32.Parse(Console.ReadLine());
        int[,] Arr = new int[n, n];
        int temp = 0;
        int stemp = 0;
        //First Matrix fill and print
        for (int i = 0; i < n; i++)
        {
            temp = i + 1;
            for (int j = 0; j < n; j++)
            {
                Arr[i, j] = temp;
                temp += n;
            }
        }
        Console.WriteLine("First matrix:");
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                Console.Write("{0} ", Arr[i, j]);
            }
            Console.WriteLine();
        }

        //We reset the matrix back to 0s.
        ResetMatrix(Arr, n);
        Console.WriteLine();

        //Second Matrix fill and print
        for (int i = 0; i < n; i++)
        {
            temp = i + 1;
            for (int j = 0; j < n; j++)
            {
                if (j % 2 == 1)
                {
                    stemp = ((j + 1) * n) - i;
                    Arr[i, j] = stemp;
                    temp += n;
                }
                else
                {
                    Arr[i, j] = temp;
                    temp += n;
                }
            }
        }
        Console.WriteLine("Second matrix:");
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                Console.Write("{0} ", Arr[i, j]);
            }
            Console.WriteLine();
        }

        //We reset the matrix back to 0s.
        ResetMatrix(Arr, n);
        Console.WriteLine();

        ////Third Matrix fill and print
        //for (int i = n-1; i >= 0; i--)
        //{
        //    for (int j = 0; j < n; j++)
        //    {
        //        Arr[i, j] = i*j+1;
        //    }
        //}
        //Console.WriteLine("Third matrix:");
        //for (int i = 0; i < n; i++)
        //{
        //    for (int j = 0; j < n; j++)
        //    {
        //        //Console.Write("i{0},j{1},{2} | ", i, j, Arr[i,j]);
        //        Console.Write("{0}, ", Arr[i, j]);
        //    }
        //    Console.WriteLine();
        //}

        ////We reset the matrix back to 0s.
        //ResetMatrix(Arr, n);
        //Console.WriteLine();

        //Fourth Matrix fill and print
        int size = n;
        int y = 0;
        int x = 0;
        int currentCount = 1;
        while (size > 0)
        {
            for (int i = y; i <= y + size - 1; i++)
            {
                Arr[i, x] = currentCount++;
            }

            for (int j = x + 1; j <= x + size - 1; j++)
            {
                Arr[y + size - 1, j] = currentCount++;
            }

            for (int i = y + size - 2; i >= y; i--)
            {
                Arr[i, x + size - 1] = currentCount++;
            }

            for (int i = x + size - 2; i >= x + 1; i--)
            {
                Arr[y, i] = currentCount++;
            }

            x = x + 1;
            y = y + 1;
            size = size - 2;
        }
        Console.WriteLine("Fourth matrix:");
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                Console.Write("{0} ", Arr[i, j]);
            }
            Console.WriteLine();
        }
    }
}

