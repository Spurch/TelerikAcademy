﻿namespace Shapes
{
    using System;
    class Program
    {
        static void Main()
        {
            Shape[] shapeArray = new Shape[5];
            shapeArray[0] = new Rectangle(2, 2);
            shapeArray[1] = new Rectangle(3, 2);
            shapeArray[2] = new Square(4);
            shapeArray[3] = new Triangle(5, 3);
            shapeArray[4] = new Triangle(3, 1);
            for (int i = 0; i < shapeArray.Length; i++)
            {
                Console.WriteLine("Shape is of type: {0}, Surface is:{1}",shapeArray[i].GetType().Name, shapeArray[i].CalculateSurface());
            }
        }
    }
}
