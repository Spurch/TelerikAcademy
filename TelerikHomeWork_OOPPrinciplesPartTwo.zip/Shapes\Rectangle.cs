﻿namespace Shapes
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    class Rectangle: Shape
    {
        public Rectangle() { }
        public Rectangle(double height, double width):
            this()
        {
            this.HEIGHT = height;
            this.WIDTH = width;
        }
        public override double CalculateSurface()
        {
            double result = 1;
            result *= this.HEIGHT * this.WIDTH;
            return result;
        }
    }
}
