﻿namespace BankSystem
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    class Mortgage : Account
    {
        private Mortgage() { }
        /*
         * Predefined constructors that use the base Account constructors!
         */
        public Mortgage(string id, Customer customer, DateTime fromDate, DateTime dueDate) :
            base(id, customer, fromDate, dueDate) { }
        //NOTE: We initialize the canWithdraw variable with false by default!
        public Mortgage(string id, Customer customer, DateTime fromDate, DateTime dueDate, decimal balance, decimal rate) :
            base(id, customer, fromDate, dueDate, balance, rate, true, false) { }

        /*
         * Mortgages can only deposit money so we override
         * only the DepositMoney() method. 
         */
        public override void DepositMoney(decimal value)
        {
            if (value == 0) { throw new ArgumentOutOfRangeException("Deposit value must be non-zero!"); }
            if (value < 0) { throw new ArgumentOutOfRangeException("Deposit value must be non-negative!"); }
            this.BALANCE += value;
        }

        /*
        * Mortgage class overrides and implements its own CalculateInterest() method!
        * The method will return the interest till DateTime.Now a.k.a the date we are calling
        * the method. If the date is before the FROMDATE value the method will throw and exception.
        * If the date is after the DUEDATE value the method will return the interest for the whole period.
        * If the date is between FROMDATE and DUEDATE the method will return the interest till that date.
        */
        public override decimal CalculateInterest()
        {
            decimal result = default(decimal);
            int period = default(int);
            if (DateTime.Now > this.DUEDATE)
            {
                period = ((this.DUEDATE.Year - this.FROMDATE.Year) * 12) + this.DUEDATE.Month - this.FROMDATE.Month;
            }
            else if (DateTime.Now < this.FROMDATE)
            {
                throw new ArgumentOutOfRangeException("Invalid Date!");
            }
            else
            {
                period = ((this.DUEDATE.Year - DateTime.Now.Year) * 12) + this.DUEDATE.Month - DateTime.Now.Month;
            }
            
            if (this.CUSTOMER.GetType().Name == "Individual")
            {
                if (period > 6)
                {
                    result = (period - 6) * this.RATE;
                }
            }
            else if (this.CUSTOMER.GetType().Name == "Company")
            {
                if (period <= 12)
                {
                    result = period * (this.RATE/2);
                }
                else
                {
                    result = 12 * (this.RATE / 2) + (period - 12) * this.RATE;
                }
            }
            return result;
        }
    }
}
