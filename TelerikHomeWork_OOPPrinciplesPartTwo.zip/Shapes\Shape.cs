﻿namespace Shapes
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    abstract class Shape
    {
        private double height = default(double);
        private double width = default(double);

        public Shape() { }
        public Shape(double height, double width) :
            this()
        {
            this.HEIGHT = height;
            this.WIDTH = width;
        }
        public abstract double CalculateSurface();

        public double HEIGHT
        {
            get
            {
                return this.height;
            }
            set
            {
                if (value == 0) { throw new ArgumentOutOfRangeException("Shape height must be non-zero!"); }
                if (value < 0) { throw new ArgumentOutOfRangeException("Shape height must be non-negative!"); }
                this.height = value;
            }
        }
        public double WIDTH
        {
            get
            {
                return this.width;
            }
            set
            {
                if (value == 0) { throw new ArgumentOutOfRangeException("Shape width must be non-zero!"); }
                if (value < 0) { throw new ArgumentOutOfRangeException("Shape width must be non-negative!"); }
                this.width = value;
            }
        }
    }
}
