﻿namespace BankSystem
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    class Individual : Customer
    {
        private string firstName = string.Empty;
        private string lastName = string.Empty;

        private Individual():base() { }

        public Individual(string uic, string address, 
            string mobile, string firstName, string lastName):
            base(address, mobile, uic)
        {
            this.FIRSTNAME = firstName;
            this.LASTNAME = lastName;
        }
        public string FIRSTNAME
        {
            get
            {
                return this.firstName;
            }
            set
            {
                this.firstName = value;
            }
        }
        public string LASTNAME
        {
            get
            {
                return this.lastName;
            }
            set
            {
                this.lastName = value;
            }
        }
    }
}
