﻿namespace Shapes
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    class Square: Rectangle
    {
        public Square() { }
        public Square(double height):
            this()
        {
            this.HEIGHT = height;
            this.WIDTH = height;
        }

    }
}
