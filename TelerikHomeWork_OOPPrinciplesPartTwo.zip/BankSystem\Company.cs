﻿namespace BankSystem
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    class Company : Customer
    {
        private string companyRepresentative;
        private string companyName = string.Empty;
        
        private Company():base(){ }

        public Company(string name, string uic, string address, 
            string mobile, string contactName):
            base(address, mobile, uic)
        {
            this.COMPANY = name;
            this.REPRESENTATIVE = contactName;
        }
        public string COMPANY
        {
            get
            {
                return this.companyName;
            }
            set
            {
                this.companyName = value;
            }
        }
        public string REPRESENTATIVE
        {
            get
            {
                return this.companyRepresentative;
            }
            set
            {
                this.companyRepresentative = value;
            }
        }
    }
}
