﻿namespace Shapes
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    class Triangle: Shape
    {
        public Triangle() { }
        public Triangle(double height, double width):
            this()
        {
            this.HEIGHT = height;
            this.WIDTH = width;
        }
        public override double CalculateSurface()
        {
            double result = 1;
            result *= (this.HEIGHT * this.WIDTH) / 2;
            return result;
        }
    }
}
