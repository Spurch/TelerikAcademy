﻿namespace BankSystem
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    class Customer
    {
        //In Customer class we implement some fields that are common 
        //to both Individuals and Companies.
        private string customerAddress = string.Empty;
        private string customerMobile = string.Empty;
        private string customerUic = string.Empty;
        protected Customer() { }

        public Customer(string address, string mobile, string uic):
            this()
        {
            this.ADDRESS = address;
            this.MOBILE = mobile;
            this.UIC = uic;

        }

        public string ADDRESS
        {
            get
            {
                return this.customerAddress;
            }
            set
            {
                this.customerAddress = value;
            }
        }
        public string MOBILE
        {
            get
            {
                return this.customerMobile;
            }
            set
            {
                this.customerMobile = value;
            }
        }
        public string UIC
        {
            get
            {
                return this.customerUic;
            }
            set
            {
                this.customerUic = value;
            }
        }
    }
}
