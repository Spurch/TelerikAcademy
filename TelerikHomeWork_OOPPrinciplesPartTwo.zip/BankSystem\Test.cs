﻿namespace BankSystem
{
    using System;
    class Test
    {
        static void Main()
        {
            Bank newBank00 = new Bank("FooBankService", "FBS004269");
            Individual newIndividual00 = new Individual("7903276404", "Sofia, Bulgaria", "0887841980", "Emil", "Nikolov");
            Company newCompany00 = new Company("ACME LTD.", "131245443", "Sofia, Bulgaria", "0889453112", "Georgi Petrov"); 
            
            Loan newLoan00 = new Loan("00001", newIndividual00, Convert.ToDateTime("01.01.2015"), Convert.ToDateTime("06.01.2015"), 5000, 7.2M);
            Loan newLoan01 = new Loan("00001", newCompany00, Convert.ToDateTime("01.08.2014"), Convert.ToDateTime("01.08.2015"), 25000, 7.2M);
            Mortgage newMortgage00 = new Mortgage("00002", newCompany00, Convert.ToDateTime("01.01.2014"), Convert.ToDateTime("01.01.2029"), 255000, 4.5M);
            Mortgage newMortgage01 = new Mortgage("00003", newIndividual00, Convert.ToDateTime("01.01.2010"), Convert.ToDateTime("01.01.2025"), 55000, 5.5M);

            newBank00.ACCOUNTS.Add(newLoan00);
            newBank00.ACCOUNTS.Add(newLoan01);
            newBank00.ACCOUNTS.Add(newMortgage00);
            newBank00.ACCOUNTS.Add(newMortgage01);

            try
            {
                foreach (var account in newBank00.ACCOUNTS)
                {
                    Console.WriteLine("Account type: {0}\nThe interest is: {1}\n", 
                        account.GetType().Name, account.CalculateInterest());
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
