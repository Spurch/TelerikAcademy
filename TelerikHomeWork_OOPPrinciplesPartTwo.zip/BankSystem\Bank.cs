﻿namespace BankSystem
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    class Bank
    {
        private List<Account> bankAccountsList;
        private string bankName;
        private string bankId;
        private Bank()
        {
            bankAccountsList = new List<Account>();
        }

        public Bank(string name, string id)
            : this()
        {
            this.NAME = name;
            this.ID = id;
        }
        public string NAME
        {
            get
            {
                return this.bankName;
            }
            set
            {
                this.bankName = value;
            }
        }
        public string ID
        {
            get
            {
                return this.bankId;
            }
            set
            {
                this.bankId = value;
            }
        }
        public List<Account> ACCOUNTS
        {
            get
            {
                return this.bankAccountsList;
            }
            set
            {
                this.bankAccountsList = value;
            }
        }
    }
}
