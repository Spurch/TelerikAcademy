﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankSystem
{
    abstract class Account
    {
        private string accountId;
        private DateTime fromDate;
        private DateTime dueDate;
        private Customer accountCustomer;
        private decimal accountBalance = default(decimal);
        private decimal interestRate = default(decimal);
        private bool canDeposit = default(bool);
        private bool canWithdraw = default(bool);

        protected Account() { }

        public Account(string id, Customer customer, DateTime fromDate, DateTime dueDate):
            this()
        {
            this.ID = id;
            this.CUSTOMER = customer;
            this.FROMDATE = fromDate;
            this.DUEDATE = dueDate;
        }

        public Account(string id, Customer customer, DateTime fromDate, DateTime dueDate, decimal balance, decimal rate):
            this(id, customer, fromDate, dueDate)
        {
            this.BALANCE = balance;
            this.RATE = rate;
        }
        public Account(string id, Customer customer, DateTime fromDate, DateTime dueDate, decimal balance, decimal rate, bool deposit, bool withdraw) :
            this(id, customer, fromDate, dueDate, balance, rate)
        {
            this.canDeposit = deposit;
            this.canWithdraw = withdraw;
        }

        public virtual void DepositMoney(decimal value){}
        public virtual void WithdrawMoney(decimal value){}
        public abstract decimal CalculateInterest();

        public string ID{
            get
            {
                return this.accountId;
            }
            protected set
            {
                this.accountId = value;
            }
        }
        public DateTime DUEDATE
        {
            get
            {
                return this.dueDate;
            }
            set
            {
                this.dueDate = value;
            }
        }
        public DateTime FROMDATE
        {
            get
            {
                return this.fromDate;
            }
            set
            {
                this.fromDate = value;
            }
        }
        public Customer CUSTOMER
        {
            get
            {
                return this.accountCustomer;
            }
            set
            {
                this.accountCustomer = value;
            }
        }
        public decimal BALANCE
        {
            get
            {
                return this.accountBalance;
            }
            set
            {
                this.accountBalance = value;
            }
        }
        public decimal RATE
        {
            get
            {
                return this.interestRate;
            }
            set
            {
                this.interestRate = value;
            }
        }
    }
}
