﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankSystem
{
    abstract class Account
    {
        private string accountId;
        private DateTime fromDate;
        private DateTime dueDate;
        private Customer accountCustomer;
        private decimal accountBalance = default(decimal);
        private decimal interestRate = default(decimal);
        /*
         * Both the deposit and the withdraw variables are private
         * we are going to use them only in the base constructors!
         */
        private bool canDeposit = default(bool);
        private bool canWithdraw = default(bool);

        protected Account() { }

        /*
         * Set of predefined constructors that will be used 
         * by the child classes.
         */
        public Account(string id, Customer customer, DateTime fromDate, DateTime dueDate):
            this()
        {
            this.ID = id;
            this.CUSTOMER = customer;
            this.FROMDATE = fromDate;
            this.DUEDATE = dueDate;
        }

        public Account(string id, Customer customer, DateTime fromDate, DateTime dueDate, decimal balance, decimal rate):
            this(id, customer, fromDate, dueDate)
        {
            this.BALANCE = balance;
            this.RATE = rate;
        }
        public Account(string id, Customer customer, DateTime fromDate, DateTime dueDate, decimal balance, decimal rate, bool deposit, bool withdraw) :
            this(id, customer, fromDate, dueDate, balance, rate)
        {
            this.DEPOSIT = deposit;
            this.WITHDRAW = withdraw;
        }

        /*
         * Virtual methods that will be inherited by the child classes.
         * Deposit class will inherit both methods while Loan and Mortgage 
         * will inherit only the DepositMoney() method.
         */
        public virtual void DepositMoney(decimal value){}
        public virtual void WithdrawMoney(decimal value){}

        /*
         * All child classes will implement their own way of calculating 
         * the interest.
         */
        public abstract decimal CalculateInterest();

        /*
         * Set of public properties for the Account class.
         */
        public string ID{
            get
            {
                return this.accountId;
            }
            protected set
            {
                this.accountId = value;
            }
        }
        public DateTime DUEDATE
        {
            get
            {
                return this.dueDate;
            }
            set
            {
                this.dueDate = value;
            }
        }
        public DateTime FROMDATE
        {
            get
            {
                return this.fromDate;
            }
            set
            {
                this.fromDate = value;
            }
        }
        public Customer CUSTOMER
        {
            get
            {
                return this.accountCustomer;
            }
            set
            {
                this.accountCustomer = value;
            }
        }
        public decimal BALANCE
        {
            get
            {
                return this.accountBalance;
            }
            set
            {
                this.accountBalance = value;
            }
        }
        public decimal RATE
        {
            get
            {
                return this.interestRate;
            }
            set
            {
                this.interestRate = value;
            }
        }
        private bool DEPOSIT
        {
            get
            {
                return this.canDeposit;
            }
            set
            {
                this.canDeposit = value;
            }
        }
        private bool WITHDRAW
        {
            get
            {
                return this.canWithdraw;
            }
            set
            {
                this.canWithdraw = value;
            }
        }
    }
}
