﻿namespace InvalidRangeException
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    class InvalidRangeException<T> : Exception
    {
        private T startRange;
        private T endRange;

        private InvalidRangeException() { }
        public InvalidRangeException(string errorMsg, Exception innerException, T startRange, T endRange):
            base(string.Format("{0} {1} must be in the range {2} to {3}!", errorMsg, typeof(T), startRange, endRange), innerException)
        {
            this.START = startRange;
            this.END = endRange;
        }

        public InvalidRangeException(string errorMsg, T startRange, T endRange):
            this(errorMsg, null, startRange, endRange){}
        public T START
        {
            get
            {
                return this.startRange;
            }
            set
            {
                this.startRange = value;
            }
        }
        public T END
        {
            get
            {
                return this.endRange;
            }
            set
            {
                this.endRange = value;
            }
        }
    }
}
