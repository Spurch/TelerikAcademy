﻿namespace InvalidRangeException
{
    using System;
    class Test
    {
        static void Main()
        {
            Console.WriteLine("Input integer start range:");
            int startRange = Int32.Parse(Console.ReadLine());
            Console.WriteLine("Input integer end range:");
            int endRange = Int32.Parse(Console.ReadLine());
            try
            {
                Console.WriteLine("Input a value in the range {0} to {1}:", startRange, endRange);
                int value = Int32.Parse(Console.ReadLine());
                if (value < startRange || value > endRange)
                {
                    throw new InvalidRangeException<int>("ERROR!", startRange, endRange);
                }
                Console.WriteLine("You entered: {0}.\nYou must enter an invalid value to see the error message!", value);
            }
            catch (InvalidRangeException<int> ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.WriteLine("Input date start range(mm.dd.yyyy):");
            DateTime startDate = DateTime.Parse(Console.ReadLine());
            Console.WriteLine("Input date end range(mm.dd.yyyy):");
            DateTime endDate = DateTime.Parse(Console.ReadLine());
            try
            {
                Console.WriteLine("Input a date(mm.dd.yyyy) between {0} and {1}:", startDate.Date, endDate.Date);
                DateTime value = DateTime.Parse(Console.ReadLine());
                if (value < startDate || value > endDate)
                {
                    throw new InvalidRangeException<DateTime>("ERROR!", startDate, endDate);
                }
                Console.WriteLine("You entered: {0}.\nYou must enter an invalid value to see the error message!", value.Date);
            }
            catch (InvalidRangeException<DateTime> ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
