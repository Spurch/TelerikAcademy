﻿namespace BankSystem
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    class Deposit: Account
    {
        private Deposit() { }
        public Deposit(string id, Customer customer, DateTime fromDate, DateTime dueDate) :
            base(id, customer, fromDate, dueDate) { }
        public Deposit(string id, Customer customer, DateTime fromDate, DateTime dueDate, decimal balance, decimal rate) :
            base(id, customer, fromDate, dueDate, balance, rate, true, true) { }


        public override void DepositMoney(decimal value)
        {
            if (value == 0) { throw new ArgumentOutOfRangeException("Deposit value must be non-zero!"); }
            if (value < 0) { throw new ArgumentOutOfRangeException("Deposit value must be non-negative!"); }
            this.BALANCE += value;
        }

        public override void WithdrawMoney(decimal value)
        {
            if (value == 0) { throw new ArgumentOutOfRangeException("Withdraw value must be non-zero!"); }
            if (value < 0) { throw new ArgumentOutOfRangeException("Withdraw value must be non-negative!"); }
            if (value > this.BALANCE) { throw new ArgumentOutOfRangeException("Current balance not enough!"); }
            this.BALANCE -= value;
        }
        public override decimal CalculateInterest()
        {
            decimal result = default(decimal);
            int period = default(int);
            if (DateTime.Now > this.DUEDATE)
            {
                period = ((this.DUEDATE.Year - this.FROMDATE.Year) * 12) + this.DUEDATE.Month - this.FROMDATE.Month;
            }
            else if (DateTime.Now < this.FROMDATE)
            {
                throw new ArgumentOutOfRangeException("Invalid Date!");
            }
            else
            {
                period = ((this.DUEDATE.Year - DateTime.Now.Year) * 12) + this.DUEDATE.Month - DateTime.Now.Month;
            }
            
            if (this.BALANCE > 1000)
            {
                result = period * this.RATE;
            }
            return result;
        }
    }
}
