﻿/*
Problem 17. Date in Bulgarian
Write a program that reads a date and time given in the format: day.month.year hour:minute:second
and prints the date and time after 6 hours and 30 minutes (in the same format)
along with the day of week in Bulgarian. 
 */
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class BulgarianTime
{
    static void Main()
    {
        string InputText = Console.ReadLine();
        string[] Splitter = InputText.Split(' ');
        int[] Date = Splitter[0].Split('.').Select(n => Convert.ToInt32(n)).ToArray();
        int[] Time = Splitter[1].Split(':').Select(n => Convert.ToInt32(n)).ToArray();
        DateTime CurrentDate;
        try
        {
            CurrentDate = new DateTime(Date[2], Date[1], Date[0], Time[0], Time[1], Time[2]);
        }
        catch (ArgumentOutOfRangeException)
        {
            Console.WriteLine("Invalid date!");
            return;
        }
        CurrentDate = CurrentDate.AddHours(6).AddMinutes(30);
        var BGCulture = new CultureInfo("bg-BG");
        Console.InputEncoding = Encoding.UTF8;
        Console.WriteLine(CurrentDate.ToString(BGCulture));
        Console.WriteLine(BGCulture.DateTimeFormat.GetDayName(CurrentDate.DayOfWeek));
    }
}

