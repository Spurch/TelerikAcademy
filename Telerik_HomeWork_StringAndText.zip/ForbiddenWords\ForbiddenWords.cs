﻿/*
 Problem 9. Forbidden words

    We are given a string containing a list of forbidden words and a text containing some of these words.
    Write a program that replaces the forbidden words with asterisks.

Example text: Microsoft announced its next generation PHP compiler today. It is based on .NET Framework 4.0 and is implemented as a dynamic language in CLR.

Forbidden words: PHP, CLR, Microsoft

The expected result: ********* announced its next generation *** compiler today. It is based on .NET Framework 4.0 and is implemented as a dynamic language in ***. 
 */
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
class ForbiddenWords
{
    static void Main()
    {
        Console.WriteLine("Enter the list of forbidden list: ");
        string ListInput = Console.ReadLine();
        var ForbiddenList = new List<string>();
        ForbiddenList = ListInput.Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries).ToList();
        Console.WriteLine("Enter the text:");
        string InputText = Console.ReadLine();
        Console.WriteLine(InputText);
        foreach (var Word in ForbiddenList)
        {
            InputText = InputText.Replace(Word, new string('*', Word.Length));
        }
        Console.WriteLine("Resulting text: ");
        Console.WriteLine(InputText);
    }
}

