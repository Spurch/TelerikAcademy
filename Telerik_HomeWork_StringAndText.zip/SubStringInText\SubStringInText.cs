﻿/*
 Problem 4. Sub-string in text

    Write a program that finds how many times a sub-string is contained in a given text (perform case insensitive search).

Example:

The target sub-string is in

The text is as follows: We are living in an yellow submarine. We don't have anything else. inside the submarine is very tight. So we are drinking all the day. We will move out of it in 5 days.

The result is: 9 
 */
using System;
class SubStringInText
{
    public static void SubText(string Text, string LookUp, ref int Count)
    {
        if (Text.Length > 0)
        {
            if (Text.Contains(LookUp))
            {
                int StartIndex = Text.IndexOf(LookUp) + LookUp.Length;
                Text = Text.Substring(StartIndex);
                Count++;
                SubText(Text, LookUp, ref Count);
            }
        }
    }
    static void Main()
    {
        Console.WriteLine("Input text: ");
        string InputText = Console.ReadLine();
        Console.WriteLine("Enter value to look for: ");
        string LookUpText = Console.ReadLine();
        int Count = 0;
        SubText(InputText.ToLower(), LookUpText, ref Count);

        Console.WriteLine("The string {0} appears {1} times in the text.", LookUpText, Count);
    }
}

