﻿/*
 Problem 3. Correct brackets

    Write a program to check if in a given expression the brackets are put correctly.

Example of correct expression: ((a+b)/5-d). Example of incorrect expression: )(a+b)). 
 */
using System;
using System.Collections.Generic;
using System.Text;
class CorrectBracket
{
    public static bool Bracket(string str)
    {
        int OpenCount = 0;
        int CloseCount = 0;
        bool flag = false;
        List<char> list = new List<char>();
        char[] Arr = str.ToCharArray();
        for (int i = 0; i < str.Length; i++)
        {
            if (Arr[i] == '(')
            {
                list.Add('(');
                OpenCount++;
            }
            if (Arr[i] == ')')
            {
                CloseCount++;
                if (list.Count != 0)
                {
                    list.RemoveAt(list.LastIndexOf('('));
                }
            }
        }
        if (list.Count == 0 && OpenCount == CloseCount)
        {
            flag = true;
        }
        return flag;
    }
    static void Main()
    {
        string Exprecion = Console.ReadLine();
        Console.WriteLine(Bracket(Exprecion));
    }
}

