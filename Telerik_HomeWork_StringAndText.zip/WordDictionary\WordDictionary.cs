﻿/*
 Problem 14. Word dictionary
    A dictionary is stored as a sequence of text lines containing words and their explanations.
    Write a program that enters a word and translates it by using the dictionary. 
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
class WordDictionary
{
    static void Main()
    {
        Dictionary<string, string> NewDict = new Dictionary<string, string>();
        NewDict.Add(".NET", "platform for applications from Microsoft");
        NewDict.Add("CLR", "managed execution environment for .NET");
        NewDict.Add("namespace", "hierarchical organization of classes");
        bool isChecking = true;
        while (isChecking)
        {
            Console.WriteLine("Enter a word to check in the dictionary: ");
            Console.WriteLine("(if you want to end the cycle enter STOP):");
            string Index = Console.ReadLine();
            if (NewDict.ContainsKey(Index))
            {
                Console.WriteLine(NewDict[Index]);
                Console.WriteLine();
            }
            else if (Index == "STOP")
            {
                isChecking = false;
            }
            else
            {
                Console.WriteLine("The word {0} doesn't appear in the dictionary.", Index);
            }
        }
    }
}

