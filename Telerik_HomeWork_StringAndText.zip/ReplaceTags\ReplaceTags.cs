﻿/*
Problem 15. Replace tags
Write a program that replaces in a HTML document given as string all the tags
<a href="…">…</a> with corresponding tags [URL=…]…/URL].
Example:
input output
<p>Please visit <a href="http://academy.telerik. com">our site</a> to choose a training course.
Also visit <a href="www.devbg.org">our forum</a> to discuss the courses.</p>
<p>Please visit [URL=http://academy.telerik. com]our site[/URL] to choose a training course.
Also visit [URL=www.devbg.org]our forum[/URL] to discuss the courses.</p> 
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

class ReplaceTags
{
    static void Main()
    {
        Console.WriteLine("Enter text:");
        string InputText = Console.ReadLine();
        
        string SchemeA = "<a href=\"";
        string SchemeB = "\">";
        string SchemeC = "</a>";

        string ReplaceA = "[URL=";
        string ReplaceB = "]";
        string ReplaceC = "[/URL]";

        string ResultText = Regex.Replace(InputText, SchemeA, ReplaceA);
        
        ResultText = Regex.Replace(ResultText, SchemeB, ReplaceB);
        ResultText = Regex.Replace(ResultText, SchemeC, ReplaceC);
        
        Console.WriteLine("The resulting text is:");
        Console.WriteLine(ResultText);
    }
}

