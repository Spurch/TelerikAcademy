﻿/*
 Problem 5. Parse tags

    You are given a text. Write a program that changes the text in all regions surrounded by the tags <upcase> and </upcase> to upper-case.
    The tags cannot be nested.

Example: We are living in a <upcase>yellow submarine</upcase>. We don't have <upcase>anything</upcase> else.
The expected result: We are living in a YELLOW SUBMARINE. We don't have ANYTHING else.  
 */
using System;
class ParseTags
{
 public static void Parse(string InputString, ref string ResultString)
       {
           string OpenTag = "<upcase>";
           string CloseTag = "</upcase>";
           if (InputString.Length > 0)
           {
               if (InputString.Contains(OpenTag))
               {
                   int StartIndex = InputString.IndexOf(OpenTag) + OpenTag.Length;
                   int EndIndex = InputString.IndexOf(CloseTag);
                   ResultString += InputString.Substring(0, StartIndex- OpenTag.Length);
                   ResultString += InputString.Substring(StartIndex, EndIndex-StartIndex).ToUpper();
                   Parse(InputString.Substring(EndIndex + CloseTag.Length), ref ResultString);
               }
               else
               {
                   ResultString += InputString;
               }
           }
       }

       static void Main()
       {
           Console.WriteLine("Please enter a string:");
           string string1 = Console.ReadLine();
           string Result = "";
           Parse(string1, ref Result);
           Console.WriteLine(Result);

       }
   }

