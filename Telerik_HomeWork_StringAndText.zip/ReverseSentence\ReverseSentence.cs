﻿/*
 * 
 */
using System;
using System.Collections.Generic;
using System.Linq;
class Program
{
    static void Main()
    {
        Console.WriteLine("Enter text:");
        string InputText = Console.ReadLine();
        char End = InputText[InputText.Length - 1];
        string Str = InputText.Substring(0, InputText.Length - 1);
        List<string> InputList = Str.Split(new char[] { ' ' }).ToList();
        InputList.Reverse();
        foreach (var Word in InputList)
        {
            Console.Write("{0} ", Word);
        }
        Console.Write(End);
        Console.WriteLine();
    }
}

