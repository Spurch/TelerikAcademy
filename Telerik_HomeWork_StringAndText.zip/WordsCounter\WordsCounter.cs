﻿/*
Problem 22. Words count
Write a program that reads a string from the console and lists all different words
in the string along with information how many times each word is found. 
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

class WordsCounter
{
    static void Main()
    {
        Console.WriteLine("Enter text:");
        string InputText = Console.ReadLine();
        string[] Separators = new string[] { ",", ".", "!", "\'", " ", "\'s" };
        string[] Words = InputText.Split(Separators,
        StringSplitOptions.RemoveEmptyEntries);
        var WordsList = new List<string>();
        for (int i = 0; i < Words.Length; i++)
        {
            int Count = 0;
            if (!WordsList.Contains(Words[i]))
            {
                WordsList.Add(Words[i]);
                for (int j = 0; j < Words.Length; j++)
                {
                    if (Words[i] == Words[j])
                    {
                        Count++;
                    }
                }
                Console.WriteLine("{0} - {1}", Words[i], Count);
                Count = 0;
            }
        }
    }
}