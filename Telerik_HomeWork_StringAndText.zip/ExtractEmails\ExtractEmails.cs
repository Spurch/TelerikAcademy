﻿/*
Problem 18. Extract e-mails
Write a program for extracting all email addresses from given text.
All sub-strings that match the format <identifier>@<host>…<domain> should be recognized as emails. 
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

class ExtractEmails
{
    static void Main()
    {
        string InputText = Console.ReadLine();
        Regex NewRegex = new Regex(@"\b[a-z0-9]+\@[a-z0-9]+\.[a-z]{2,3}\b", RegexOptions.None);
        MatchCollection Emails = NewRegex.Matches(InputText);
        foreach (var Match in Emails)
        {
            Console.WriteLine(Match);
        }
    }
}
