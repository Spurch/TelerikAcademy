﻿/*
 Problem 2. Reverse string
    Write a program that reads a string, reverses it and prints the result at the console. 
 */
using System;
using System.Text;
class ReverseString
{
    public static string RvrsString(string DataString)
    {
        char[] Arr = DataString.ToCharArray();
        StringBuilder StrBuild = new StringBuilder();
        for (int i = DataString.Length-1; i >= 0; i--)
        {
            StrBuild.Append(Arr[i]);
        }
        return StrBuild.ToString();
    }
    static void Main()
    {
        Console.WriteLine("Enter a string to reverse: ");
        Console.WriteLine(RvrsString(Console.ReadLine()));
    }
}

