﻿/*
Problem 16. Date difference
Write a program that reads two dates in the format: day.month.year and calculates the number of days between them.
Example:
Enter the first date: 27.02.2006
Enter the second date: 3.03.2006
Distance: 4 days 
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class DateCalculations
{
    static void Main()
    {
        Console.Write("Enter the first date:");
        string FirstDate = Console.ReadLine();
        Console.Write("Enter the second date:");
        string SecondDate = Console.ReadLine();
        string[] FirstDateSplitted = FirstDate.Split('.');
        DateTime FirstDateFormatted = new DateTime(int.Parse(FirstDateSplitted[2]), int.Parse(FirstDateSplitted[1]), int.Parse(FirstDateSplitted[0]));
        string[] SecondDateSplitted = SecondDate.Split('.');
        DateTime SecondDateFormatted = new DateTime(int.Parse(SecondDateSplitted[2]), int.Parse(SecondDateSplitted[1]), int.Parse(SecondDateSplitted[0]));
        TimeSpan TimeDiff = SecondDateFormatted - FirstDateFormatted;
        Console.WriteLine("Distance: {0} days", TimeDiff.Days);
    }
}

