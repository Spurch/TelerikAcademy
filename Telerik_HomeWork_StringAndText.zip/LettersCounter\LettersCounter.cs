﻿/*
 //Problem 21. Letters count
//Write a program that reads a string from the console and prints all different letters
//in the string along with information how many times each letter is found. 
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class LettersCounter
{
    static void Main()
    {
        Console.WriteLine("Enter text:");
        string InputText = Console.ReadLine();
        List<char> UniqueChars = new List<char>();
        List<int> CharCounter = new List<int>();
        for (int i = 0; i < InputText.Length; i++)
        {
            if (!UniqueChars.Contains(InputText[i]) && ((InputText[i] >= 'a' & InputText[i] <= 'z') || (InputText[i] >= 'A' & InputText[i] <= 'Z')))
            {
                UniqueChars.Add(InputText[i]);
                CharCounter.Add(0);
                for (int j = 0; j < InputText.Length; j++)
                {
                    if (UniqueChars[CharCounter.Count - 1] == InputText[j])
                    {
                        CharCounter[CharCounter.Count - 1] = CharCounter[CharCounter.Count - 1] + 1;
                    }
                }
                Console.WriteLine("{0} - {1}", UniqueChars[CharCounter.Count - 1], CharCounter[CharCounter.Count - 1]);
            }
        }
    }
}