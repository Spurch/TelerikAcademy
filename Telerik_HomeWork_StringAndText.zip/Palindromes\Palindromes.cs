﻿/*
Problem 20. Palindromes
Write a program that extracts from a given text all palindromes, e.g. ABBA, lamal, exe. 
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

class Palindromes
{
    static void Main()
    {
        string InputText = Console.ReadLine();
        Regex NewRegex = new Regex(@"[\w]+", RegexOptions.None);
        MatchCollection CurrentMatch = NewRegex.Matches(InputText);
        var WordsList = new List<string>();
        
        foreach (var Match in CurrentMatch)
        {
            WordsList.Add(Match.ToString());
        }

        var Palindromes = new List<string>();

        foreach (var Word in WordsList)
        {
            bool isPal = true;
            int CurrLength = Word.Length;
        
            for (int i = 0; i < CurrLength / 2; i++)
            {
                if (Word[i] != Word[CurrLength - i - 1])
                {
                    isPal = false;
                    break;
                }
                if (isPal && i == CurrLength / 2 - 1)
                {
                    Console.WriteLine(Word);
                }
            }
        }
    }
}

