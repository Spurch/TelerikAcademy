﻿/*
Problem 19. Dates from text in Canada
Write a program that extracts from a given text all dates that match the format DD.MM.YYYY.
Display them in the standard date format for Canada. 
 */
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

class CanadaDateTime
{
    static void Main()
    {
        string InputText = Console.ReadLine();
        Regex NewRegex = new Regex(@"[0-9]{2}\.[0-9]{2}\.[0-9]{4}\b", RegexOptions.None);
        var AllDates = NewRegex.Matches(InputText).OfType<Match>().Select(m => m.Groups[0].Value).ToArray(); ;
        Console.WriteLine("The dates in the text are:");
        DateTime[] DatesArray = AllDates.Select(t => Convert.ToDateTime(t)).ToArray();
        foreach (var CurrentDate in AllDates)
        {
            DateTime CanadianDate;
            if (DateTime.TryParseExact(CurrentDate, "dd.MM.yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out CanadianDate))
            {
                Console.WriteLine(CanadianDate.ToString(CultureInfo.GetCultureInfo("en-CA").DateTimeFormat.ShortDatePattern));
            }
        }
    }
}
