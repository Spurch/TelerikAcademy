﻿/*
 Problem 4. Path

    Create a class Path to hold a sequence of points in the 3D space.
    Create a static class PathStorage with static methods to save and load paths from a text file.
    Use a file format of your choice. 
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Path
{
    [Serializable()]
    public struct Point3D
    {
        private double _x;
        private double _y;
        private double _z;

        public Point3D(double x, double y, double z) : this()
        {
            this.X = x;
            this.Y = y;
            this.Z = z;
        }

        private static readonly Point3D center = new Point3D() { X = 0, Y = 0, Z = 0 };
        public override string ToString()
        {
            return string.Format("[{0},{1},{2}]", X, Y, Z);
        }

        public static Point3D O
        {
            get
            {
                return Point3D.center;
            }
        }
        public double X
        {
            get
            {
                return this._x;
            }
            set
            {
                this._x = value;
            }
        }
        public double Y
        {
            get
            {
                return this._y;
            }
            set
            {
                this._y = value;
            }
        }
        public double Z
        {
            get
            {
                return this._z;
            }
            set
            {
                this._z = value;
            }
        }
    }
}
