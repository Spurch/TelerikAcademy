﻿/*
 Problem 3. Static class

    Write a static class with a static method to calculate the distance between two points in the 3D space.
 
 */
using System;
namespace StaticClass
{
    class StaticClass
    {
        static void Main()
        {

        }
    }
}
