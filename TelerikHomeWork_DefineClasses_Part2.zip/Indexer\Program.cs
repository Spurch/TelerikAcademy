﻿/*
 Problem 9. Matrix indexer
 Implement an indexer this[row, col] to access the inner matrix cells.
 */
using System;
namespace Indexer
{
    class Program
    {
        static void Main()
        {

        }
    }
}
