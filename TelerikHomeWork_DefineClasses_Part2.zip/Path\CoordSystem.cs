﻿/*
 Problem 4. Path

    Create a class Path to hold a sequence of points in the 3D space.
    Create a static class PathStorage with static methods to save and load paths from a text file.
    Use a file format of your choice. 
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Path
{
    public static class CoordSystem
    {
        public static double CalculateDistance(Point3D pointA, Point3D pointB){
            double x = (pointB.X * pointB.X) - (2 * pointB.X * pointA.X) + (pointA.X * pointA.X);
            double y = (pointB.Y * pointB.Y) - (2 * pointB.Y * pointA.Y) + (pointA.Y * pointA.Y);
            double z = (pointB.Z * pointB.Z) - (2 * pointB.Z * pointA.Z) + (pointA.Z * pointA.Z);

            return Math.Sqrt(x + y + z);
        }
    }
}
