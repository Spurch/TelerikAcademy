﻿/*
Problem 7. Min and Max
 Create generic methods Min<T>() and Max<T>() for finding the
 minimal and maximal element in the GenericList<T>.
 You may need to add a generic constraints for the type T.
 */
using System;
namespace MinMax
{
    class MinMax
    {
        static void Main()
        {
            GenericList<int> list = new GenericList<int>(10);
            for (int i = 0; i < 6; i++)
            {
                list.Add(i);
            }
            //list.RemoveAtIndex(2);
            //list.InsertAtIndex(8, 13);
            //list.Add(14);
            //list.Add(99);
            Console.WriteLine("NUMBER OF ELEMENT: {0}",list.COUNT);
            for (int i = 0; i < list.SIZE; i++)
            {
                Console.WriteLine(list.GetAtIndex(i));
            }
            Console.WriteLine("MAX: {0}", GenericList<int>.Max(list));
            Console.WriteLine("MIN: {0}", GenericList<int>.Min(list));
        }
    }
}
