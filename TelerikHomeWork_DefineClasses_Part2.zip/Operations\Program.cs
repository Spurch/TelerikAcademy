﻿/*
 Problem 10. Matrix operations
    Implement the operators + and - (addition and subtraction 
    of matrices of the same size) and * for matrix multiplication.
    Throw an exception when the operation cannot be performed.
    Implement the true operator (check for non-zero elements). 
 */
using System;
namespace Operations
{
    class Program
    {
        static void Main()
        {

        }
    }

}