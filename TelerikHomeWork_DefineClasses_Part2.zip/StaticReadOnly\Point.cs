﻿/*
 Problem 2. Static read-only field

    Add a private static read-only field to hold the start of the coordinate system – the point O{0, 0, 0}.
    Add a static property to return the point O.

 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StaticReadOnly
{
    struct Point3D
    {
        private int _x;
        private int _y;
        private int _z;

        private static readonly Point3D center = new Point3D() { X = 0, Y = 0, Z = 0 };
        public override string ToString()
        {
            return string.Format("[{0},{1},{2}]", X, Y, Z);
        }

        public static Point3D O
        {
            get
            {
                return Point3D.center;
            }
        }
        public int X
        {
            get
            {
                return _x;
            }
            set
            {
                _x = value;
            }
        }
        public int Y
        {
            get
            {
                return _y;
            }
            set
            {
                _y = value;
            }
        }
        public int Z
        {
            get
            {
                return _z;
            }
            set
            {
                _z = value;
            }
        }
    }
}
