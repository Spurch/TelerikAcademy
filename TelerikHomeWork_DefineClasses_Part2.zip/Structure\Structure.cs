﻿/*
 Problem 1. Structure

    Create a structure Point3D to hold a 3D-coordinate {X, Y, Z} in the Euclidian 3D space.
    Implement the ToString() to enable printing a 3D point.
 
 */
using System;
class Program
{
    struct Point3D
    {
        private int _x;
        private int _y;
        private int _z;

        public override string ToString()
        {
            return string.Format("[{0},{1},{2}]", X, Y, Z);
        }
        public int X
        {
            get
            {
                return _x;
            }
            set
            {
                _x = value;
            }
        }
        public int Y
        {
            get
            {
                return _y;
            }
            set
            {
                _y = value;
            }
        }
        public int Z
        {
            get
            {
                return _z;
            }
            set
            {
                _z = value;
            }
        }
    }
    static void Main()
    {

    }
}

