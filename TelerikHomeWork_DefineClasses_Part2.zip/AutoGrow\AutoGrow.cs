﻿/*
Problem 6. Auto-grow
 Implement auto-grow functionality: when the internal array is full, 
 create a new array of double size and move all elements to it.
 */
using System;
namespace AutoGrow
{
    class AutoGrow
    {
        static void Main()
        {

        }
    }

}