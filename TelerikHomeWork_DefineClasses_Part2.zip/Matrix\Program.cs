﻿/*
 Problem 8. Matrix
 Define a class Matrix<T> to hold a matrix of numbers (e.g. integers, floats, decimals). 
 */
using System;
namespace Matrix
{
    class Program
    {
        static void Main()
        {

        }
    }

}