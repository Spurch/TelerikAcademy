﻿/*
 Problem 2. Numbers Not Divisible by 3 and 7
 Write a program that enters from the console a positive integer n and prints all
 the numbers from 1 to n not divisible by 3 and 7, on a single line, separated by a space. 
 */
using System;
class NotDivisbleByThreeAndSeven
{
    static void Main()
    {
        Console.Write("Enter value for N:");
        int Value = Int32.Parse(Console.ReadLine());
        /*
         * Here we are using a for-loop to iterate through
         * all the values in the range and check if they can be divided
         * by 3 or 7.
         */
        for (int i = 1; i <= Value; i++)
        {
            //Note the ! infront of the conditional statement.
            //This basically says NOT(condition in parentesis) -
            //so if the condition is TRUE this will return FALSE
            //and vise-versa.
            if (!(i % 3 == 0 || i % 7 == 0))
            {
                Console.Write("{0} ",i);
            }
        }
        Console.WriteLine();
    }
}

