﻿/*
 Problem 8. Catalan Numbers
 Write a program to calculate the nth Catalan number by given n (1 <= n <= 100). 
 */
using System;
//We are adding a reference to the System.Numerics library
//in order to use the BigInteger class.
using System.Numerics;
class Catalan
{
    static void Main()
    {
        Console.Write("Enter value for N(between 1 and 100): ");
        byte Value = Byte.Parse(Console.ReadLine());
        /*
         * We need the BigInteger class because otherwise
         * we won't be able to store all teh Catalan numbers 
         * in the range from 1 to 100. Because the Catalan 
         * numbers from N=95 and above have more than 50 digits!
         */
        BigInteger a = 1;
        BigInteger b = 1;
        BigInteger result = 1;
        //Just a little check if the value of N is in the range we want.
        if (Value >= 1 && Value <= 100)
        {
            for (int i = 2; i <= Value; i++)
            {
                //We increment both parts of the equation with each loop.
                a *= Value + i;
                b *= i;
            }
            //Finnally we calculate the result.
            result = a / b;
            Console.WriteLine("Catalan number {0} is:", Value);
            Console.WriteLine(result);
        }
        else
        {
            Console.WriteLine("Value for N is out of range!");
        }
    }
}

