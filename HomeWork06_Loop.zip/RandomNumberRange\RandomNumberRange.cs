﻿/*
 Problem 11. Random Numbers in Given Range
 Write a program that enters 3 integers n, min and max 
 (min != max) and prints n random numbers in the range [min...max]. 
 */
using System;
class RandomNumberRange
{
    static void Main()
    {
        Console.Write("How many random numbers do you want? ");
        int n = Int32.Parse(Console.ReadLine());
        Console.Write("Minimal value? ");
        int min = Int32.Parse(Console.ReadLine());
        Console.Write("Maximum value? ");
        int max = Int32.Parse(Console.ReadLine());
        int CurrentRand = 0;
        Random rand = new Random();
        for (int i = 0; i < n; i++)
        {
            CurrentRand = rand.Next(min, max + 1);
            Console.Write("{0}, ", CurrentRand);
        }
        Console.WriteLine();
    }
}

