﻿/*
 Problem 7. Calculate N! / (K! * (N-K)!)
 In combinatorics, the number of ways to choose k different members out of a 
 group of n different elements (also known as the number of combinations) is 
 calculated by the following formula: formula For example, there are 2598960 ways 
 to withdraw 5 cards out of a standard deck of 52 cards.
 Your task is to write a program that calculates n! / (k! * (n-k)!) for 
 given n and k (1 < k < n < 100). Try to use only two loops. 
 */
using System;
class CalculateNumbersNK2
{
    static void Main()
    {
        Console.Write("Value for N: ");
        int NValue = Int32.Parse(Console.ReadLine());
        Console.Write("Value for K: ");
        int KValue = Int32.Parse(Console.ReadLine());

        if (NValue < 100 && KValue > 1 && NValue > KValue)
        {
            //Variable that will accumulate N!
            double NFact = 1;
            //Variable that will accumulate K!
            double KFact = 1;
            //The (N-K)! factorial variable.
            double Temp = 1;
            //Final result variable.
            double Result = 0;

            //We are going to increment until N, because N
            //is bigger than K by deffinition.
            for (int i = 1; i <= NValue; i++)
            {
                NFact *= i;
                //This check here safeguards that we increment K 
                //only till its necessary.
                if (i <= KValue)
                {
                    KFact *= i;
                }
            }
            //Here we accumulate the Factorial of the difference between N and K.
            //That is why we are incrementing 'i' till (NValue - KValue).
            for (int i = 1; i <= NValue - KValue; i++)
            {
                Temp *= i;
            }

            //We calculate the final result with the accumulated factorials.
            Result = NFact / (KFact * Temp);
            Console.WriteLine("{0}", Result);
        }
        else
        {
            Console.WriteLine("Inccorect values!!!");
        }
    }
}

