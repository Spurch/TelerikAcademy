﻿/*
 Problem 9. Matrix of Numbers
 Write a program that reads from the console a positive integer number n (1 = n = 20) 
 and prints a matrix like in the examples below. Use two nested loops. 
 */
using System;
class Matrix
{
    static void Main()
    {
        Console.WriteLine("Enter value for N(between 1 and 20):");
        byte Value = byte.Parse(Console.ReadLine());
        if (Value >= 1 && Value <= 20)
        {
            //Note that 'i' will iterate from 1 to N - not from 0 to N-1!
            //'i' will iterate over the columns of the matrix.
            for (int i = 1; i <= Value; i++)
            {
                /*
                 * On the other hand 'j' will iterate from 0 to N-1!
                 * By doing so we ensure that i+j <= (N*2)-1
                 * And N*2-1 is exactly the maximum value will want
                 * to print in the matrix at position [N][N].
                 */
                //'j' will iterate over the rows of the matrix and
                //increment each value in the row by 1(using 'i' current value as
                //a starting point).
                for (int j = 0; j < Value; j++)
                {
                    Console.Write("{0} ", j + i);
                }
                Console.WriteLine();
            }
        }
        else
        {
            Console.WriteLine("Value for N is not in the correct range!");
        }
    }
}

