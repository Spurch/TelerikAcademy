﻿/*
 Problem 2. Constructors

    Define several constructors for the defined classes that take different 
    sets of arguments (the full information for the class or part of it).
    Assume that model and manufacturer are mandatory (the others are optional). 
    All unknown data fill with null.

 */
using System;
namespace Constructors
{
    class Constructors
    {
        static void Main()
        {

        }
    }
}
