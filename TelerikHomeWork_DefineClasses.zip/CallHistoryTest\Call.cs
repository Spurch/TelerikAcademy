﻿/*
Problem 12. Call history test

    Write a class GSMCallHistoryTest to test the call history functionality of the GSM class.
        Create an instance of the GSM class.
        Add few calls.
        Display the information about the calls.
        Assuming that the price per minute is 0.37 calculate and print the total price of the calls in the history.
        Remove the longest call from the history and calculate the total price again.
        Finally clear the call history and print it.
 */
using System;
using System.Globalization;
namespace CallHistoryTest
{
    class Call: IComparable<Call>
    {
        private string dialedNumber = null;
        private DateTime callDate;
        private TimeSpan callTime;
        private uint? callDuration = null;

        public Call() { }

        //Predefined constructor for the call objects.
        public Call(string number, DateTime date, TimeSpan time, uint? duration)
        {
            this.NUMBER = number;
            this.DATE = date;
            this.TIME = time;
            this.SPAN = duration;
        }

        //We implement IComparable and override the CompareTo() method 
        //to be able to sort a collection of calls.
        public int CompareTo(Call otherCall)
        {
            if (this.SPAN > otherCall.SPAN)
            {
                return 1;
            }
            else if (this.SPAN == otherCall.SPAN)
            {
                return 0;
            }
            else
            {
                return -1;
            }
        }

        //Override ToString() method.
        //Note that if the call duration is zero we output the call just like a Click.
        public override string ToString()
        {
            if (this.SPAN == 0)
            {
                return string.Format("Clicked: {0} in {1} at {2}.",
                    this.NUMBER, this.DATE.ToShortDateString(), this.TIME.ToString(@"hh\:mm\:ss"));
            }
            else
            {
                return string.Format("Called: {0} in {1} at {2}. Duration: {3} seconds.",
                    this.NUMBER, this.DATE.ToShortDateString(), this.TIME.ToString(@"hh\:mm\:ss"), this.SPAN);
            }
        }
        /*---------------------CLASS PUBLIC PROPERTIES - START---------------------*/
        public string NUMBER
        {
            get
            {
                return this.dialedNumber;
            }
            set
            {
                this.dialedNumber = value;
            }
        }
        public DateTime DATE
        {
            get
            {
                return this.callDate;
            }
            set
            {
                this.callDate = value;
            }
        }
        public TimeSpan TIME
        {
            get
            {
                return this.callTime;
            }
            set
            {
                this.callTime = value;
            }
        }
        public uint? SPAN
        {
            get
            {
                return this.callDuration;
            }
            set
            {
                this.callDuration = value;
            }
        }
        /*---------------------CLASS PUBLIC PROPERTIES - END---------------------*/
    }
}
