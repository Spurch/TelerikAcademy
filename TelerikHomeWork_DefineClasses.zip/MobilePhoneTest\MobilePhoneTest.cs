﻿/*
 Problem 7. GSM test

    Write a class GSMTest to test the GSM class:
        Create an array of few instances of the GSM class.
        Display the information about the GSMs in the array.
        Display the information about the static property IPhone4S. 
 */
using System;
using System.Collections.Generic;
namespace MobilePhoneTest
{
    class MobilePhoneTest
    {
        static void Main()
        {
            var mobileList = new List<MobilePhone>();

            Battery nokiaBattery = new Battery("BJ51", BatteryType.LiIon, 40, 12);
            Battery sonyBattery = new Battery("BA900", BatteryType.LiIon, 30, 15);
            Battery samsungBattery = new Battery("EB-L1G6LLA", BatteryType.LiIon, 30, 15);

            Display smallDisplay = new Display(5, 16000000);
            Display mediumDisplay = new Display(7, 16000000);
            Display bigDisplay = new Display(11, 16000000);

            MobilePhone nokiaLumia = new MobilePhone("Lumia630", "Nokia", "Microsoft", 300.00M, nokiaBattery, smallDisplay);
            mobileList.Add(nokiaLumia);
            MobilePhone sonyExperia = new MobilePhone("XperiaM", "Sony", "Sony", 350.00M, sonyBattery, mediumDisplay);
            mobileList.Add(sonyExperia);
            MobilePhone samsungNote = new MobilePhone("GalaxyNote", "Samsung", "Samsung", 600.00M, samsungBattery, bigDisplay);
            mobileList.Add(samsungNote);

            foreach (var phone in mobileList)
            {
                Console.WriteLine(phone.ToString());
            }
            Console.WriteLine(MobilePhone.GetIPhone());
        }
    }
}

