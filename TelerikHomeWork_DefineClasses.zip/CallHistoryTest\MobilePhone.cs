﻿/*
Problem 12. Call history test

    Write a class GSMCallHistoryTest to test the call history functionality of the GSM class.
        Create an instance of the GSM class.
        Add few calls.
        Display the information about the calls.
        Assuming that the price per minute is 0.37 calculate and print the total price of the calls in the history.
        Remove the longest call from the history and calculate the total price again.
        Finally clear the call history and print it.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CallHistoryTest
{
    class MobilePhone
    {
        private static MobilePhone Iphone;

        private List<Call> callHistory = new List<Call>();
        private string phoneModel = null;
        private string phoneManufacturer = null;
        private string phoneOwner = null;
        private decimal ?phonePrice = null;
        private Battery battery = null;
        private Display display = null;

        //Override ToString() method that uses a StringBuilder.
        public override string ToString()
        {
            StringBuilder OutString = new StringBuilder();
            OutString.AppendLine("---------------------------");
            OutString.AppendLine("|       Mobile phone      |");
            OutString.AppendLine("---------------------------");
            OutString.Append("Model: ");
            OutString.Append(this.MODEL + "\n");
            OutString.Append("Manufacturer: ");
            OutString.Append(this.MANUFACTURER + "\n");
            OutString.Append("Price: ");
            OutString.Append(this.PRICE + "\n");
            OutString.Append("Owner: ");
            OutString.Append(this.OWNER + "\n");
            OutString.AppendLine("---------------------------");
            OutString.AppendLine(this.BATTERY.ToString());
            OutString.AppendLine("---------------------------");
            OutString.AppendLine(this.DISPLAY.ToString());
            return OutString.ToString();

        }
        /*---------------------STATIC CONSTRUCTOR FOR THE STATIC VARIABLE - START---------------------*/
        static MobilePhone()
        {
            Iphone = new MobilePhone("iPhone 4S", "Apple", "Will Smith", 700.00M, 
                new Battery("Apple", BatteryType.LiIon, 12, 36), new Display(7, 16000000));
        }
        /*---------------------STATIC CONSTRUCTOR FOR THE STATIC VARIABLE - END---------------------*/

        /*---------------------PREDEFINED CONSTRUCTORS OF THE CLASS - START---------------------*/
        public MobilePhone(){
            battery = new Battery();
            display = new Display();
        }
        public MobilePhone(string model, string manufacturer, Battery battery, Display display)
        {
            this.BATTERY = battery;
            this.DISPLAY = display;
            this.MODEL = model;
            this.MANUFACTURER = manufacturer;
        }
        public MobilePhone(string model, string manufacturer, string owner, Battery battery, Display display)
        {
            this.BATTERY = battery;
            this.DISPLAY = display;
            this.MODEL = model;
            this.MANUFACTURER = manufacturer;
            this.OWNER = owner;
        }
        public MobilePhone(string model, string manufacturer, decimal? price, Battery battery, Display display)
        {
            this.BATTERY = battery;
            this.DISPLAY = display;
            this.MODEL = model;
            this.MANUFACTURER = manufacturer;
            this.PRICE = price;
        }
        public MobilePhone(string model, string manufacturer, string owner, decimal? price, Battery battery, Display display)
        {
            this.BATTERY = battery;
            this.DISPLAY = display;
            this.MODEL = model;
            this.MANUFACTURER = manufacturer;
            this.OWNER = owner;
            this.PRICE = price;
        }
        /*---------------------PREDEFINED CONSTRUCTORS OF THE CLASS - END---------------------*/

        /*---------------------CLASS PUBLIC METHODS - START---------------------*/

        //Method that outputs info for the static variable.
        public static string GetIPhone()
        {
            return Iphone.ToString();
        }

        //Method that calculates the total cost for the calls based on price per minute.
        public decimal CalculateCalls(decimal pricePerMinute)
        {
            //Getting the price per second.
            decimal pricePerSecond = pricePerMinute / 60;
            decimal totalPrice = 0.0M;
            uint? totalSpan = 0;
            //Getting the call history and calculating each call duration.
            List<Call> tempList = this.HISTORY;
            foreach (var call in tempList)
            {
                if (call.SPAN == null)
                {
                    totalSpan += 0;
                }
                else
                {
                    totalSpan += call.SPAN;
                }
            }

            return totalPrice = (decimal)totalSpan * pricePerSecond;
        }

        //Method that adds a call to the call history.
        public void AddCall(Call call)
        {
            this.callHistory.Add(call);
        }
        //Method that deletes a call from the history.
        public void DeleteCall(Call call)
        {
            this.callHistory.Remove(call);
        }

        //Method that clears the call history.
        public void ClearCall()
        {
            this.callHistory.Clear();
        }
        /*---------------------CLASS PUBLIC METHODS - END---------------------*/

        /*---------------------CLASS PUBLIC PROPERTIES - START---------------------*/
        public List<Call> HISTORY
        {
            get { return this.callHistory; }
        }
        public Battery BATTERY
        {
            get
            {
                return this.battery;
            }
            set
            {
                this.battery = value;
            }
        }
        public Display DISPLAY
        {
            get
            {
                return this.display;
            }
            set
            {
                this.display = value;
            }
        }
        public string MODEL
        {
            get
            {
                return this.phoneModel;
            }
            set
            {
                this.phoneModel = value;
            }
        }
        public string MANUFACTURER
        {
            get
            {
                return this.phoneManufacturer;
            }
            set
            {
                this.phoneManufacturer = value;
            }
        }
        public string OWNER
        {
            get
            {
                return this.phoneOwner;
            }
            set
            {
                this.phoneOwner = value;
            }
        }
        public decimal? PRICE
        {
            get
            {
                return this.phonePrice;
            }
            set
            {
                this.phonePrice = value;
            }
        }
        /*---------------------CLASS PUBLIC PROPERTIES - END---------------------*/
    }
}
