﻿/*
 Problem 4. ToString
    Add a method in the GSM class for displaying all information about it.
    Try to override ToString(). 
 */
using System;
namespace ToString
{
    class ToString
    {
        static void Main()
        {

        }
    }

}