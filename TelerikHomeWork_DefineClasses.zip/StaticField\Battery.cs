﻿/*
 Problem 6. Static field
    Add a static field and a property 
    IPhone4S in the GSM class to hold the information about iPhone 4S.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StaticField
{
    public enum BatteryType { LiIon, NiMH, NiCd};
    class Battery
    {
        private string batteryModel = null;
        private BatteryType ?batteryType = null;
        private double ?batteryHoursTalk = null;
        private double ?batteryHoursIdle = null;

        public override string ToString()
        {
            return string.Format("|         Battery         |\n---------------------------\nModel: {0}\nType: {1}\nHours talk: {2}\nHours idle: {3}", 
                this.MODEL, this.TYPE, this.HOURSTALK, this.HOURSIDLE);
        }
        public Battery() { }
        public Battery(string model, BatteryType? type)
        {
            this.MODEL = model;
            this.TYPE = type;
        }
        public Battery(double? talk)
        {
            this.HOURSTALK = talk;
        }
        public Battery(double? talk, double? idle)
        {
            this.HOURSTALK = talk;
            this.HOURSIDLE = idle;
        }
        public Battery(double? talk, double? idle, BatteryType? type)
        {
            this.TYPE = type;
            this.HOURSTALK = talk;
            this.HOURSIDLE = idle;
        }
        public Battery(string model, double? idle)
        {
            this.MODEL = model;
            this.HOURSIDLE = idle;
        }
        public Battery(string model , BatteryType? type, double? talk, double? idle)
        {
            this.MODEL = model;
            this.TYPE = type;
            this.HOURSTALK = talk;
            this.HOURSIDLE = idle;
        }

        public string MODEL
        {
            get
            {
                return this.batteryModel;
            }
            set
            {
                this.batteryModel = value;
            }
        }
        public double ?HOURSTALK
        {
            get
            {
                return this.batteryHoursTalk;
            }
            set
            {
                this.batteryHoursTalk = value;
            }
        }
        public double? HOURSIDLE
        {
            get
            {
                return this.batteryHoursIdle;
            }
            set
            {
                this.batteryHoursIdle = value;
            }
        }
        public BatteryType ?TYPE
        {
            get
            {
                return this.batteryType;
            }
            set
            {
                batteryType = value;
            }
        }
    }
}
