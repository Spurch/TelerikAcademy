﻿/*
Problem 12. Call history test

    Write a class GSMCallHistoryTest to test the call history functionality of the GSM class.
        Create an instance of the GSM class.
        Add few calls.
        Display the information about the calls.
        Assuming that the price per minute is 0.37 calculate and print the total price of the calls in the history.
        Remove the longest call from the history and calculate the total price again.
        Finally clear the call history and print it.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CallHistoryTest
{
    class Display
    {
        private double? displaySize = null;
        private int? displayNumberOfColors = null;

        //Override ToString() method.
        public override string ToString()
        {
            return string.Format("|         Display         |\n---------------------------\nSize: {0} inches.\nNumber of colors: {1} colors.\n",
                this.SIZE, this.COLOR);
        }
        /*---------------------PREDEFINED CONSTRUCTORS OF THE CLASS - START---------------------*/
        public Display() { }
        public Display(double? size)
        {
            this.SIZE = size;
        }
        public Display(int? colors)
        {
            this.COLOR = colors;
        }
        public Display(double? size, int? colors)
        {
            this.SIZE = size;
            this.COLOR = colors;
        }
        /*---------------------PREDEFINED CONSTRUCTORS OF THE CLASS - END---------------------*/

        /*---------------------CLASS PUBLIC PROPERTIES - START---------------------*/
        public double? SIZE
        {
            get
            {
                return this.displaySize;
            }
            set
            {
                this.displaySize = value;
            }
        }
        public int? COLOR
        {
            get
            {
                return this.displayNumberOfColors;
            }
            set
            {
                this.displayNumberOfColors = value;
            }
        }
        /*---------------------CLASS PUBLIC PROPERTIES - END---------------------*/
    }
}
