﻿/*
Problem 12. Call history test

    Write a class GSMCallHistoryTest to test the call history functionality of the GSM class.
        Create an instance of the GSM class.
        Add few calls.
        Display the information about the calls.
        Assuming that the price per minute is 0.37 calculate and print the total price of the calls in the history.
        Remove the longest call from the history and calculate the total price again.
        Finally clear the call history and print it.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CallHistoryTest
{
    //Enum variable for the BatteryType.
    public enum BatteryType { LiIon, NiMH, NiCd};
    class Battery
    {
        private string batteryModel = null;
        private BatteryType ?batteryType = null;
        private double ?batteryHoursTalk = null;
        private double ?batteryHoursIdle = null;

        //Override ToString() method.
        public override string ToString()
        {
            return string.Format("|         Battery         |\n---------------------------\nModel: {0}\nType: {1}\nHours talk: {2}hrs.\nHours idle: {3}hrs.", 
                this.MODEL, this.TYPE, this.HOURSTALK, this.HOURSIDLE);
        }

        /*---------------------PREDEFINED CONSTRUCTORS OF THE CLASS - START---------------------*/
        public Battery() { }
        public Battery(string model, BatteryType? type)
        {
            this.MODEL = model;
            this.TYPE = type;
        }
        public Battery(double? talk)
        {
            this.HOURSTALK = talk;
        }
        public Battery(double? talk, double? idle)
        {
            this.HOURSTALK = talk;
            this.HOURSIDLE = idle;
        }
        public Battery(double? talk, double? idle, BatteryType? type)
        {
            this.TYPE = type;
            this.HOURSTALK = talk;
            this.HOURSIDLE = idle;
        }
        public Battery(string model, double? idle)
        {
            this.MODEL = model;
            this.HOURSIDLE = idle;
        }
        public Battery(string model , BatteryType? type, double? talk, double? idle)
        {
            this.MODEL = model;
            this.TYPE = type;
            this.HOURSTALK = talk;
            this.HOURSIDLE = idle;
        }
        /*---------------------PREDEFINED CONSTRUCTORS OF THE CLASS - END---------------------*/

        /*---------------------CLASS PUBLIC PROPERTIES - START---------------------*/
        public string MODEL
        {
            get
            {
                return this.batteryModel;
            }
            set
            {
                this.batteryModel = value;
            }
        }
        public double ?HOURSTALK
        {
            get
            {
                return this.batteryHoursTalk;
            }
            set
            {
                this.batteryHoursTalk = value;
            }
        }
        public double? HOURSIDLE
        {
            get
            {
                return this.batteryHoursIdle;
            }
            set
            {
                this.batteryHoursIdle = value;
            }
        }
        public BatteryType ?TYPE
        {
            get
            {
                return this.batteryType;
            }
            set
            {
                batteryType = value;
            }
        }
        /*---------------------CLASS PUBLIC PROPERTIES - END---------------------*/
    }
}
