﻿/*
 Problem 2. Constructors

    Define several constructors for the defined classes that take different 
    sets of arguments (the full information for the class or part of it).
    Assume that model and manufacturer are mandatory (the others are optional). 
    All unknown data fill with null.

 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Constructors
{
    class Display
    {
        double ?displaySize = null;
        int ?displayNumberOfColors = null;

        public Display(){}
        public Display(double ?size)
        {
            this.displaySize = size;
        }
        public Display(int ?colors)
        {
            this.displayNumberOfColors = colors;
        }
        public Display(double ?size, int ?colors)
        {
            this.displaySize = size;
            this.displayNumberOfColors = colors;
        }
    }
}
