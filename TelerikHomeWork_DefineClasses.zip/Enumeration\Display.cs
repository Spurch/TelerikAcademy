﻿/*
Problem 3. Enumeration
    Add an enumeration BatteryType (Li-Ion, NiMH, NiCd, …) and use it as a new 
    field for the batteries.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Enumeration
{
    class Display
    {
        double ?displaySize = null;
        int ?displayNumberOfColors = null;

        public Display(){}
        public Display(double? size)
        {
            this.displaySize = size;
        }
        public Display(int colors)
        {
            this.displayNumberOfColors = colors;
        }
        public Display(double? size, int colors)
        {
            this.displaySize = size;
            this.displayNumberOfColors = colors;
        }
    }
}
