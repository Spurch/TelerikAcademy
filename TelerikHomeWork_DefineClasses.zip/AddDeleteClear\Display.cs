﻿/*
Problem 10. Add/Delete calls

    Add methods in the GSM class for adding and deleting calls from the calls history.
    Add a method to clear the call history.

 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AddDeleteClear
{
    class Display
    {
        private double? displaySize = null;
        private int? displayNumberOfColors = null;
        public override string ToString()
        {
            return string.Format("|         Display         |\n---------------------------\nSize: {0} inches.\nNumber of colors: {1} colors.\n",
                this.SIZE, this.COLOR);
        }
        public Display() { }
        public Display(double? size)
        {
            this.SIZE = size;
        }
        public Display(int? colors)
        {
            this.COLOR = colors;
        }
        public Display(double? size, int? colors)
        {
            this.SIZE = size;
            this.COLOR = colors;
        }
        public double? SIZE
        {
            get
            {
                return this.displaySize;
            }
            set
            {
                this.displaySize = value;
            }
        }
        public int? COLOR
        {
            get
            {
                return this.displayNumberOfColors;
            }
            set
            {
                this.displayNumberOfColors = value;
            }
        }
    }
}
