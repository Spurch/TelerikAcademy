﻿/*
 Problem 5. Properties
    Use properties to encapsulate the data fields inside the GSM, Battery and Display classes.
    Ensure all fields hold correct data at any given time.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Properties
{
    class Display
    {
        private double? displaySize = null;
        private int? displayNumberOfColors = null;
        public override string ToString()
        {
            return string.Format("Display, size:{0}, number of colors:{1}.", 
                this.SIZE, this.COLOR);
        }
        public Display(){}
        public Display(double? size)
        {
            this.SIZE = size;
        }
        public Display(int colors)
        {
            this.COLOR = colors;
        }
        public Display(double? size, int colors)
        {
            this.SIZE = size;
            this.COLOR = colors;
        }
        public double? SIZE
        {
            get
            {
                return this.displaySize;
            }
            set
            {
                this.displaySize = value;
            }
        }
        public int ?COLOR
        {
            get
            {
                return this.displayNumberOfColors;
            }
            set
            {
                this.displayNumberOfColors = value;
            }
        }
    }
}
