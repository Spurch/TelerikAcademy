﻿/*
 Problem 2. Constructors

    Define several constructors for the defined classes that take different 
    sets of arguments (the full information for the class or part of it).
    Assume that model and manufacturer are mandatory (the others are optional). 
    All unknown data fill with null.

 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Constructors
{
    class Battery
    {
        string batteryModel = null;
        double ?batteryHoursTalk = null;
        double ?batteryHoursIdle = null;

        public Battery() { }
        public Battery(string model)
        {
            this.batteryModel = model;
        }
        public Battery(double ?talk)
        {
            this.batteryHoursTalk = talk;
        }
        public Battery(double ?talk, double ?idle)
        {
            this.batteryHoursTalk = talk;
            this.batteryHoursIdle = idle;
        }
        public Battery(string model, double ?idle)
        {
            this.batteryModel = model;
            this.batteryHoursIdle = idle;
        }
        public Battery(string model , double ?talk, double ?idle)
        {
            this.batteryModel = model;
            this.batteryHoursTalk = talk;
            this.batteryHoursIdle = idle;
        }
    }
}
