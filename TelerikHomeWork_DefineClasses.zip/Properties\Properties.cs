﻿/*
 Problem 5. Properties
    Use properties to encapsulate the data fields inside the GSM, Battery and Display classes.
    Ensure all fields hold correct data at any given time.
 */
using System;
namespace Properties
{
    class Properties
    {
        static void Main()
        {

        }
    }

}