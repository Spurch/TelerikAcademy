﻿/*
Problem 9. Call history

    Add a property CallHistory in the GSM class to hold a list of the performed calls.
    Try to use the system class List<Call>.

 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CallHistory
{
    class MobilePhone
    {
        private static MobilePhone Iphone;

        private List<Call> callHistory;
        private string phoneModel = null;
        private string phoneManufacturer = null;
        private string phoneOwner = null;
        private decimal ?phonePrice = null;
        private Battery battery = null;
        private Display display = null;
        public override string ToString()
        {
            StringBuilder OutString = new StringBuilder();
            OutString.AppendLine("---------------------------");
            OutString.AppendLine("|       Mobile phone      |");
            OutString.AppendLine("---------------------------");
            OutString.Append("Model: ");
            OutString.Append(this.MODEL + "\n");
            OutString.Append("Manufacturer: ");
            OutString.Append(this.MANUFACTURER + "\n");
            OutString.Append("Price: ");
            OutString.Append(this.PRICE + "\n");
            OutString.Append("Owner: ");
            OutString.Append(this.OWNER + "\n");
            OutString.AppendLine("---------------------------");
            OutString.AppendLine(this.BATTERY.ToString());
            OutString.AppendLine("---------------------------");
            OutString.AppendLine(this.DISPLAY.ToString());
            return OutString.ToString();

        }

        static MobilePhone()
        {
            Iphone = new MobilePhone("iPhone 4S", "Apple", "Will Smith", 700.00M, 
                new Battery("Apple", BatteryType.LiIon, 12, 36), new Display(7, 16000000));
        }

        public MobilePhone(){
            battery = new Battery();
            display = new Display();
        }
        public MobilePhone(string model, string manufacturer, Battery battery, Display display)
        {
            this.BATTERY = battery;
            this.DISPLAY = display;
            this.MODEL = model;
            this.MANUFACTURER = manufacturer;
        }
        public MobilePhone(string model, string manufacturer, string owner, Battery battery, Display display)
        {
            this.BATTERY = battery;
            this.DISPLAY = display;
            this.MODEL = model;
            this.MANUFACTURER = manufacturer;
            this.OWNER = owner;
        }
        public MobilePhone(string model, string manufacturer, decimal? price, Battery battery, Display display)
        {
            this.BATTERY = battery;
            this.DISPLAY = display;
            this.MODEL = model;
            this.MANUFACTURER = manufacturer;
            this.PRICE = price;
        }
        public MobilePhone(string model, string manufacturer, string owner, decimal? price, Battery battery, Display display)
        {
            this.BATTERY = battery;
            this.DISPLAY = display;
            this.MODEL = model;
            this.MANUFACTURER = manufacturer;
            this.OWNER = owner;
            this.PRICE = price;
        }

        public static string GetIPhone()
        {
            return Iphone.ToString();
        }

        public List<Call> HISTORY
        {
            get { return this.callHistory; }
        }
        public Battery BATTERY
        {
            get
            {
                return this.battery;
            }
            set
            {
                this.battery = value;
            }
        }
        public Display DISPLAY
        {
            get
            {
                return this.display;
            }
            set
            {
                this.display = value;
            }
        }
        public string MODEL
        {
            get
            {
                return this.phoneModel;
            }
            set
            {
                this.phoneModel = value;
            }
        }
        public string MANUFACTURER
        {
            get
            {
                return this.phoneManufacturer;
            }
            set
            {
                this.phoneManufacturer = value;
            }
        }
        public string OWNER
        {
            get
            {
                return this.phoneOwner;
            }
            set
            {
                this.phoneOwner = value;
            }
        }
        public decimal? PRICE
        {
            get
            {
                return this.phonePrice;
            }
            set
            {
                this.phonePrice = value;
            }
        }
    }
}
