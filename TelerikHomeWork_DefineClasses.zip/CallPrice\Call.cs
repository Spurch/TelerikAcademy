﻿/*
Problem 11. Call price

    Add a method that calculates the total price of the calls in the call history.
    Assume the price per minute is fixed and is provided as a parameter.

 */
using System;
namespace CallPrice
{
    class Call
    {
        private string dialedNumber = null;
        private DateTime? callDate = null;
        private TimeSpan? callTime = null;
        private uint? callDuration = null;

        public Call() { }

        public Call(string number, DateTime date, TimeSpan time, uint? duration)
        {
            this.NUMBER = number;
            this.DATE = date.Date;
            this.TIME = time;
            this.SPAN = duration;
        }

        public override string ToString()
        {
            if (this.SPAN == null)
            {
                return string.Format("Clicked: {0} in {1} at {2}.",
                    this.NUMBER, this.DATE, this.TIME);
            }
            else
            {
                return string.Format("Called: {0} in {1} at {2}. Duration: {3} seconds.",
                    this.NUMBER, this.DATE, this.TIME, this.SPAN);
            }
        }
        public string NUMBER
        {
            get
            {
                return this.dialedNumber;
            }
            set
            {
                this.dialedNumber = value;
            }
        }
        public DateTime? DATE
        {
            get
            {
                return this.callDate;
            }
            set
            {
                this.callDate = value;
            }
        }
        public TimeSpan? TIME
        {
            get
            {
                return this.callTime;
            }
            set
            {
                this.callTime = value;
            }
        }
        public uint? SPAN
        {
            get
            {
                return this.callDuration;
            }
            set
            {
                this.callDuration = value;
            }
        }
    }
}
