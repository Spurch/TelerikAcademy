﻿/*
 Problem 2. Constructors

    Define several constructors for the defined classes that take different 
    sets of arguments (the full information for the class or part of it).
    Assume that model and manufacturer are mandatory (the others are optional). 
    All unknown data fill with null.

 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Constructors
{
    class MobilePhone
    {
        public string phoneModel = null;
        string phoneManufacturer = null;
        string phoneOwner = null;
        decimal ?phonePrice = null;
        Battery battery = null;
        Display display = null;

        public MobilePhone(){
            battery = new Battery();
            display = new Display();
        }
        public MobilePhone(string model, string manufacturer)
        {
            battery = new Battery();
            display = new Display();
            this.phoneModel = model;
            this.phoneManufacturer = manufacturer;
        }
        public MobilePhone(string model, string manufacturer, string owner)
        {
            this.phoneModel = model;
            this.phoneManufacturer = manufacturer;
            this.phoneOwner = owner;
        }
        public MobilePhone(string model, string manufacturer, decimal ?price)
        {
            this.phoneModel = model;
            this.phoneManufacturer = manufacturer;
            this.phonePrice = price;
        }
        public MobilePhone(string model, string manufacturer, string owner, decimal ?price)
        {
            this.phoneModel = model;
            this.phoneManufacturer = manufacturer;
            this.phoneOwner = owner;
            this.phonePrice = price;
        }
    }
}
