﻿/*
Problem 3. Enumeration
    Add an enumeration BatteryType (Li-Ion, NiMH, NiCd, …) and use it as a new 
    field for the batteries.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Enumeration
{
    public enum BatteryType { LiIon, NiMH, NiCd};
    class Battery
    {
        string batteryModel = null;
        BatteryType ?batteryType = null;
        double ?batteryHoursTalk = null;
        double ?batteryHoursIdle = null;

        public Battery() { }
        public Battery(string model, BatteryType? type)
        {
            this.batteryModel = model;
            this.batteryType = type;
        }
        public Battery(double? talk)
        {
            this.batteryHoursTalk = talk;
        }
        public Battery(double? talk, double? idle)
        {
            this.batteryHoursTalk = talk;
            this.batteryHoursIdle = idle;
        }
        public Battery(double? talk, double? idle, BatteryType? type)
        {
            this.batteryType = type;
            this.batteryHoursTalk = talk;
            this.batteryHoursIdle = idle;
        }
        public Battery(string model, double? idle)
        {
            this.batteryModel = model;
            this.batteryHoursIdle = idle;
        }
        public Battery(string model , BatteryType? type, double? talk, double? idle)
        {
            this.batteryModel = model;
            this.batteryType = type;
            this.batteryHoursTalk = talk;
            this.batteryHoursIdle = idle;
        }
    }
}
