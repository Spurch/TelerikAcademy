﻿/*
 Problem 6. Static field
    Add a static field and a property 
    IPhone4S in the GSM class to hold the information about iPhone 4S.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StaticField
{
    class Display
    {
        private double? displaySize = null;
        private int? displayNumberOfColors = null;
        public override string ToString()
        {
            return string.Format("|         Display         |\n---------------------------\nSize: {0}\nNumber of colors: {1}\n",
                this.SIZE, this.COLOR);
        }
        public Display() { }
        public Display(double? size)
        {
            this.SIZE = size;
        }
        public Display(int? colors)
        {
            this.COLOR = colors;
        }
        public Display(double? size, int? colors)
        {
            this.SIZE = size;
            this.COLOR = colors;
        }
        public double? SIZE
        {
            get
            {
                return this.displaySize;
            }
            set
            {
                this.displaySize = value;
            }
        }
        public int? COLOR
        {
            get
            {
                return this.displayNumberOfColors;
            }
            set
            {
                this.displayNumberOfColors = value;
            }
        }
    }
}
