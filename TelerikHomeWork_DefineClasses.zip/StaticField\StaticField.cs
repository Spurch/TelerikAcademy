﻿/*
 Problem 6. Static field
    Add a static field and a property 
    IPhone4S in the GSM class to hold the information about iPhone 4S.
 */
using System;
namespace StaticField
{
    class StaticField
    {
        static void Main()
        {
            Console.WriteLine(MobilePhone.GetIPhone()); 
        }
    }

}