﻿/*
 Problem 4. ToString
    Add a method in the GSM class for displaying all information about it.
    Try to override ToString(). 
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ToString
{
    class MobilePhone
    {
        public string phoneModel = null;
        string phoneManufacturer = null;
        string phoneOwner = null;
        decimal ?phonePrice = null;
        Battery battery = null;
        Display display = null;
        public override string ToString()
        {

            return string.Format("Mobile phone, model:{0}, manufacturer:{1}, owner:{2}, price:{3}.\n"
                + battery.ToString() + "\n" + display.ToString(), this.phoneModel, this.phoneManufacturer,
                this.phoneOwner, this.phonePrice);

        }

        public MobilePhone(){
            battery = new Battery();
            display = new Display();
        }
        public MobilePhone(string model, string manufacturer)
        {
            this.phoneModel = model;
            this.phoneManufacturer = manufacturer;
        }
        public MobilePhone(string model, string manufacturer, string owner)
        {
            this.phoneModel = model;
            this.phoneManufacturer = manufacturer;
            this.phoneOwner = owner;
        }
        public MobilePhone(string model, string manufacturer, decimal? price)
        {
            this.phoneModel = model;
            this.phoneManufacturer = manufacturer;
            this.phonePrice = price;
        }
        public MobilePhone(string model, string manufacturer, string owner, decimal? price)
        {
            this.phoneModel = model;
            this.phoneManufacturer = manufacturer;
            this.phoneOwner = owner;
            this.phonePrice = price;
        }
    }
}
