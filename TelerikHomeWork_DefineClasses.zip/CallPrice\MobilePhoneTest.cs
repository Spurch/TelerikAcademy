﻿/*
Problem 11. Call price

    Add a method that calculates the total price of the calls in the call history.
    Assume the price per minute is fixed and is provided as a parameter.

 */
using System;
using System.Collections.Generic;
namespace CallPrice
{
    class MobilePhoneTest
    {
        static void Main()
        {
            var mobileList = new List<MobilePhone>();

            Battery nokiaBattery = new Battery("BJ51", BatteryType.LiIon, 40, 12);
            Battery sonyBattery = new Battery("BA900", BatteryType.LiIon, 30, 15);
            Battery samsungBattery = new Battery("EB-L1G6LLA", BatteryType.LiIon, 30, 15);

            Display smallDisplay = new Display(5, 16000000);
            Display mediumDisplay = new Display(7, 16000000);
            Display bigDisplay = new Display(11, 16000000);

            MobilePhone nokiaLumia = new MobilePhone("Lumia630", "Nokia", "Microsoft", 300.00M, nokiaBattery, smallDisplay);
            mobileList.Add(nokiaLumia);
            MobilePhone sonyExperia = new MobilePhone("XperiaM", "Sony", "Sony", 350.00M, sonyBattery, mediumDisplay);
            mobileList.Add(sonyExperia);
            MobilePhone samsungNote = new MobilePhone("GalaxyNote", "Samsung", "Samsung", 600.00M, samsungBattery, bigDisplay);
            mobileList.Add(samsungNote);

            foreach (var phone in mobileList)
            {
                Console.WriteLine(phone.ToString());
            }
            Console.WriteLine(MobilePhone.GetIPhone());
        }
    }
}

