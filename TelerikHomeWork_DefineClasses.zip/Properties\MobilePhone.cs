﻿/*
 Problem 5. Properties
    Use properties to encapsulate the data fields inside the GSM, Battery and Display classes.
    Ensure all fields hold correct data at any given time.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Properties
{
    class MobilePhone
    {
        private string phoneModel = null;
        private string phoneManufacturer = null;
        private string phoneOwner = null;
        private decimal ?phonePrice = null;
        private Battery battery = null;
        private Display display = null;
        public override string ToString()
        {

            return string.Format("Mobile phone, model:{0}, manufacturer:{1}, owner:{2}, price:{3}.\n"
                + this.BATTERY.ToString() + "\n" + this.DISPLAY.ToString(), this.MODEL, this.MANUFACTURER,
                this.OWNER, this.PRICE);

        }

        public MobilePhone(){
            battery = new Battery();
            display = new Display();
        }
        public MobilePhone(string model, string manufacturer, Battery battery, Display display)
        {
            this.BATTERY = battery;
            this.DISPLAY = display;
            this.MODEL = model;
            this.MANUFACTURER = manufacturer;
        }
        public MobilePhone(string model, string manufacturer, string owner, Battery battery, Display display)
        {
            this.BATTERY = battery;
            this.DISPLAY = display;
            this.MODEL = model;
            this.MANUFACTURER = manufacturer;
            this.OWNER = owner;
        }
        public MobilePhone(string model, string manufacturer, decimal? price, Battery battery, Display display)
        {
            this.BATTERY = battery;
            this.DISPLAY = display;
            this.MODEL = model;
            this.MANUFACTURER = manufacturer;
            this.PRICE = price;
        }
        public MobilePhone(string model, string manufacturer, string owner, decimal? price, Battery battery, Display display)
        {
            this.BATTERY = battery;
            this.DISPLAY = display;
            this.MODEL = model;
            this.MANUFACTURER = manufacturer;
            this.OWNER = owner;
            this.PRICE = price;
        }

        public Battery BATTERY
        {
            get
            {
                return this.battery;
            }
            set
            {
                this.battery = value;
            }
        }
        public Display DISPLAY
        {
            get
            {
                return this.display;
            }
            set
            {
                this.display = value;
            }
        }
        public string MODEL
        {
            get
            {
                return this.phoneModel;
            }
            set
            {
                this.phoneModel = value;
            }
        }
        public string MANUFACTURER
        {
            get
            {
                return this.phoneManufacturer;
            }
            set
            {
                this.phoneManufacturer = value;
            }
        }
        public string OWNER
        {
            get
            {
                return this.phoneOwner;
            }
            set
            {
                this.phoneOwner = value;
            }
        }
        public decimal? PRICE
        {
            get
            {
                return this.phonePrice;
            }
            set
            {
                this.phonePrice = value;
            }
        }
    }
}
