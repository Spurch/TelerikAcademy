﻿/*
 Problem 7. GSM test

    Write a class GSMTest to test the GSM class:
        Create an array of few instances of the GSM class.
        Display the information about the GSMs in the array.
        Display the information about the static property IPhone4S. 
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MobilePhoneTest
{
    class Display
    {
        private double? displaySize = null;
        private int? displayNumberOfColors = null;
        public override string ToString()
        {
            return string.Format("|         Display         |\n---------------------------\nSize: {0} inches.\nNumber of colors: {1} colors.\n",
                this.SIZE, this.COLOR);
        }
        public Display() { }
        public Display(double? size)
        {
            this.SIZE = size;
        }
        public Display(int? colors)
        {
            this.COLOR = colors;
        }
        public Display(double? size, int? colors)
        {
            this.SIZE = size;
            this.COLOR = colors;
        }
        public double? SIZE
        {
            get
            {
                return this.displaySize;
            }
            set
            {
                this.displaySize = value;
            }
        }
        public int? COLOR
        {
            get
            {
                return this.displayNumberOfColors;
            }
            set
            {
                this.displayNumberOfColors = value;
            }
        }
    }
}
