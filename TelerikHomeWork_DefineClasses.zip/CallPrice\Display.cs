﻿/*
Problem 11. Call price

    Add a method that calculates the total price of the calls in the call history.
    Assume the price per minute is fixed and is provided as a parameter.

 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CallPrice
{
    class Display
    {
        private double? displaySize = null;
        private int? displayNumberOfColors = null;
        public override string ToString()
        {
            return string.Format("|         Display         |\n---------------------------\nSize: {0} inches.\nNumber of colors: {1} colors.\n",
                this.SIZE, this.COLOR);
        }
        public Display() { }
        public Display(double? size)
        {
            this.SIZE = size;
        }
        public Display(int? colors)
        {
            this.COLOR = colors;
        }
        public Display(double? size, int? colors)
        {
            this.SIZE = size;
            this.COLOR = colors;
        }
        public double? SIZE
        {
            get
            {
                return this.displaySize;
            }
            set
            {
                this.displaySize = value;
            }
        }
        public int? COLOR
        {
            get
            {
                return this.displayNumberOfColors;
            }
            set
            {
                this.displayNumberOfColors = value;
            }
        }
    }
}
