﻿/*
Problem 11. Call price

    Add a method that calculates the total price of the calls in the call history.
    Assume the price per minute is fixed and is provided as a parameter.

 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CallPrice
{
    class MobilePhone
    {
        private static MobilePhone Iphone;

        private List<Call> callHistory = new List<Call>();
        private string phoneModel = null;
        private string phoneManufacturer = null;
        private string phoneOwner = null;
        private decimal ?phonePrice = null;
        private Battery battery = null;
        private Display display = null;
        public override string ToString()
        {
            StringBuilder OutString = new StringBuilder();
            OutString.AppendLine("---------------------------");
            OutString.AppendLine("|       Mobile phone      |");
            OutString.AppendLine("---------------------------");
            OutString.Append("Model: ");
            OutString.Append(this.MODEL + "\n");
            OutString.Append("Manufacturer: ");
            OutString.Append(this.MANUFACTURER + "\n");
            OutString.Append("Price: ");
            OutString.Append(this.PRICE + "\n");
            OutString.Append("Owner: ");
            OutString.Append(this.OWNER + "\n");
            OutString.AppendLine("---------------------------");
            OutString.AppendLine(this.BATTERY.ToString());
            OutString.AppendLine("---------------------------");
            OutString.AppendLine(this.DISPLAY.ToString());
            return OutString.ToString();

        }

        static MobilePhone()
        {
            Iphone = new MobilePhone("iPhone 4S", "Apple", "Will Smith", 700.00M, 
                new Battery("Apple", BatteryType.LiIon, 12, 36), new Display(7, 16000000));
        }

        public MobilePhone(){
            battery = new Battery();
            display = new Display();
        }
        public MobilePhone(string model, string manufacturer, Battery battery, Display display)
        {
            this.BATTERY = battery;
            this.DISPLAY = display;
            this.MODEL = model;
            this.MANUFACTURER = manufacturer;
        }
        public MobilePhone(string model, string manufacturer, string owner, Battery battery, Display display)
        {
            this.BATTERY = battery;
            this.DISPLAY = display;
            this.MODEL = model;
            this.MANUFACTURER = manufacturer;
            this.OWNER = owner;
        }
        public MobilePhone(string model, string manufacturer, decimal? price, Battery battery, Display display)
        {
            this.BATTERY = battery;
            this.DISPLAY = display;
            this.MODEL = model;
            this.MANUFACTURER = manufacturer;
            this.PRICE = price;
        }
        public MobilePhone(string model, string manufacturer, string owner, decimal? price, Battery battery, Display display)
        {
            this.BATTERY = battery;
            this.DISPLAY = display;
            this.MODEL = model;
            this.MANUFACTURER = manufacturer;
            this.OWNER = owner;
            this.PRICE = price;
        }

        public static string GetIPhone()
        {
            return Iphone.ToString();
        }

        public decimal CalculateCalls(decimal pricePerMinute)
        {
            decimal totalPrice = 0.0M;
            uint? totalSpan = 0;
            List<Call> tempList = this.HISTORY;
            foreach (var call in tempList)
            {
                if (call.SPAN == null)
                {
                    totalSpan += 0;
                }
                else
                {
                    totalSpan += call.SPAN;
                }
            }

            return totalPrice = (decimal)(totalSpan / 60) * pricePerMinute;
        }

        public void AddCall(Call call)
        {
            this.callHistory.Add(call);
        }

        public void DeleteCall(Call call)
        {
            this.callHistory.Remove(call);
        }

        public void ClearCall()
        {
            this.callHistory.Clear();
        }

        public List<Call> HISTORY
        {
            get { return this.callHistory; }
        }
        public Battery BATTERY
        {
            get
            {
                return this.battery;
            }
            set
            {
                this.battery = value;
            }
        }
        public Display DISPLAY
        {
            get
            {
                return this.display;
            }
            set
            {
                this.display = value;
            }
        }
        public string MODEL
        {
            get
            {
                return this.phoneModel;
            }
            set
            {
                this.phoneModel = value;
            }
        }
        public string MANUFACTURER
        {
            get
            {
                return this.phoneManufacturer;
            }
            set
            {
                this.phoneManufacturer = value;
            }
        }
        public string OWNER
        {
            get
            {
                return this.phoneOwner;
            }
            set
            {
                this.phoneOwner = value;
            }
        }
        public decimal? PRICE
        {
            get
            {
                return this.phonePrice;
            }
            set
            {
                this.phonePrice = value;
            }
        }
    }
}
