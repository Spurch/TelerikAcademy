﻿/*
 Problem 4. ToString
    Add a method in the GSM class for displaying all information about it.
    Try to override ToString(). 
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ToString
{
    class Display
    {
        double? displaySize = null;
        int ?displayNumberOfColors = null;
        public override string ToString()
        {
            return string.Format("Display, size:{0}, number of colors:{1}.", 
                this.displaySize, this.displayNumberOfColors);
        }
        public Display(){}
        public Display(double? size)
        {
            this.displaySize = size;
        }
        public Display(int? colors)
        {
            this.displayNumberOfColors = colors;
        }
        public Display(double? size, int? colors)
        {
            this.displaySize = size;
            this.displayNumberOfColors = colors;
        }
    }
}
