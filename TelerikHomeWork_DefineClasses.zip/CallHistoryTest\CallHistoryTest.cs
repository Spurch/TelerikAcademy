﻿/*
Problem 12. Call history test

    Write a class GSMCallHistoryTest to test the call history functionality of the GSM class.
        Create an instance of the GSM class.
        Add few calls.
        Display the information about the calls.
        Assuming that the price per minute is 0.37 calculate and print the total price of the calls in the history.
        Remove the longest call from the history and calculate the total price again.
        Finally clear the call history and print it.
 */
using System;
using System.Collections.Generic;
using System.Globalization;
namespace CallHistoryTest
{
    class CallHistoryTest
    {
        static void Main()
        {
            //Creating a new instance for each of our main classes.
            Battery nokiaBattery = new Battery("BJ51", BatteryType.LiIon, 40, 12);
            Display smallDisplay = new Display(5, 16000000);
            MobilePhone nokiaLumia = new MobilePhone("Lumia630", "Nokia", "Microsoft", 300.00M, nokiaBattery, smallDisplay);

            //Variable that will generate a random call duration in seconds.
            Random rand = new Random();
            //The assumed price per minute for each call.
            decimal pricePerMin = 0.37M;

            //We then add 6 calls with random duration to the newly created MobilePhone instance.
            for (int i = 0; i < 6; i++)
            {
                //Getting a new random duration in seconds.
                uint randSpan = (uint)rand.Next(0, 600);
                //Creating a new Call instance with the given random duration.
                Call call = new Call("+359887841089", DateTime.Today, DateTime.Now.TimeOfDay, randSpan);
                //Adding the call to the call history.
                nokiaLumia.AddCall(call);
            }

            //We get the whole call history, sort it and print it on the screen.
            Console.WriteLine("----------------------------SORTED CALL LIST---------------------------");
            List<Call> tempList = nokiaLumia.HISTORY;
            tempList.Sort();
            foreach (var call in tempList)
            {
                //We are using a class override of the ToString() method to print the call history.
                Console.WriteLine(call.ToString());
            }
            //Estimating the total cost in CurrentCulture currency.
            Console.WriteLine("\nPrice per minute is: {0}. Total cost: {1}\n", pricePerMin.ToString("C", CultureInfo.CurrentCulture), nokiaLumia.CalculateCalls(pricePerMin).ToString("C", CultureInfo.CurrentCulture));
            
            //We then use the fact that the list is sorted to delete the longest call.
            Console.WriteLine("-----------------------DELETING THE LONGEST CALL-----------------------");
            nokiaLumia.DeleteCall(tempList[tempList.Count - 1]);
            //We then print the whole list once again.
            foreach (var call in tempList)
            {
                Console.WriteLine(call.ToString());
            }
            //The newly estimated total cost.
            Console.WriteLine("\nPrice per minute is: {0}. Total cost: {1}\n", pricePerMin.ToString("C", CultureInfo.CurrentCulture), nokiaLumia.CalculateCalls(pricePerMin).ToString("C", CultureInfo.CurrentCulture));

            //We clear the list and attempt to print the empty list.
            Console.WriteLine("---------------------CLEARING THE WHOLE CALL LIST----------------------");
            nokiaLumia.ClearCall();
            foreach (var call in tempList)
            {
                Console.WriteLine(call.ToString());
            }
            Console.WriteLine("\nPrice per minute is: {0}. Total cost: {1}\n", pricePerMin.ToString("C", CultureInfo.CurrentCulture), nokiaLumia.CalculateCalls(pricePerMin).ToString("C", CultureInfo.CurrentCulture));
        }
    }
}

