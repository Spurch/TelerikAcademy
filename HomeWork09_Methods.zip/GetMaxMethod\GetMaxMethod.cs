﻿/*
 Problem 2. Get largest number
 Write a method GetMax() with two parameters that returns the larger of two integers.
 Write a program that reads 3 integers from the console and prints the largest of them
 using the method GetMax(). 
 */
using System;
class GetMaxMethod
{
    public static int GetMax(int x, int y)
    {
        return x > y? x : y;
    }
    static void Main()
    {
        Console.WriteLine("Enter first value:");
        int FirstValue = Int32.Parse(Console.ReadLine());
        Console.WriteLine("Enter second value:");
        int SecondValue = Int32.Parse(Console.ReadLine());
        Console.WriteLine("Enter third value:");
        int ThirdValue = Int32.Parse(Console.ReadLine());
        
        Console.WriteLine(GetMax(GetMax(FirstValue, SecondValue) ,ThirdValue));
    }
}

