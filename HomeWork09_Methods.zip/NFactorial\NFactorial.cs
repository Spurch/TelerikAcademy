﻿/*
 Problem 10. N Factorial
    Write a program to calculate n! for each n in the range [1..100]. 
 */
using System;
using System.Linq;
class NFactorial
{
    public static int[] Factorial(int n)
    {
        int[] Arr = n.ToString().ToCharArray().Select(x => (int)Char.GetNumericValue(x)).ToArray();
        Array.Reverse(Arr);
        return Arr;
    }
    static void Main()
    {

    }
}

