﻿/*
 Problem 4. Appearance count
    Write a method that counts how many times given number appears in given array.
    Write a test program to check if the method is workings correctly. 
 */
using System;
using System.Linq;
class ElementCounter
{
    public static int Counter<T>(T[] Arr, T Element)
    {
        int count = 0;
        for (int i = 0; i < Arr.Length; i++)
        {
            if (Arr[i].Equals(Element))
            {
                count++;
            }
        }
        return count;
    }
    static void Main()
    {
        Console.WriteLine("Enter array values in one single row, seperated by , or space:");
        int[] NumberArray = Console.ReadLine().
            Split(new char[] { ' ', ',', '\t' }, StringSplitOptions.RemoveEmptyEntries)
            .Select(x => int.Parse(x)).ToArray();
        Console.WriteLine("Enter a value to look for: ");
        int Value = Int32.Parse(Console.ReadLine());

        Console.WriteLine("The value appears {0} times.", Counter(NumberArray, Value)); 
    }
}

