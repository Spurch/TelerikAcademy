﻿/*
 Problem 6. First larger than neighbours
    Write a method that returns the index of the first element in array that is larger than its neighbours, or -1, if there’s no such element.
    Use the method from the previous exercise. 
 */
using System;
class FirstLargerThanNeighbours
{
    public static bool LargerThan(int[] Arr, int index)
    {
        bool isBigger = false;
        if (index != 0 && index != Arr.Length && index != Arr.Length - 1 && Arr.Length >= 3)
        {
            if (Arr[index] > Arr[index - 1] && Arr[index] > Arr[index + 1])
            {
                isBigger = true;
            }
        }
        return isBigger;
    }

    public static int FirstLargerThan(int[] Arr)
    {

        int index = -1;
        int i = 1;
        while (i < Arr.Length-1)
        {
            if (LargerThan(Arr, i))
            {
                index = i;
                break;
            }
            i++;
        }
        return index;
    }
    static void Main()
    {
        int[] array = new int[] {1,2,3,4,5,6,7,8,9};
        Console.WriteLine(FirstLargerThan(array));
        
    }
}

