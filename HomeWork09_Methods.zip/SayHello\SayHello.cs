﻿/*
 Problem 1. Say Hello
    Write a method that asks the user for his name and prints “Hello, <name>”
    Write a program to test this method.
 */
using System;
using System.Text;
class SayHello
{
    public static void Hello()
    {
        Console.WriteLine("Please enter your name: ");
        string UserName = Console.ReadLine();
        StringBuilder Hello = new StringBuilder();
        Hello.Append("Hello, ");
        Hello.Append(UserName + "!");
        Console.WriteLine(Hello);
    }
    static void Main()
    {
        Hello();
    }
}

