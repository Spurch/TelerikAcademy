﻿/*
 Problem 5. Larger than neighbours
 Write a method that checks if the element at given position in given 
 array of integers is larger than its two neighbours (when such exist). 
 */
using System;
using System.Linq;
class LargerThanNeighbours
{
    public static bool LargerThan(int[] Arr, int index)
    {
        bool isBigger = false;
        if (index != 0 && index != Arr.Length && index != Arr.Length - 1 && Arr.Length >= 3)
        {
            if (Arr[index] > Arr[index - 1] && Arr[index] > Arr[index + 1])
            {
                isBigger = true;
            }
        }
        return isBigger;
    }
    static void Main()
    {
        Console.WriteLine("Enter array values in one single row, seperated by , or space:");
        int[] NumberArray = Console.ReadLine().
            Split(new char[] { ' ', ',', '\t' }, StringSplitOptions.RemoveEmptyEntries)
            .Select(x => int.Parse(x)).ToArray();
        Console.WriteLine("Enter an index to check: ");
        int Value = Int32.Parse(Console.ReadLine());

        Console.WriteLine("Is the value at index {0} larger than its neighbours? -{1}!", Value, LargerThan(NumberArray, Value)); 
        
    }
}

