﻿/*
 Problem 8. Number as array
 Write a method that adds two positive integer numbers represented as arrays of 
 digits (each array element arr[i] contains a digit; the last digit is kept in arr[0]).
 Each of the numbers that will be added could have up to 10 000 digits. 
 */
using System;
using System.Linq;
class NumberAsArray
{
    public static int[] CalcNumbers(decimal a, decimal b)
    {
        //We always presume that the first number is larger so we check
        //and call again the CalcNumbers method if needed!
        if (a < b)
        {
            return CalcNumbers(b, a);
        }

        //Getting the first number as an array of integers.
        int[] FirstArray = a.ToString().ToCharArray().Reverse().Select(x => (int)Char.GetNumericValue(x)).ToArray();
        //Getting the second number as an array of integers.
        int[] SecondArray = b.ToString().ToCharArray().Reverse().Select(x => (int)Char.GetNumericValue(x)).ToArray();
        
        //Note that when we sum to numbers the resulting number will have at most 
        //the number of digits of the bigger number + 1.
        //Exmp: 999 + 5 = 1004 ; 999 + 999 = 1998 ; etc.
        int ResultLenght = FirstArray.Length + 1;

        //We create the resulting array.
        int[] ResultArray = new int[ResultLenght];

        //Variable to hold the reminder if the sum is 10 or bigger.
        int AddRem = 0;
        //Variable to hold the sum.
        int Add = 0;
        for (int i = 0; i < FirstArray.Length; i++)
        {
            //If we are not out of range of the smaller array.
            if (i < SecondArray.Length)
            {
                Add = FirstArray[i] + SecondArray[i];
            }
            //If we have already added all the digits of the smaller array.
            else
            {
                Add = FirstArray[i];
            }
            //If the sum is 10 or larger.
            if (Add > 9 && (i + 1) < FirstArray.Length)
            {
                AddRem = Add % 10;
                ResultArray[i] += AddRem;
                //NOTE: Here we increment the next cell in the resulting array.
                ResultArray[i + 1] += 1;
                
            }
            else
            {
                Add = ResultArray[i] += Add;
                //CONTINUE NOTE: So there is a chance to have the case when 
                //we add 9 when Result[i] has a value of 1.
                if (Add > 9)
                {
                    AddRem = Add % 10;
                    //NOTE: Here we do not add the AddRem value to the current result
                    //array value we replace it! Otherwise we will get a wrong result!
                    ResultArray[i] = AddRem;
                    ResultArray[i + 1] += 1;
                }
            }
        }
        if (ResultArray[ResultLenght - 1] == 0)
        {
            int[] Result = new int[ResultLenght - 1];
            for (int i = 0; i < ResultLenght - 1; i++)
            {
                Result[i] = ResultArray[i];
            }
            return Result;
        }
        else
        {
            return ResultArray;
        }
    }

    //Simple method that prints an array of integers on the console.
    private static void Print(int[] Arr)
    {
        for (int i = Arr.Length - 1; i >= 0; i--)
        {
            Console.Write("{0}", Arr[i]);
        }
        Console.WriteLine();
    }

    static void Main()
    {
        Console.WriteLine("Enter first value: ");
        decimal a = Decimal.Parse(Console.ReadLine());
        Console.WriteLine("Enter second value: ");
        decimal b = Decimal.Parse(Console.ReadLine());
        Console.WriteLine("The result is: ");
        Print(CalcNumbers(a, b));
    }
}

