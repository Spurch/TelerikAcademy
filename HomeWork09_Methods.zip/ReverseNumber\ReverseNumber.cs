﻿/*
 Problem 7. Reverse number
    Write a method that reverses the digits of given decimal number. 
 */
using System;
using System.Linq;
class ReverseNumber
{
    public static decimal RevNumber(decimal Value)
    {
        string RevNum = Value.ToString();
        string ReverseString = "";
        char[] Arr = RevNum.ToCharArray();
        for (int i = Arr.Length-1; i > -1; i--)
        {
            ReverseString += Arr[i];
        }

        return Decimal.Parse(ReverseString);
    }
    static void Main()
    {
        Console.WriteLine("Please enter a value to reverse:");
        decimal ValueToReverse = Decimal.Parse(Console.ReadLine());
        ValueToReverse = RevNumber(ValueToReverse);
        Console.WriteLine(ValueToReverse);
    }
}

