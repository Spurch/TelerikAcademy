﻿/*
 Problem 3. English digit
 Write a method that returns the last digit of given integer as an English word.
 */
using System;
using System.Text;
class EnglishDigit
{
    public static string DigitToWord(int Digit)
    {
        StringBuilder Word = new StringBuilder();
        Digit = Digit % 10;
        switch (Digit)
        {
            case 1:
                Word.Append("One"); break;
            case 2:
                Word.Append("Two"); break;
            case 3:
                Word.Append("Three"); break;
            case 4:
                Word.Append("Four"); break;
            case 5:
                Word.Append("Five"); break;
            case 6:
                Word.Append("Six"); break;
            case 7:
                Word.Append("Seven"); break;
            case 8:
                Word.Append("Eight"); break;
            case 9:
                Word.Append("Nine"); break;
            default:
                Word.Append("Zero"); break;
        }

        return Word.ToString();
    }
    static void Main()
    {
        Console.WriteLine("Enter a number:");
        int Number = Int32.Parse(Console.ReadLine());
        Console.WriteLine(DigitToWord(Number));
    }
}

