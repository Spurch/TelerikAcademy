﻿/*
 Problem 1. StringBuilder.Substring
 Implement an extension method Substring(int index, int length) for the class 
 StringBuilder that returns new StringBuilder and has the same functionality as 
 Substring in the class String.
 */

namespace SubString
{
    using System;
    using System.Text;
    class SubString
    {
        static void Main()
        {
            try
            {
                StringBuilder test = new StringBuilder();
                test.Append("The quick brown fox!");
                test = test.SubString(0, 5);
                Console.WriteLine(test.ToString());
            }
            catch (IndexOutOfRangeException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
