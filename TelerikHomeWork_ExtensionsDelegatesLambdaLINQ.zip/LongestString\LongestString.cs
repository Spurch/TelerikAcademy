﻿/*
 Problem 17. Longest string
    Write a program to return the string with maximum length from an array of strings.
    Use LINQ. 
 */
using System;
using System.Linq;
class Program
{
    public static string GetLongestString(string[] inputStringArray)
    {
        var tempStringArray = from currentString in inputStringArray
                           orderby currentString.Length descending
                           select currentString;
        var resultString = tempStringArray.FirstOrDefault();

        return resultString;
    }
    static void Main()
    {
        string[] testString = new string[] { "the", "quick", "brown", "fox" };
        Console.WriteLine(Program.GetLongestString(testString)); 
    }
}

