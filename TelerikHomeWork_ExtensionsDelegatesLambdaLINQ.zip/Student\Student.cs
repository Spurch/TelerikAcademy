﻿namespace Student
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Text.RegularExpressions;
    class Student
    {
        private string firstName = string.Empty;
        private string lastName = string.Empty;
        private string facultyNumber = string.Empty;
        private string mobileNumber = string.Empty;
        private string studentMail = string.Empty;
        private int studentAge = default(int);
        private List<double> marksList;
        private Group group;
        private Student() { }
        public Student(string firstName, string lastName, string facultyNumber,
            string mobileNumber, string studentMail, int studentAge, Group group, List<double> marksList)
        {
            this.FIRSTNAME = firstName;
            this.LASTNAME = lastName;
            this.FN = facultyNumber;
            this.MOBILE = mobileNumber;
            this.MAIL = studentMail;
            this.AGE = studentAge;
            this.GROUP = group;
            this.MARKS = marksList;
        }

        public override string ToString()
        {
            return string.Format("Student N:{0}\nName:{1} {2}\nAge:{3}\nMobile:{4}\nMail:{5}\n{6}\n"
                , this.FN, this.FIRSTNAME, this.LASTNAME, this.AGE, this.MOBILE, this.MAIL, this.GROUP);
        }

        public string GetMarks()
        {
            StringBuilder marksBuilder = new StringBuilder();
            marksBuilder.Append("==============");
            foreach (var mark in this.MARKS)
            {
                marksBuilder.Append(mark);
                marksBuilder.AppendLine();
            }
            marksBuilder.Append("==============");
            return marksBuilder.ToString();
        }

        public string FIRSTNAME
        {
            get { return this.firstName; }
            set
            {
                if (value == null) { throw new ArgumentNullException(
                    "Student first name cannot be null!"); }
                this.firstName = value;
            }
        }
        public string LASTNAME
        {
            get { return this.lastName; }
            set
            {
                if (value == null) { throw new ArgumentNullException(
                    "Student last name cannot be null!"); }
                this.lastName = value;
            }
        }
        public string FN
        {
            get { return this.facultyNumber; }
            set
            {
                if (value == null) { throw new ArgumentNullException(
                    "Student faculty number cannot be null!"); }
                this.facultyNumber = value;
            }
        }
        public string MOBILE
        {
            get { return this.mobileNumber; }
            set
            {
                if (value == null) { throw new ArgumentNullException(
                    "Student mobile number cannot be null!"); }
                this.mobileNumber = value;
            }
        }
        public string MAIL
        {
            get { return this.studentMail; }
            set
            {
                if (value == null) { throw new ArgumentNullException(
                    "Student mail address cannot be null!"); }
                else if (Regex.IsMatch(value, 
                        @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z", 
                    RegexOptions.IgnoreCase))
                {
                    this.studentMail = value;
                }
                else{throw new ArgumentNullException(
                    "Invalid mail entry!");}
            }
        }
        public int AGE
        {
            get { return this.studentAge; }
            set
            {
                if (value == 0) { throw new ArgumentException(
                    "Student age cannot be zero!"); }
                else if (value < 0) { throw new ArgumentException(
                    "Student age cannot be negative!"); }
                this.studentAge = value;
            }
        }

        public List<double> MARKS
        {
            get { return this.marksList; }
            set
            {
                if (value == null) { throw new ArgumentNullException(
                    "Marks list cannot be null!"); }
                this.marksList = value; }
        }

        public Group GROUP
        {
            get { return this.group; }
            set
            {
                if (value == null) { throw new ArgumentNullException(
                    "Group cannot be null!"); }
                this.group = value;
            }
        }
    }
}
