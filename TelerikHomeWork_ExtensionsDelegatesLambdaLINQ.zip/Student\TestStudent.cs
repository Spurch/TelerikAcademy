﻿namespace Student
{
    using System;
    using System.Collections.Generic;
    class Program
    {
        static void Main()
        {

            Group group1 = new Group("1", "Physics");
            Group group2 = new Group("2", "Mathematics");

            Student student00 = new Student("Ivan", "Stoyanov", "F80660", "029752130", "ivan.stoyanov@gmail.com", 24, group1, new List<double> { 3, 5});
            Student student01 = new Student("Georgi", "Georgiev", "F80670", "+359897234822", "g.georgiev@abv.bg", 20, group2, new List<double> { 6, 6, 6, 6 });
            Student student02 = new Student("Nikolay", "Nikolov", "F80565", "+359887123456", "nikolov.n@gmail.com", 18, group2, new List<double> { 2, 2, 4, 3 });
            Student student03 = new Student("Petar", "Petrov", "F80606", "+359888665789", "petar.p@abv.bg", 19, group1, new List<double> { 4, 4, 4, 4 });
            Student student04 = new Student("Emil", "Emilov", "F81606", "029314567", "emilemilov@gmail.com", 22, group1, new List<double> { 4, 3, 3, 6 });

            Student[] studentGroup = new Student[5];
            studentGroup[0] = student00;
            studentGroup[1] = student01;
            studentGroup[2] = student02;
            studentGroup[3] = student03;
            studentGroup[4] = student04;

            List<Student> studentList = new List<Student>();
            studentList.Add(student00);
            studentList.Add(student01);
            studentList.Add(student02);
            studentList.Add(student03);
            studentList.Add(student04);

            Console.WriteLine("-----------------------");
            Console.WriteLine("Students by age range:");
            Console.WriteLine("-----------------------");
            var temp00 = StudentMethods.SortByAge(studentGroup, 20, 30);
            foreach (var item in temp00)
            {
                Console.WriteLine(item);
            }

            Console.WriteLine("-----------------------");
            Console.WriteLine("Students by name order:");
            Console.WriteLine("-----------------------");
            var temp01 = StudentMethods.SortByName(studentGroup);
            foreach (var item in temp01)
            {
                Console.WriteLine(item);
            }

            Console.WriteLine("------------------");
            Console.WriteLine("Students by phone:");
            Console.WriteLine("------------------");
            var temp02 = StudentMethods.ExtractByPhone(studentGroup, "02");
            foreach (var item in temp02)
            {
                Console.WriteLine(item);
            }

            Console.WriteLine("-----------------");
            Console.WriteLine("Students by mail:");
            Console.WriteLine("-----------------");
            var temp03 = StudentMethods.ExtractByMail(studentGroup, "abv.bg");
            foreach (var item in temp03)
            {
                Console.WriteLine(item);
            }

            Console.WriteLine("------------------");
            Console.WriteLine("Students by group:");
            Console.WriteLine("------------------");
            var temp04 = StudentMethods.ExtractByGroup(studentList, "2");
            foreach (var item in temp04)
            {
                Console.WriteLine(item);
            }

            Console.WriteLine("----------------------------");
            Console.WriteLine("Students by group extension:");
            Console.WriteLine("----------------------------");

            var temp05 = StudentMethods.ExtractByGroupExtension(studentList, "2");
            foreach (var item in temp05)
            {
                Console.WriteLine(item);
            }

            Console.WriteLine("----------------------------");
            Console.WriteLine("Students by marks anonymous:");
            Console.WriteLine("----------------------------");

            StudentMethods.ExtractByMarks(studentGroup, 6);

            Console.WriteLine("-------------------------");
            Console.WriteLine("Students by marks number:");
            Console.WriteLine("-------------------------");

            StudentMethods.ExtractByMarksNumber(studentGroup, 2);

            Console.WriteLine("------------------------");
            Console.WriteLine("Students by enroll year:");
            Console.WriteLine("------------------------");
            var temp06 = StudentMethods.ExtractStudentsByEnrollYear(studentGroup, 2006);
            foreach (var item in temp06)
            {
                foreach (var mark in item)
                {
                    Console.Write("{0} ", mark);
                }
                Console.WriteLine();
            }
        }
    }

}