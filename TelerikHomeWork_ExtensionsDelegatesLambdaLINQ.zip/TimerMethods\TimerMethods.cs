﻿/*
 Problem 7. Timer
    Using delegates write a class Timer that can execute certain method at each t seconds. 
 */
namespace TimerEvents
{
    using System;
    using System.Threading;
    public delegate void TimerDelegate();
    public class TimerMethods
    {
        // fields
        private int interval;
        private int ticks;
        private TimerDelegate timer;
        // constructor
        public TimerMethods(int interval, int ticks, TimerDelegate timerEvent)
        {
            this.INTERVAL = interval;
            this.TICKS = ticks;
            this.TIMEREVENT = timerEvent;
        }
        // properties
        public int INTERVAL
        {
            get
            {
                return this.interval;
            }
            set
            {
                if (value < 0)
                {
                    throw new ArgumentException("Interval must be a non-negative value!");
                }
                this.interval = value * 1000;
            }
        }
        public int TICKS
        {
            get
            {
                return this.ticks;
            }
            set
            {
                if (value < 0)
                {
                    throw new ArgumentException("The ticks must be a non-negative value!");
                }
                this.ticks = value;
            }
        }
        public TimerDelegate TIMEREVENT
        {
            get
            {
                return this.timer;
            }
            set
            {
                this.timer = value;
            }
        }
        // Methods
        public void TickTack()
        {
            while (ticks > 0)
            {
                Thread.Sleep((int)interval);
                ticks--;
                timer();
            }
        }
    }
}