﻿namespace TimerEvents
{
using System;
    class Test
    {
        public static void Main()
        {
            TimerMethods timer = new TimerMethods(1, 15, delegate() { Console.WriteLine("Tick-tack!"); });
            timer.TickTack();
        }
    }
}
