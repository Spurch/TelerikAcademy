﻿namespace Student
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    class Group
    {
        private string groupNumber;
        private string groupDepartment;

        private Group() { }

        public Group(string groupNumber, string groupDepartment)
        {
            this.NUMBER = groupNumber;
            this.DEPARTMENT = groupDepartment;
        }

        public override string ToString()
        {
            return string.Format("Group N:{0}\nDepartment:{1}", this.NUMBER, this.DEPARTMENT);
        }
        public string NUMBER
        {
            get { return this.groupNumber; }
            set
            {
                if (value == null) { throw new ArgumentNullException(
                    "Group number cannot be null!"); }
                this.groupNumber = value;
            }
        }
        public string DEPARTMENT
        {
            get { return this.groupDepartment; }
            set
            {
                if (value == null) { throw new ArgumentNullException(
                    "Department name cannot be null!"); }
                this.groupDepartment = value;
            }
        }
    }
}
