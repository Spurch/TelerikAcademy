﻿/*
 Problem 2. IEnumerable extensions
    Implement a set of extension methods for IEnumerable<T> that implement
    the following group functions: sum, product, min, max, average.
 */
namespace IEnumerableExtensions
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    public static class IEnumerableExtensions
    {
        //Extension method for the Min function.
        public static T Min<T>(this IEnumerable<T> source) where T : IComparable
        {
            if (source.Count() == 0)
            {
                throw new ArgumentNullException("Source collection is null or empty!");
            }
            T min = source.First();
            foreach (var item in source)
            {
                if (item.CompareTo(min) <= 0)
                {
                    min = item;
                }
            }
            return min;
        }

        //Extension method for the Max function.
        public static T Max<T>(this IEnumerable<T> source) where T : IComparable
        {
            if (source.Count() == 0)
            {
                throw new ArgumentNullException("Source collection is null or empty!");
            }
            T max = source.First();
            foreach (var item in source)
            {
                if (item.CompareTo(max) >= 0)
                {
                    max = item;
                }
            }
            return max;
        }

        //Extension method for the sum function.
        public static T Sum<T>(this IEnumerable<T> source, Func<T, dynamic> ConvertFunc)
        {
            var resultSum = default(T);
            foreach (var item in source)
            {
                resultSum += ConvertFunc(item);    
            }
            
            return resultSum;
        }
        //Extension method for the prod function.
        public static T Product<T>(this IEnumerable<T> source, Func<T, dynamic> ConvertFunc)
        {
            dynamic resultProduct = 1;
            foreach (var item in source)
            {
                resultProduct *= ConvertFunc(item);
            }

            return resultProduct;
        }

        //Extension method for the average function.
        public static T Average<T>(this IEnumerable<T> source, Func<T, dynamic> AvgFunc)
        {
            var averageResult = default(T);
            int count = source.Count();
            foreach (var item in source)
            {
                averageResult += AvgFunc(item);
            }
            return (dynamic)averageResult / (dynamic)count;
        }
    }
}